#include "../src/renderer.h"
#include "../src/b7_anim.h"
#include <stdio.h>
#include <math.h>
static int check(const char *name,unsigned armor){
    char file[200];snprintf(file,sizeof(file),"models/%s.im2t",name);
    IM2Model mdl={0};B7Motion m={0};
    if(!im2_load(&mdl,file))return 0;
    if(!b7_prepare(&m,armor,&mdl))return 0;
    if(!(m.hover.xyz&&m.walk.xyz&&m.land.xyz&&m.fly.xyz))return 0;
    float init[3]={mdl.vertices[0].x,mdl.vertices[0].y,mdl.vertices[0].z};
    /* Exercise four original keyframed poses; no inert binary streams. */
    unsigned stages[4]={200,350,500,100};
    for(int s=0;s<4;s++){
      b7_apply(&m,&mdl,s==0||s==2,s==1||s==2,s==3,stages[s],stages[s]);
      for(unsigned i=0;i<mdl.nv;i++)if(!isfinite(mdl.vertices[i].x)||!isfinite(mdl.vertices[i].y)||!isfinite(mdl.vertices[i].z))return 0;
    }
    b7_apply(&m,&mdl,0,0,0,0,0);
    float delta=fabsf(mdl.vertices[0].x-init[0])+fabsf(mdl.vertices[0].y-init[1])+fabsf(mdl.vertices[0].z-init[2]);
    printf("%s vertices %u rest error %.7f\n",name,mdl.nv,delta);
    b7_release(&m);im2_free(&mdl);
    return delta<1e-5f;
}
int main(void){
  return (check("mark6",0)&&check("mark4",1)&&check("warmachine",2)&&check("stealth",3)&&check("suitcase",4)) ? (puts("PASS: five suits; original animation playback and rest restoration"),0):1;
}
