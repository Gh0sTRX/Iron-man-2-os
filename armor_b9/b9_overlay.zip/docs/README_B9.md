# Iron Man 2 PS Vita B9 — Five Armors & Missing Animations

This experimental private-use overlay extends the previously verified B8 target range without replacing the old VPK.

New: original SuitCase/Mark V mesh (629 vertices, 902 triangles, 25 palette bones) and MC_SuitCase PVRTC texture; Mark IV and Stealth animate by vertex-order-identical Mark VI motion streams; Mark VI forward horizontal flying pose uses the original War Machine 2010 clip retargeted to the Mark VI rig; War Machine flight-to-ground uses original Iron Man Fly2Ground clip retargeted to War Machine; SuitCase uses original Iron Man idle hover, walk, land and float forward clips.

The sourced clips are authentic original IPA animation data, not the original executable or commercial game's missions. Certain clips are deliberately retargeted across armors and must be checked on real PS Vita for visual artifacts. Does not claim complete official game fidelity.

B8 reticle and targets preserved, as are all prior models. Existing B8 VPK app ID IM2E00005 preserved; B9 builds IM2F00006.
