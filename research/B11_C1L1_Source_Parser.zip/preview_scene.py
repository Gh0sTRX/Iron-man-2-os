from pathlib import Path
import sys, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
sys.path.insert(0,str(Path(__file__).parent))
from bdae_scene_parser import parse
B=Path(__file__).parent
files={
 'C1L1_ground_001':(0.31,0.39,0.45),'C1L1_obj_001':(.72,.72,.74),'C1L1_obj_002':(.65,.69,.73),'C1L1_obj_003':(.71,.67,.61),'C1L1_obj_004':(.62,.64,.62),
 'C1L1_car_01':(.86,.47,.30),'C1L1_car_02':(.78,.51,.29),'C1L1_light_001':(.45,.67,.59),'C1L1_light_002':(.43,.66,.60),'C1L1_light_003':(.48,.64,.61)
}
# An orthographic oblique view with z exaggerated ~1.75x for urban silhouette.
def make(filename,angle=.68,filter_scene=550,zoom=1,omit_ground=False):
 arr=[];cols=[];depth=[];r=np.array([[np.cos(angle),-np.sin(angle)],[np.sin(angle),np.cos(angle)]])
 for f,color in files.items():
  if omit_ground and f=='C1L1_ground_001':continue
  raw=(B/'original_models'/(f+'.bdae')).read_bytes();ms,_=parse(raw)
  for m in ms:
   v=m['positions'];face=m['faces'];c=np.mean(v[face],axis=1)
   mask=(abs(c[:,0])<filter_scene)&(abs(c[:,1])<filter_scene)
   face=face[mask]
   if len(face)==0:continue
   pt=v[face]
   xy=pt[:,:,:2]@r
   screen=np.stack([xy[:,:,0],xy[:,:,1]*.44+pt[:,:,2]*2.6],axis=2)
   arr.extend(screen);shade=(.77+np.clip((np.cross(pt[:,1]-pt[:,0],pt[:,2]-pt[:,0])[:,2])/140,-.20,.23))
   cols.extend([tuple(np.clip(np.array(color)*float(s),0,1)) for s in shade]);depth.extend(np.mean(xy[:,:,1]-pt[:,:,2]*0.27,axis=1))
 ix=np.argsort(depth)[::-1]
 fig,ax=plt.subplots(figsize=(15,9),dpi=160);fig.patch.set_facecolor('#08101c');ax.set_facecolor('#08101c')
 collection=PolyCollection(np.asarray(arr)[ix],facecolors=np.asarray(cols)[ix],edgecolors=(.06,.1,.15,.18),linewidths=.11,antialiaseds=False)
 ax.add_collection(collection)
 pts=np.asarray(arr).reshape(-1,2)
 lim=np.percentile(pts,[.25,99.75],axis=0)
 center=(lim[0]+lim[1])/2
 size=(lim[1]-lim[0])*1.1
 ax.set_xlim(center[0]-size[0]*.52,center[0]+size[0]*.52)
 ax.set_ylim(center[1]-size[1]*.52,center[1]+size[1]*.52)
 ax.set_aspect('equal',adjustable='datalim');ax.axis('off')
 ax.text(.02,.96,'IRON MAN 2  /  C1L1 ORIGINAL WORLD GEOMETRY',transform=ax.transAxes,fontsize=18,color='#f1f4f8',fontweight='bold')
 ax.text(.02,.92,'Reconstructed from 2010 IPA  •  untextured geometry preview  •  placement to be verified',transform=ax.transAxes,fontsize=10,color='#7bc8db')
 fig.subplots_adjust(left=.005,right=.995,bottom=.005,top=.995)
 fig.savefig(B/'exports'/filename,facecolor=fig.get_facecolor(),pad_inches=0.02)
 plt.close(fig)
 print(filename,'triangles',len(arr))
make('C1L1_original_geometry_oblique.png')
make('C1L1_original_geometry_without_ground.png',angle=-.85,omit_ground=True)
