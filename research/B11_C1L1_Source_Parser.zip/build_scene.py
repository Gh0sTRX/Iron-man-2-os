#!/usr/bin/env python3
"""Build GLB from original 2010 Iron Man 2 environment mesh positions and validated faces.
This is an asset-layout preview, NOT the decoded level state graph or collision.
"""
from pathlib import Path
import csv,sys,hashlib
from collections import Counter
import numpy as np
import trimesh
sys.path.insert(0,str(Path(__file__).parent))
from bdae_scene_parser import parse
BASE=Path(__file__).parent
SRC=BASE/'original_models'; OUT=BASE/'exports';OUT.mkdir(exist_ok=True)
# Ground meshes are original world coordinates. Collision meshes are excluded from rendered scene.
series=[('C1L1_ground_001','ground',[98,112,115,255]),('C1L1_obj_001','urban',[157,159,174,255]),('C1L1_obj_002','urban',[147,151,168,255]),('C1L1_obj_003','urban',[166,162,151,255]),('C1L1_obj_004','urban',[157,153,142,255]),('C1L1_car_01','vehicles',[168,113,78,255]),('C1L1_car_02','vehicles',[137,104,77,255]),('C1L1_light_001','props',[92,133,116,255]),('C1L1_light_002','props',[103,142,128,255]),('C1L1_light_003','props',[108,131,131,255])]
scene=trimesh.Scene();rows=[];verts=faces=0
for fname,kind,rgba in series:
 source=SRC/(fname+'.bdae');ms,stats=parse(source.read_bytes())
 for j,m in enumerate(ms):
  geom=trimesh.Trimesh(vertices=m['positions'],faces=m['faces'],process=False,validate=False)
  assert len(geom.faces)==len(m['faces']);geom.visual.vertex_colors=np.tile(rgba,(len(geom.vertices),1))
  scene.add_geometry(geom,geom_name=fname+'_'+str(j),node_name=fname+'_'+str(j))
  rows.append({'source':fname+'.bdae','mesh':m['name'],'vertices':len(geom.vertices),'triangles':len(geom.faces),'stride_bytes':m['stride'],'vertex_offset':hex(m['vertex_offset']),'mesh_header_offset':hex(m['mesh_descriptor']),'min_x':float(m['positions'][:,0].min()),'min_y':float(m['positions'][:,1].min()),'min_z':float(m['positions'][:,2].min()),'max_x':float(m['positions'][:,0].max()),'max_y':float(m['positions'][:,1].max()),'max_z':float(m['positions'][:,2].max())});verts+=len(geom.vertices);faces+=len(geom.faces)
from zipfile import ZipFile
char_src=BASE/'assets'/'Iron_man_mark6_textured.glb'
char=trimesh.load(char_src,force='mesh');char.apply_translation((0,0,0))
scene.add_geometry(char,geom_name='MarkVI_illustrative_start_at_0_0_0',node_name='MarkVI_not_original_spawn')
# Correct original Z-up asset coordinates to standard glTF Y-up orientation.
rot=trimesh.transformations.rotation_matrix(-np.pi/2,[1,0,0])
scene.apply_transform(rot)
scene.export(str(OUT/'IronMan2_C1L1_Original_Geometry_With_MarkVI.glb'))
# separate scene environment without suit
scene2=trimesh.Scene()
for k,v in scene.geometry.items():
 if not k.startswith('MarkVI_'):scene2.add_geometry(v,geom_name=k)
scene2.apply_transform(rot)
scene2.export(str(OUT/'IronMan2_C1L1_Environment_Geometry.glb'))
with (OUT/'geometry_manifest.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()));writer.writeheader();writer.writerows(rows)
print('meshes',len(rows),'vertices',verts,'triangles',faces,'models',len(series))
print('bounds',scene2.bounds)
for x in OUT.glob('*.glb'):
 print(x.name,'size',x.stat().st_size,'sha256',hashlib.sha256(x.read_bytes()).hexdigest())
 s=trimesh.load(str(x),force='scene');print('reload geometries',len(s.geometry),'bound',s.bounds)
