# Iron Man 2 (2010) — B11 Orijinal C1L1 Sahne Geometrisi

**Milestone:** İlk kez orijinal iOS IPA'nın `models` arşivindeki sahne parçaları (zemin, yapı, dekor ve araç) ortak bir 3D sahnede birleştirildi. Bu henüz PS Vita VPK'si veya oynanabilir görev değildir.

## Doğrudan doğrulanan veriler

- Kaynak: kullanıcının sağladığı orijinal `IronMan2_1.0.0_ios_2.2.1.ipa`.
- Kaynak grubu: `C1L1_*` isimli 15 BRES/BDAE 0.0.0.133 dosyası; 10 dosyadaki görünür çevre modelleri birleştirildi. Ayrıca çarpışma (`col`) ve `sky` kaynakları tespit edildi fakat GLB'deki görsel sahneye konmadı. `C1L1` adlandırması birinci bölümle güçlü ilişki gösterse de `level1.bclara` ile birebir nesne eşleştirmesi henüz yapılmadı.
- Yeni `bdae_scene_parser.py` gerçek `-mesh` referanslarını okuyarak her alt-mesh için **vertex sayısı/stride/ofseti, üçgen indeksi, malzeme adı ve bounds** bilgilerini ayrıştırır. Yakın uyumlu sonraki sürümlerden hazır format varsaymaz; doğrudan bu IPA'daki kayıtları kullanır.
- BRES mesh header'ında vertex sayısı `+0x10`, vertex stream descriptor `+0x14`, alt mesh sayısı `+0x18`, alt mesh listesi `+0x1C`; bbox `+0x20`. Vertex descriptor'da stride `+0x00`, veri ofseti `+0x14`. Alt mesh kayıtları **56 bayt**; triangle count `+0x08`, index count `+0x18`, 16-bit indeks verisi ofseti `+0x1C`. Tüm aktarılan indeksler mevcut vertex sayısının altında; indeks adedi 3×üçgen sayısıdır. Her mesh'te konum değerleri sonlu ve dosyanın bbox'ıyla uyumludur.
- Görünür 10 çevre BDAE dosyasından 370 alt-mesh, **37.946 vertex ve 22.919 üçgen** GLB olarak çıkarıldı. Dört çarpışma/gökyüzü dosyası dahil taranan tüm BDAE'larda toplam **24.925 geçerli üçgen** saptandı (bu 3D haritanın tüm objelerinin çözüldüğü anlamına gelmiyor).
- Kaynak koordinatları orijinalde Z-yukarıdır; GLB dosyaları Y-yukarı standardına döndürülmüştür. `IronMan2_C1L1_Original_Geometry_With_MarkVI.glb` içinde gerçek Mark VI model/dokusu yaklaşık (0,0,0) *temsili* konuma yerleştirilmiştir; **orijinal oyuncu spawn noktası doğrulanmış değildir**.

## Açılabilir dosyalar

- `exports/IronMan2_C1L1_Environment_Geometry.glb`: orijinal çevre mesh'leri; geometri gerçek, kategori bazında düz temsili renk.
- `exports/IronMan2_C1L1_Original_Geometry_With_MarkVI.glb`: aynı çevre + kullanıcının IPA'sından elde edilen Mark VI dokulu model (temsili yerleşim).
- `exports/C1L1_original_geometry_oblique.png`: çevre yapı önizlemesi; düz renk, **orijinal oyun ekranı değil**.
- `exports/C1L1_original_geometry_without_ground.png`: zeminin önüne geçtiği yapıları ayrı görmek için deneysel açılı görünüş.
- `exports/geometry_manifest.csv`: alt-mesh bazlı kaynak/ofset/vertex/indeks/bounds listesi.

## Tekrar üretme

Python 3, numpy, trimesh, matplotlib gerektirir. Orijinal IPA'yı kullanın:

```bash
python extract_scene_from_ipa.py /path/to/IronMan2_1.0.0_ios_2.2.1.ipa
python build_scene.py
python preview_scene.py
```

`assets/Iron_man_mark6_textured.glb` (orijinal kullanıcının materyalli modeli) pakette bulunur.

## Henüz çözülmeyen önemli unsurlar

1. Doku atlasları orijinal `textures` arşivinde olmasına rağmen 370 submesh'in **birebir malzeme–doku eşlemesi yapılmadı**; çevre GLB'si özgün doku değil, temsili renklerle geliyor.
2. `level1.bclara` nesne/olay örnekleri ve spawn noktası çözümlenmedi. Tek dosya grubunun gerçek görev sahnesindeki tam sıralaması doğrulanmadı.
3. Bazı BDAE mesh varyantları/geçersiz kayıtlar atlanıyor; **tam harita değil**, özgün koordinatlarda kurtarılmış bir alt küme.
4. Geometri **PS Vita'ya henüz gönderilmedi**. Tam ortam yazılımsal raster çiziciye çok ağır gelir; basitleştirme/LOD veya GPU tabanlı çizim sistemi gerekir. Çarpışma, kamera ve orijinal görev mantığı yok.

Bu prototip, önceki B8/B9/B10 VPK'lerinden bağımsızdır; eski çalışan sürümler korunmuştur. Kaynak veriler özel GitHub deposunda tutulmalıdır.
