#!/usr/bin/env python3
"""Read original Iron Man 2 (Gameloft BRES 0.0.0.133) static scene mesh tables.
Mesh tables decoded from BDAE fields and validated against bounding boxes and index bounds.
Never repositions meshes or hallucinates missing geometry.
"""
from pathlib import Path
import zipfile,re,struct,math,json,collections
import numpy as np

ROOT='Payload/IronMan2.app/'

def decode_archive(blob):
 n=struct.unpack_from('<H',blob)[0]; base=2+4*n
 offsets=struct.unpack_from('<'+'I'*n,blob,2)
 assert offsets[0]==0 and offsets[-1]==len(blob)-base
 c=struct.unpack_from('<H',blob,base)[0];assert n==c+2
 names=[];p=base+2
 for i in range(c):
  k=struct.unpack_from('<H',blob,p)[0];p+=2;names.append(blob[p:p+k].decode('latin1'));p+=k
 assert p==base+offsets[1]
 for i,name in enumerate(names):yield name,blob[base+offsets[i+1]:base+offsets[i+2]]

def parse(raw):
 if raw[:4]!=b'BRES' or struct.unpack_from('<I',raw,12)[0]!=len(raw):raise ValueError('BRES integrity')
 U=lambda o:struct.unpack_from('<I',raw,o)[0]
 L=len(raw)
 def st(p):
  if p<=0 or p>=L:return None
  end=raw.find(b'\x00',p,p+150)
  if end<0:return None
  return raw[p:end].decode('latin1','replace')
 wanted={m.start():m.group()[:-1].decode('latin1') for m in re.finditer(rb'[A-Za-z0-9_.-]+-mesh\x00',raw) if raw[m.start()-1:m.start()]!=b'#'}
 found=[];stats=collections.Counter()
 for ofs in range(0x20,L-56,4):
  if U(ofs+4) not in wanted or U(ofs+8)>=L or U(ofs+12)!=1:continue
  name=wanted[U(ofs+4)];friendly=st(U(ofs+8))
  if not friendly or name[:-5]!=friendly:continue
  count=U(ofs+16);vd=U(ofs+20);groups=U(ofs+24);sd=U(ofs+28)
  if not (3<=count<=300000 and 0<groups<=20 and 0<vd<=L-24 and 0<sd<=L-groups*56):continue
  bbox=np.frombuffer(raw,dtype='<f4',count=6,offset=ofs+32).copy()
  if not (np.isfinite(bbox).all() and np.all(bbox[:3]<=bbox[3:])): continue
  stride=U(vd);vpos=U(vd+20)
  if stride not in (12,16,20,24,28,32,36,40,44,48,52,56,60,64,72,80):
   stats['unknown_stride_'+str(stride)]+=1;continue
  if not(0<vpos<L and vpos+count*stride<=L):continue
  vertex=np.frombuffer(raw,dtype=np.dtype((np.void,stride)),count=count,offset=vpos)
  positions=np.ndarray((count,3),dtype='<f4',buffer=vertex,strides=(stride,4)).copy()
  if not np.isfinite(positions).all():continue
  if (np.abs(positions).max()>1000000):continue
  # Bounding-box should cover positions (with tolerance in units)
  diff_lo=bbox[:3]-positions.min(axis=0);diff_hi=positions.max(axis=0)-bbox[3:]
  if max(float(diff_lo.max()),float(diff_hi.max()))>1.0:
   stats['bbox_fail']+=1;continue
  uv=np.zeros((count,2),dtype=np.float32)
  # FVF28 has two 2-float UV sets (20 byte layout has one UV set)
  if stride in (20,28):
   uv=np.ndarray((count,2),dtype='<f4',buffer=vertex,offset=12,strides=(stride,4)).copy()
  elif stride>=32:
   uv=np.ndarray((count,2),dtype='<f4',buffer=vertex,offset=24,strides=(stride,4)).copy()
  if not np.isfinite(uv).all():uv[:]=0
  faces_all=[];submeshes=[];valid=True
  for j in range(groups):
   p=sd+56*j
   nfaces=U(p+8);nindices=U(p+24);idx_ptr=U(p+28)
   if nfaces==0 or nindices!=nfaces*3 or idx_ptr+nindices*2>L or idx_ptr==0:
    valid=False;break
   indices=np.frombuffer(raw,dtype='<u2',count=nindices,offset=idx_ptr).astype(np.int32)
   if indices.max()>=count:valid=False;break
   faces=indices.reshape(-1,3)
   submeshes.append({'material':st(U(p+4)),'faces':faces,'index_offset':idx_ptr})
   faces_all.append(faces)
  if not valid:
   stats['submesh_invalid']+=1;continue
  mesh={'name':name,'vertex_count':count,'faces':np.concatenate(faces_all),'positions':positions,'uv':uv,'submeshes':submeshes,'stride':stride,'bounds':bbox,'mesh_descriptor':ofs,'vertex_offset':vpos}
  found.append(mesh)
 return found,stats

if __name__=='__main__':
 from collections import Counter
 import sys
 inp=Path(sys.argv[1]); meshes,stat=parse(inp.read_bytes());print(inp.name,'mesh count',len(meshes),'submesh count',sum(len(x['submeshes']) for x in meshes),'vert',sum(len(x['positions']) for x in meshes),'tris',sum(len(x['faces']) for x in meshes),'fvf',dict(Counter(m['stride'] for m in meshes)),'errors',dict(stat))
 print([(m['name'],m['vertex_count'],len(m['faces'])) for m in meshes[:5]])
