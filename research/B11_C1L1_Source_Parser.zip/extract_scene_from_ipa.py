#!/usr/bin/env python3
"""Re-extract original C1L1 BDAE scene objects from a personally held Iron Man 2 IPA."""
import sys,zipfile
from pathlib import Path
from bdae_scene_parser import decode_archive
source=Path(sys.argv[1]); dest=Path(__file__).parent/'original_models';dest.mkdir(exist_ok=True)
with zipfile.ZipFile(source) as z:
 objects=dict(decode_archive(z.read('Payload/IronMan2.app/models')))
 for name,content in objects.items():
  if name.startswith('C1L1_') and name.lower().endswith('.bdae'):
   (dest/name).write_bytes(content)
   print(name,len(content))
