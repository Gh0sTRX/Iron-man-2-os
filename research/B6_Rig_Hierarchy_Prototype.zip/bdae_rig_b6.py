#!/usr/bin/env python3
"""Read original BRES/BDAE v0,0,0,133 scene graph nodes for 2010 Iron Man 2.

The 72-byte scene nodes contain three name string pointers, local translation,
local quaternion, local scale, child count and absolute pointer to a packed array
of child nodes (each 72 bytes). This is proven for Mark VI + War Machine; the
skinned mesh's inverse-bind and vertex weights are NOT decoded.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import struct,json,math,argparse,zipfile
from anim_decoder_b6 import ROOT,decode_archive,decode_anim

NODE_SIZE=72

@dataclass
class Node:
    name: str
    offset: int
    parent: str|None
    pos:tuple[float,float,float]
    quat:tuple[float,float,float,float]
    scale:tuple[float,float,float]
    child_count:int


def parse_rig(raw:bytes,root_name='Bip01-node'):
    if raw[:4]!=b'BRES':raise ValueError('unsupported BDAE header')
    bom=struct.unpack_from('<H',raw,4)[0]
    if bom!=0xfffe:raise ValueError(f'BOM {bom}')
    file_size=struct.unpack_from('<I',raw,12)[0]
    if file_size!=len(raw):raise ValueError('bad BDAE total size')
    model_version_ptr=struct.unpack_from('<I',raw,28)[0]
    version_string_offset=struct.unpack_from('<I',raw,model_version_ptr)[0]
    version=raw[version_string_offset:].split(b'\x00')[0].decode('latin-1')
    if version!='0,0,0,133':raise ValueError(f'unvalidated BDAE version {version}')
    target=root_name.encode()+b'\0'
    start=raw.find(target)
    if start<0:raise ValueError(f'cannot find root name {root_name}')
    locations=[];target_bytes=struct.pack('<I',start)
    c=0
    while True:
        i=raw.find(target_bytes,c)
        if i<0:break
        if i>=32 and i<NODE_SIZE+len(raw) and i+NODE_SIZE<=len(raw):locations.append(i)
        c=i+1
    if len(locations)!=1:raise ValueError(f'expected one root node ref, found {locations}')
    root=locations[0];nodes={};stack=set()
    def visit(o, parent=None):
        if o in stack:raise ValueError('cycle in scene graph')
        if o in nodes:raise ValueError('unexpected duplicate scene node')
        if not (0<=o<=len(raw)-NODE_SIZE):raise ValueError('node outside file')
        ptr=struct.unpack_from('<I',raw,o)[0]
        if not (0<ptr<len(raw)):raise ValueError('bad name ptr')
        end=raw.find(b'\0',ptr)
        if end<ptr or end>ptr+200:raise ValueError('name not terminated')
        name=raw[ptr:end].decode('latin-1')
        pos=struct.unpack_from('<3f',raw,o+12)
        quat=struct.unpack_from('<4f',raw,o+24)
        scale=struct.unpack_from('<3f',raw,o+40)
        cc,offs=struct.unpack_from('<II',raw,o+52)
        if cc>32:raise ValueError(f'bad child count {cc} at {o}')
        if cc and (offs<0 or offs+cc*NODE_SIZE>len(raw)):raise ValueError('bad child block')
        if any(not math.isfinite(x) for x in pos+quat+scale):raise ValueError('nonfinite transform')
        if not .95<math.sqrt(sum(x*x for x in quat))<1.05:raise ValueError('non-unit bind quaternion')
        if name in (n.name for n in nodes.values()):raise ValueError('duplicate node name '+name)
        nodes[o]=Node(name,o,parent,pos,quat,scale,cc)
        stack.add(o)
        for c in range(cc):visit(offs+c*NODE_SIZE,name)
        stack.remove(o)
    visit(root)
    return {'version':version,'node_count':len(nodes),'root':root_name,'nodes':[asdict(n) for n in nodes.values()]}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('ipa',type=Path)
    p.add_argument('--model',choices=['Iron_man_mark6.bdae','warmachine.bdae'],default='Iron_man_mark6.bdae')
    p.add_argument('--out',type=Path,default=Path('rig.json'))
    args=p.parse_args()
    with zipfile.ZipFile(args.ipa) as z:
        models=dict(decode_archive(z.read(ROOT+'models')))
    rig=parse_rig(models[args.model]);args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(rig,indent=2),encoding='utf-8')
    print(args.model,'nodes',rig['node_count'],'output',args.out)
if __name__=='__main__':main()
