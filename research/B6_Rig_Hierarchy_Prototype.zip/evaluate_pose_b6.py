#!/usr/bin/env python3
"""Rig-local diagnostic (original node hierarchy + original .anim TR/Q channels).

This evaluates joint WORLD positions. No vertex skinning/mesh weights. Quaternion
component order assumed x,y,z,w based on original BDAE bind rotations; verify
against original model animation output before declaring parity.
"""
from __future__ import annotations
import argparse,json,math,sys,zipfile
from pathlib import Path
from anim_decoder_b6 import ROOT,decode_archive,decode_anim
from bdae_rig_b6 import parse_rig

def lerp(a,b,t):return tuple((1-t)*x+t*y for x,y in zip(a,b))
def normalize(q):
 norm=math.sqrt(sum(x*x for x in q))
 return tuple(x/norm for x in q)
def sample(chan,ms,quat=False):
 vv=chan.values
 if len(vv)==1 or ms<=vv[0][0]:return normalize(vv[0][1]) if quat else vv[0][1]
 if ms>=vv[-1][0]:return normalize(vv[-1][1]) if quat else vv[-1][1]
 for k in range(1,len(vv)):
  if vv[k][0]>=ms:
   a,b=vv[k-1],vv[k];t=(ms-a[0])/(b[0]-a[0]);u,v=a[1],b[1]
   if quat:
    if sum(x*y for x,y in zip(u,v))<0:v=tuple(-x for x in v)
    return normalize(lerp(u,v,t))
   return lerp(u,v,t)
 raise ValueError('no frame')
def mul(a,b):
 x,y,z,w=a;X,Y,Z,W=b
 return (w*X+x*W+y*Z-z*Y, w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z)
def rotate(q,v):
 x,y,z,w=q;vx,vy,vz=v
 u=(y*vz-z*vy,z*vx-x*vz,x*vy-y*vx)
 v2=(y*u[2]-z*u[1],z*u[0]-x*u[2],x*u[1]-y*u[0])
 return tuple(v[i]+2*(w*u[i]+v2[i]) for i in range(3))

def pose(rig,anim,ms):
 animdata={n:(t,r) for n,t,r in zip(anim.names,anim.translations,anim.rotations)}
 worlds={};out=[]
 for node in rig['nodes']:
  nodename=node['name'];basename=nodename.removesuffix('-node')
  lp=node['pos'];lq=node['quat'];ls=node['scale']
  if nodename.endswith('-node') and basename in animdata:
   t,r=animdata[basename]
   lp=sample(t,ms,False);lq=sample(r,ms,True)
  par=node['parent']
  if par is None:p=(0,0,0);q=(0,0,0,1);s=(1,1,1)
  else:p,q,s=worlds[par]
  worldp=tuple(p[i]+rotate(q,[s[j]*lp[j] for j in range(3)])[i] for i in range(3))
  worldq=normalize(mul(q,lq));worlds[nodename]=(worldp,worldq,tuple(s[i]*ls[i] for i in range(3)))
  out.append({'name':nodename,'parent':par,'xyz':worldp})
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('ipa',type=Path)
 p.add_argument('--model',default='Iron_man_mark6.bdae');p.add_argument('--clip',default='IronMan_Aim_Float_idle.anim')
 p.add_argument('--ms',type=int,default=400);p.add_argument('--out',type=Path,default=Path('pose.json'))
 a=p.parse_args()
 with zipfile.ZipFile(a.ipa) as z:
  models=dict(decode_archive(z.read(ROOT+'models')))
  anims=dict(decode_archive(z.read(ROOT+'anims')))
 rig=parse_rig(models[a.model]);anim=decode_anim(anims[a.clip]);positions=pose(rig,anim,a.ms)
 important={n['name']:n['xyz'] for n in positions if n['name'] in ['Bip01-node','Bip01_Head-node','Bip01_L_UpperArm-node','Bip01_L_Hand-node','Bip01_R_Hand-node','Bip01_L_Foot-node','Bip01_R_Foot-node']}
 a.out.write_text(json.dumps({'rig':a.model,'clip':a.clip,'time_ms':a.ms,'nodes':positions},indent=2))
 print('world joints',len(positions),'time',a.ms,'important',important)
if __name__=='__main__':main()
