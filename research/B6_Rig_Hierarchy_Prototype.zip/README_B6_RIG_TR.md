# B6 Rig Hiyerarşisi — Orijinal 2010 `.bdae` Model Bağlantıları

Kaynak: Kullanıcının orijinal iOS v1.0.0 IPA'sındaki `Iron_man_mark6.bdae` ve `warmachine.bdae`.

## Doğrulanan özgün BRES/BDAE `0,0,0,133` sahne düğümü biçimi

Header: `BRES`, little-endian, BOM `FE FF`. BDAE model bilgisi offsetindeki ilk `u32` eski sürümün versiyon metnine işaret eder. Bu modelde sürüm `0,0,0,133`.

Sahne düğümü **72 bayt**:

| Göreli bayt | Tip | Anlam |
| --- | --- | --- |
| 0x00 | u32 | null-terminated sahne düğümü adının adresi |
| 0x04, 0x08 | u32 ×2 | diğer string göstergeleri |
| 0x0C | f32 ×3 | yerel konum |
| 0x18 | f32 ×4 | yerel quaternion, sayısal olarak yaklaşık birim uzunlukta |
| 0x28 | f32 ×3 | yerel ölçek |
| 0x34 | u32 | doğrudan çocuk sayısı |
| 0x38 | u32 | çocuk düğümlerinin mutlak offseti (çocuklar 72 bayt aralıklarla saklı) |
| 0x3C–0x47 | 12 bayt | henüz yorumlanmamış ek alanlar |

Bu şema, **Mark VI için 96**, **War Machine için 112** düğümü tam ebeveyn-çocuk ilişkileriyle okuyup sayısal geçerlilik sınamalarından geçirdi. Grafik bir ağaç oluşturuyor, mükerrer ad/cycle yok, konum/dönüş/ölçek değerleri sonlu.

Animasyonun `Bip01_L_UpperArm`, modelde `Bip01_L_UpperArm-node` ile eşleşir. Iron Man kliplerinin 31/37 fiziksel olmayan dosya yolundan ayrılmış isimleri bu kök ağaçta; War Machine Fly-M klibinin 38/41 benzer ismi bu ağaçta. Diğer animasyon isimleri ek sahne kaynakları, yardımcı hedefler veya kök ağacın dışındaki nesneler olabilir.

## Gerçek animasyon + gerçek rig poz hesaplaması

`evaluate_pose_b6.py` animasyon konum ve quaternion değerlerini doğru isimli düğümlere yazar, quaternion çarpımı ve döndürme ile ebeveyn dönüşümlerini birleştirip **dünya koordinatlarında kemik bağlantılarını hesaplar**. Bu işlemi hem Mark VI hem War Machine üzerinde çalıştırdık.

- `IronMan_AirLand_Original_Rig_B6.gif` — **orijinal 800ms iniş**; 31 örnekleme, gerçek kemik pozlarının tel-iskelet animasyonu.
- `WarMachine_Hover_Original_Rig_B6.gif` — **orijinal 1600ms uçuşta bekleme**; 31 örnekleme, gerçek kemik pozları.
- Bu GIF'ler **orijinal oyunun ekran görüntüsü değil**; kendi tanılama aracımızın çıkışı. Ham quaternion bileşen sıralamasının gerçek motorla tam uyumluluğu hâlâ görsel olarak kontrol edilmelidir.

## Henüz çözmediğimiz asıl mesele

**Mesh skinning**: gerçek zırhın her vertexini hangi kemiklerin ve hangi ağırlıkların etkilediğini henüz bilmiyoruz. Rig ve animasyon dönüyor ama zırhın dış poligonları kemiklere bağlı değil. Ayrıca inverse bind pose verileri / rig bind matrisi doğrulanmalı. Tam orijinal animasyonlu Vita VPK'si hâlâ üretilmedi. Mevcut B4/B5 çalışan demolarını değiştirmeyin.

## Çalıştırma

```bash
python bdae_rig_b6.py IronMan2_1.0.0_ios_2.2.1.ipa --model Iron_man_mark6.bdae --out rig_mark6.json
python evaluate_pose_b6.py IronMan2_1.0.0_ios_2.2.1.ipa --model warmachine.bdae --clip Warmachine_Aim_Fly_M.anim --ms 800 --out worldpose.json
python export_skeleton_gif.py IronMan2_1.0.0_ios_2.2.1.ipa warmachine.bdae Warmachine_Aim_Float_idle.anim wm.gif Z
```

`bdae_rig_b6.py`, `evaluate_pose_b6.py`, `export_skeleton_gif.py` diğer `anim_decoder_b6.py` modülünü gerektirir. Python 3 ve GIF için `Pillow` gereklidir.
