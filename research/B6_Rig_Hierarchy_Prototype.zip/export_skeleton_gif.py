#!/usr/bin/env python3
"""Render unskinned skeletal hierarchy diagnostics from authentic .anim + .bdae."""
import sys,zipfile,math
from pathlib import Path
from PIL import Image,ImageDraw
from anim_decoder_b6 import ROOT,decode_archive,decode_anim
from bdae_rig_b6 import parse_rig
from evaluate_pose_b6 import pose

def make(ipa,model,clip,output,vertical='Z'):
 with zipfile.ZipFile(ipa) as z:models=dict(decode_archive(z.read(ROOT+'models')));anims=dict(decode_archive(z.read(ROOT+'anims')))
 rig=parse_rig(models[model]);anim=decode_anim(anims[clip]);
 times=[int(i*anim.duration_ms/30) for i in range(31)]
 frames=[];ys=[];xs=[]
 for t in times:
  bones={n['name']:n for n in pose(rig,anim,t) if n['name'].startswith('Bip01') and n['name'].endswith('-node') and n['name']!='Bip01_Footsteps-node'}
  frames.append(bones)
  for bone in bones.values():
   x,y,z=bone['xyz'];xs.append(y);ys.append(x if vertical=='X' else z)
 xmin,xmax=min(xs),max(xs);ymin,ymax=min(ys),max(ys)
 w,h=720,530;scale=min((w-150)/(xmax-xmin),(h-140)/(ymax-ymin));mx=(xmin+xmax)/2;my=(ymin+ymax)/2
 pictures=[]
 for idx,bones in enumerate(frames):
  im=Image.new('RGB',(w,h),'#0b1928');d=ImageDraw.Draw(im)
  for v in range(0,w,36):d.line((v,0,v,h),fill='#152b3d')
  for v in range(0,h,36):d.line((0,v,w,v),fill='#152b3d')
  def proj(b):
   a=b['xyz'];return int(w*.5+(a[1]-mx)*scale),int(h*.51+((a[0] if vertical=='X' else a[2])-my)*scale)
  for bone in bones.values():
   par=bone['parent']
   if par in bones:
    d.line((*proj(bones[par]),*proj(bone)),fill='#75dce8',width=5)
  for bone in bones.values():
   x,y=proj(bone);d.ellipse((x-4,y-4,x+4,y+4),fill='#eecf8d')
  d.text((16,12),f'IRON MAN 2 · ORIGINAL {clip.replace(".anim", "")[:45]}',fill='#f3e8c9')
  d.text((16,36),f'Original BDAE rig + authentic ANIM keyframes | {times[idx]} / {anim.duration_ms} ms',fill='#a5c6d6')
  d.text((16,h-26),'SKELETON DATA PREVIEW • NOT SKINNED ARMOR • NO VPK YET',fill='#93afc4')
  pictures.append(im)
 out=Path(output);out.parent.mkdir(parents=True,exist_ok=True)
 pictures[0].save(out,save_all=True,append_images=pictures[1:],duration=46,loop=0,optimize=True)
 print(out,'frames',len(pictures),'size',out.stat().st_size)

if __name__=='__main__':
 if len(sys.argv)<5:raise SystemExit('Usage: script ipa model.bdae clip.anim output.gif [X|Z]')
 make(*sys.argv[1:])
