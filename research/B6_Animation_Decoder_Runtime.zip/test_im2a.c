#include "im2a_player.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void show(IM2Joint *j,int time){float p[3],q[4];im2_evaluate(j,time,p,q);float n=0;for(int k=0;k<4;k++)n+=q[k]*q[k];printf("t=%d node=%s pos=(%.6f %.6f %.6f) quat=(%.6f %.6f %.6f %.6f) length=%.6f\n",time,j->name,p[0],p[1],p[2],q[0],q[1],q[2],q[3],sqrtf(n));if(fabsf(n-1)>0.001f)exit(5);}
int main(int argc,char**argv){
 if(argc<3){fprintf(stderr,"Usage: %s clip.im2a JointName [time_ms]\n",argv[0]);return 1;}
 IM2Clip c;int e=im2_load(argv[1],&c);if(e){fprintf(stderr,"load error %d\n",e);return 2;}
 int id=im2_find(&c,argv[2]);if(id<0){fprintf(stderr,"No such node %s\n",argv[2]);im2_free(&c);return 3;}
 printf("IM2A clip: %u joints; %d ms\n",c.joint_count,c.duration_ms);
 int sampletime=argc>3?atoi(argv[3]):-1;
 if(sampletime>=0)show(&c.joints[id],sampletime);
 else {show(&c.joints[id],0);show(&c.joints[id],c.duration_ms/2);show(&c.joints[id],c.duration_ms);}
 im2_free(&c);return 0;
}
