#ifndef IRONMAN_IM2A_PLAYER_H
#define IRONMAN_IM2A_PLAYER_H
#include <stddef.h>
#include <stdint.h>

typedef struct { int32_t ms; float p[3]; } IM2PositionFrame;
typedef struct { int32_t ms; float q[4]; } IM2RotationFrame;
typedef struct {
    char* name;
    uint16_t pos_count,rot_count;
    IM2PositionFrame* positions;
    IM2RotationFrame* rotations;
} IM2Joint;
typedef struct { uint16_t joint_count; int32_t duration_ms; IM2Joint* joints; } IM2Clip;

// Return 0 on success; on failure return nonzero and leave clip empty.
int im2_load(const char* filename,IM2Clip* out);
void im2_free(IM2Clip* clip);
int im2_find(const IM2Clip* clip,const char* name);
void im2_evaluate(const IM2Joint* joint,int32_t time_ms,float out_pos[3],float out_quat[4]);
#endif
