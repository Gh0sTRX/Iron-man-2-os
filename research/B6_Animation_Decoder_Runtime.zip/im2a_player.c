#include "im2a_player.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int r_u16(FILE *f,uint16_t *v){unsigned char b[2];if(fread(b,1,2,f)!=2)return 0;*v=(uint16_t)(b[0]|(b[1]<<8));return 1;}
static int r_i16(FILE *f,int16_t *v){uint16_t u;if(!r_u16(f,&u))return 0;*v=(int16_t)u;return 1;}
static int r_i32(FILE *f,int32_t *v){unsigned char b[4];if(fread(b,1,4,f)!=4)return 0;uint32_t u=(uint32_t)b[0]|((uint32_t)b[1]<<8)|((uint32_t)b[2]<<16)|((uint32_t)b[3]<<24);*v=(int32_t)u;return 1;}
static int r_f32(FILE *f,float *v){int32_t bits;if(!r_i32(f,&bits))return 0;uint32_t raw=(uint32_t)bits;memcpy(v,&raw,sizeof(float));return isfinite(*v);}
static float clamp01(float t){return t<0.0f?0.0f:t>1.0f?1.0f:t;}
static void normalize(float q[4]){float sum=0;for(int k=0;k<4;k++)sum+=q[k]*q[k];if(sum<1e-12f){q[0]=q[1]=q[2]=0.0f;q[3]=1.0f;return;}float inv=1.0f/sqrtf(sum);for(int k=0;k<4;k++)q[k]*=inv;}

void im2_free(IM2Clip* clip){if(!clip)return;if(!clip->joints){memset(clip,0,sizeof(*clip));return;}for(unsigned i=0;i<clip->joint_count;i++){free(clip->joints[i].name);free(clip->joints[i].positions);free(clip->joints[i].rotations);}free(clip->joints);memset(clip,0,sizeof(*clip));}
int im2_load(const char* filename,IM2Clip* out){
 if(!out||!filename)return 1;
 memset(out,0,sizeof(*out));
 FILE *f=fopen(filename,"rb");if(!f)return 2;
 unsigned char magic[4];uint16_t ver=0,num=0;int32_t dur=0;
 if(fread(magic,1,4,f)!=4||memcmp(magic,"IM2A",4)!=0||!r_u16(f,&ver)||ver!=1||!r_u16(f,&num)||num==0||num>512||!r_i32(f,&dur)||dur<0||dur>1800000)goto bad;
 out->joint_count=num;out->duration_ms=dur;
 out->joints=calloc(num,sizeof(IM2Joint));if(!out->joints)goto bad;
 for(unsigned i=0;i<num;i++){
  IM2Joint *j=&out->joints[i];uint16_t namebytes=0;
  if(!r_u16(f,&namebytes)||namebytes==0||namebytes>2048)goto bad;
  j->name=malloc((size_t)namebytes+1);if(!j->name||fread(j->name,1,namebytes,f)!=namebytes)goto bad;
  j->name[namebytes]=0;
  if(!r_u16(f,&j->pos_count)||!r_u16(f,&j->rot_count)||j->pos_count<1||j->rot_count<1||j->pos_count>2048||j->rot_count>2048)goto bad;
  j->positions=calloc(j->pos_count,sizeof(IM2PositionFrame));j->rotations=calloc(j->rot_count,sizeof(IM2RotationFrame));if(!j->positions||!j->rotations)goto bad;
  for(unsigned k=0;k<j->pos_count;k++){
   IM2PositionFrame *v=&j->positions[k];if(!r_i32(f,&v->ms)|| (k&&v->ms<=j->positions[k-1].ms))goto bad;
   for(int z=0;z<3;z++)if(!r_f32(f,&v->p[z]))goto bad;
  }
  for(unsigned k=0;k<j->rot_count;k++){
   IM2RotationFrame *v=&j->rotations[k];if(!r_i32(f,&v->ms)|| (k&&v->ms<=j->rotations[k-1].ms))goto bad;
   for(int z=0;z<4;z++){int16_t q;if(!r_i16(f,&q))goto bad;v->q[z]=(float)q/32767.0f;}
   normalize(v->q);
  }
 }
 if(fgetc(f)!=EOF)goto bad;
 fclose(f);return 0;
 bad:fclose(f);im2_free(out);return 3;
}
int im2_find(const IM2Clip* clip,const char* name){if(!clip||!name)return -1;for(unsigned i=0;i<clip->joint_count;i++)if(!strcmp(clip->joints[i].name,name))return (int)i;return -1;}
void im2_evaluate(const IM2Joint* j,int32_t ms,float out_p[3],float out_q[4]){
 if(!j||!j->pos_count||!j->rot_count)return;
 unsigned a=0;while(a+1<j->pos_count&&j->positions[a+1].ms<=ms)a++;
 unsigned b=(a+1<j->pos_count)?a+1:a;
 float factor=a==b?0.0f:clamp01((ms-j->positions[a].ms)/(float)(j->positions[b].ms-j->positions[a].ms));
 for(int k=0;k<3;k++)out_p[k]=j->positions[a].p[k]*(1.0f-factor)+j->positions[b].p[k]*factor;
 a=0;while(a+1<j->rot_count&&j->rotations[a+1].ms<=ms)a++;
 b=(a+1<j->rot_count)?a+1:a;
 factor=a==b?0.0f:clamp01((ms-j->rotations[a].ms)/(float)(j->rotations[b].ms-j->rotations[a].ms));
 float dot=0;for(int k=0;k<4;k++)dot+=j->rotations[a].q[k]*j->rotations[b].q[k];
 float sign=dot<0?-1.0f:1.0f;
 for(int k=0;k<4;k++)out_q[k]=j->rotations[a].q[k]*(1.0f-factor)+sign*j->rotations[b].q[k]*factor;
 normalize(out_q);
}
