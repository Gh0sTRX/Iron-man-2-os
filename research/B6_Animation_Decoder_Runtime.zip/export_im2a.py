#!/usr/bin/env python3
"""Convert selected original .anim clips into compact PS Vita-friendly IM2A data.

Data stays derived from the user's IPA; do not publish content without rights.
"""
import argparse,struct,zipfile
from pathlib import Path
from anim_decoder_b6 import decode_archive,decode_anim,ROOT

def encode_clip(clip):
    if len(clip.names)>65535:raise ValueError('Too many joints')
    dest=bytearray(struct.pack('<4sHHi',b'IM2A',1,len(clip.names),clip.duration_ms))
    for name,trans,rot in zip(clip.names,clip.translations,clip.rotations):
        n=name.encode('utf8')
        if len(n)>65535 or len(trans.values)>65535 or len(rot.values)>65535:raise ValueError('Too many entries')
        dest.extend(struct.pack('<H',len(n)));dest.extend(n)
        dest.extend(struct.pack('<HH',len(trans.values),len(rot.values)))
        for t,v in trans.values:dest.extend(struct.pack('<i3f',t,*v))
        for t,v in rot.values:
            q=[max(-32768,min(32767,round(x*32767))) for x in v]
            dest.extend(struct.pack('<i4h',t,*q))
    return bytes(dest)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('ipa',type=Path)
    p.add_argument('--dest',type=Path,default=Path('clips'))
    p.add_argument('--name',action='append',default=[])
    a=p.parse_args()
    with zipfile.ZipFile(a.ipa) as z:
        clips=dict(decode_archive(z.read(ROOT+'anims')))
    a.dest.mkdir(parents=True,exist_ok=True)
    if not a.name: raise SystemExit('Use --name clip.anim (repeatable)')
    for name in a.name:
        if name not in clips:raise SystemExit(f'clip not found: {name}')
        anim=decode_anim(clips[name]);data=encode_clip(anim)
        out=a.dest/Path(name).with_suffix('.im2a').name
        out.write_bytes(data)
        print(out.name,len(data),'bones',len(anim.names),'duration',anim.duration_ms)

if __name__=='__main__':main()
