#!/usr/bin/env python3
import subprocess,zipfile,sys,math,random,re,struct
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from anim_decoder_b6 import decode_archive,decode_anim,ROOT
from export_im2a import encode_clip
ipa=sys.argv[1];tool=str(Path(__file__).parent/'test_im2a')
with zipfile.ZipFile(ipa) as z: clips=dict(decode_archive(z.read(ROOT+'anims')))
selected=['IronMan_Aim_Float_idle.anim','IronMan_Air_land.anim','IronMan_Aim_Ground_move_F.anim','Warmachine_Aim_Fly_M.anim','Warmachine_Aim_Float_idle.anim']
assert len(clips)==972
for name in selected:
 original=decode_anim(clips[name]);p=Path(__file__).parent/'clips'/name.replace('.anim','.im2a');data=p.read_bytes()
 assert encode_clip(original)==data,('different bytes',name)
 for i in [0,len(original.names)//2,len(original.names)-1]:
  joint=original.names[i]
  for t in [0,original.duration_ms//2,original.duration_ms]:
   result=subprocess.run([tool,str(p),joint,str(t)],capture_output=True,text=True)
   assert result.returncode==0,(name,joint,result.stdout,result.stderr)
 print(f'PASS {name}: exact IM2A round-trip, 9 C sampling tests')
print('PASS 45 native C sampling tests plus 5 lossless IM2A serializations')
