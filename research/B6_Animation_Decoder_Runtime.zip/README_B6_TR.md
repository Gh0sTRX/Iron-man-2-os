# Iron Man 2 – B6 | Gerçek Orijinal Animasyon Çözücüsü

Tarih: **2026-10-12**. Birincil kaynak: `IronMan2_1.0.0_ios_2.2.1.ipa`, SHA-256 `4c338c71cdd2817afb10099b90834c911d3c82e94adc477f24a9f9f4e0479c94`.

İkinci kaynak: `Iron Man 2 iOS 3.0.ipa` (oyun sürümü 1.0.3), SHA-256 `a118b887cb59f76268ef1814a84a8b64812f218a636002ebd953d60e885356ec`.

## Ne gerçekten çözüldü?

- IPA'daki `Payload/IronMan2.app/anims` arşivi içindeki **972 animasyonun tamamı**, her birinin girişinden son baytına kadar geçerli biçimde ayrıştırıldı (972/972; kalan byte 0).
- Her animasyon: `u16 name_count`, ardından uzunlukla kodlanmış isimler, her isim için **konum kanalı**, sonra her isim için **dönüş kanalı** içeriyor.
- Konum: statik `u8=1 + f32×3`; hareketli `u8=0 + u16 keycount + keycount×(i32 milisaniye + 3×f32)`.
- Dönüş: statik `u8=1 + i16×4`; hareketli `u8=0 + u16 keycount + keycount×(i32 milisaniye + 4×i16)`. Dört bileşen **yaklaşık birim uzunluklu quaternion** oluşturuyor; `i16 / 32767` ile normalize ediliyor. Oyunun quaternion bileşen sıralaması / model uzayı bağımsız görsel karşılaştırmayla henüz kesinleştirilmedi.
- Ön kare istisnası: `Enemy_jump_spider_Afraid_Move_Back.anim` klibinde negatif zamanlar var (-66 ve -33 ms); signed `i32` gerektiriyor.
- Çözülen toplam **962.221** sabit veya keyframed kanal değeri; bunların 5.419'u hareketli konum kanalı, 18.619'u hareketli quaternion kanalı. Tüm quaternion örnekleri sayısal olarak kontrol edildi.
- **v1.0.3 ikinci IPA: 989/989 animasyon aynı çözücüyle eksiksiz ayrıştırıldı.** v1.0.0 ile ortak **972 klip bayt düzeyinde birebir aynı**; 17 yeni klip yalnızca `man1_*_IPad.anim` ve `woman1_*_IPad.anim` adlarını taşıyor.

## Üretilen ve gerçekten test edilen araçlar

- `anim_decoder_b6.py`: **her iki IPA'nın toplam 972/989 animasyonunun** tam transform çözücüsü, istatistik/CSV ve tek dosya JSON dışa aktarımı.
- `export_im2a.py`: tek bir `.anim` dosyasını gerçek zamanlı Vita C koduna uygun **IM2A** biçimine aktarır.
- `im2a_player.c`, `.h`: C11 quaternion ve pozisyon interpolasyonu (shortest-path normalized linear interpolation), signed milisaniye desteği. 3D iskelet skinning'i henüz yok.
- `test_im2a.c`: konsoldan kemiğin belli ms değerindeki sayısal durumunu yazdırır.
- `verify_b6.py`: beş orijinal klipte `IM2A` ikili veri birebir tekrar üretim testi ve **45** gerçek C örnekleme testi.
- `IronMan2_B6_Orijinal_Animasyon_Hareket_Goruntuleyici.html`: basit çizimle kemik eksen dönüşü/time curve görüntüleyen **bağımsız çevrimdışı teşhis sayfası**. Orijinal zırhı oynatıyor gibi göstermez.
- `clips/*.im2a`: orijinal kliplerin küçük özel çalışma biçimindeki verileri. **Özel proje içinde tut; kamuya dağıtma.**

## Windows / Linux kullanım

```bash
python anim_decoder_b6.py IronMan2_1.0.0_ios_2.2.1.ipa --csv stats.csv
python export_im2a.py IronMan2_1.0.0_ios_2.2.1.ipa --dest clips --name Warmachine_Aim_Fly_M.anim
cc -O2 -std=c11 im2a_player.c test_im2a.c -lm -o test_im2a
./test_im2a clips/Warmachine_Aim_Fly_M.im2a Bip01_L_UpperArm 800
```

## Çok önemli açık işler

1. Orijinal `.bdae` içinden **ebeveyn kemik hiyerarşisi, bind pose, inverse-bind matrisleri, vertex weight/joint index** bilgilerini çıkartmak.
2. Hareketli quaternion bileşen sırasını ve lokal dönüş uzayını asıl oyun görüntüsü / ayrıştırılmış rig ile kıyaslamak.
3. Sadece bir animasyonu (`IronMan_Aim_Float_idle` veya `Warmachine_Aim_Fly_M`) doğru kemiklere bağlayıp gerçek PS Vita'da zırh kol/bacak animasyonu test etmek.
4. Vita'da performans: B4 gerçek 13–15 FPS idi; optimize B5'in CPU/SDL sayaçlarının gerçek cihaz sonucu **henüz bekleniyor**. Tam oyuna değil önce stabil 30 FPS hedefine odaklan.
5. Etkiler, hareket sistemi, çarpışma, repulsor ateşi, harita, görev, orijinal oyun mantığı hâlâ ayrıca portlanmalı.

**Bu sürüm PS Vita VPK DEĞİL**. C animasyon verisi çözümü ve masaüstü doğrulama paketidir. Mevcut çalışan B4/B5 dosyalarını koru.
