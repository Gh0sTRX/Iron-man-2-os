import sys,struct,numpy as np,itertools
sys.path.insert(0,'/mnt/data/ironman_b6_work')
from bdae_rig_b6 import parse_rig
from scipy.spatial.transform import Rotation
for model,matbase,bonecount in [('Iron_man_mark6',0xb8dc,25),('warmachine',0x12acc,29)]:
 b=open('/mnt/data/ironman_b6_work/samples/'+model+'.bdae','rb').read();rig=parse_rig(b);mat=np.frombuffer(b,dtype='<f4',count=bonecount*16,offset=matbase).reshape(-1,4,4)
 targets={}
 for n in rig['nodes']:
  p=struct.unpack_from('<I',b,n['offset']+8)[0];t=b[p:b.find(b'\0',p)] if 0<p<len(b) else b''
  if t.startswith(b'Bone') and t[4:].isdigit():
   k=int(t[4:])-1;targets[n['name']]=np.linalg.inv(mat[k].T)[:3,3]
 out=[]
 for perm in itertools.permutations(range(4)):
  for order in ['parent_local','local_parent']:
   for transpose in [False,True]:
    for initial in [False,True]:
     W={};err=[]
     for n in rig['nodes']:
      q=np.array(n['quat'])[list(perm)]
      q=q /np.linalg.norm(q)
      if transpose:q[:3]*=-1
      M=np.eye(4);M[:3,:3]=Rotation.from_quat(q).as_matrix();M[:3,3]=n['pos']
      if n['parent'] is None:
       W[n['name']]=np.linalg.inv(M) if initial else M
      elif order=='parent_local':W[n['name']]=W[n['parent']]@M
      else:W[n['name']]=M@W[n['parent']]
      if n['name'] in targets:
       err.append(np.linalg.norm(W[n['name']][:3,3]-targets[n['name']]))
     out.append((np.median(err),np.mean(err),np.max(err),perm,order,transpose,initial))
 print(model,'best 15',*sorted(out)[:15],sep='\n')
