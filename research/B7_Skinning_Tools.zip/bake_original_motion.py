#!/usr/bin/env python3
"""Bake authentic animation transforms into CPU-friendly IM2V vertex streams.

Each frame is derived using original 2010 .anim transform tracks and BDAE
skin weights, not AI fabricated or procedural animation. Streaming animation is
a deliberate performance optimization for PS Vita's software renderer.
"""
import sys,struct,math,zipfile,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).parent))
from animate_skin import prepare,deform,ROOT
from anim_decoder_b6 import decode_anim, decode_archive, ROOT as IPA_ROOT

def bake(outdir):
 specs=[
 ('Iron_man_mark6','IronMan_Aim_Float_idle','mark6_hover'),
 ('Iron_man_mark6','IronMan_Aim_Ground_move_F','mark6_walk'),
 ('Iron_man_mark6','IronMan_Air_land','mark6_land'),
 ('warmachine','Warmachine_Aim_Float_idle','warmachine_hover'),
 ('warmachine','Warmachine_Aim_Ground_move_F','warmachine_walk'),
 ('warmachine','Warmachine_Aim_Fly_M','warmachine_fly')]
 outdir.mkdir(parents=True,exist_ok=True)
 cached={}
 ret=[]
 for model,clip,dest in specs:
  if model not in cached:cached[model]=prepare(model)
  setup=cached[model]
  clipfile=ROOT/(clip+'.anim')
  if clipfile.is_file():blob=clipfile.read_bytes()
  else:
   with zipfile.ZipFile('/mnt/data/IronMan2_1.0.0_ios_2.2.1.ipa') as zin:
    blob=dict(decode_archive(zin.read(IPA_ROOT+'anims')))[clip+'.anim']
  anim=decode_anim(blob)
  ms=anim.duration_ms;fps=20
  ticks=list(range(0,ms,50));ticks.append(ms)
  frames=np.asarray([deform(setup,anim,t) for t in ticks],dtype='<f4')
  if not np.isfinite(frames).all():raise ValueError('Non finite vertices')
  # Make sure animation is not a constant pose and not exploding out of model bounds
  span=np.max(np.abs(frames-frames[0]));
  if span<1e-5:raise ValueError('not animated: '+clip)
  with (outdir/(dest+'.im2v')).open('wb') as f:
   f.write(struct.pack('<4s4I',b'IM2V',len(setup['vertices']),len(ticks),fps,ms))
   f.write(frames.tobytes())
  blob=(outdir/(dest+'.im2v')).read_bytes()
  assert len(blob)==20+len(ticks)*len(setup['vertices'])*12
  info={'name':dest,'clip':clip,'model':model,'frames':len(ticks),'ms':ms,'size':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'max_vertex_movement':round(float(span),4)}
  print(info);ret.append(info)
 return ret
if __name__=='__main__':
 import json
 result=bake(Path('/mnt/data/ironman_b7_skinning/b7_build/animations'))
 Path('/mnt/data/ironman_b7_skinning/animation_manifest.json').write_text(json.dumps(result,indent=2))
