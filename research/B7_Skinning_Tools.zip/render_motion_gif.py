#!/usr/bin/env python3
"""Render animated original Iron Man mesh/atlas at selected animation timestamps."""
from pathlib import Path
import subprocess,sys
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,str(Path(__file__).parent))
from animate_skin import prepare,deform,write_im2t,ROOT
from anim_decoder_b6 import decode_anim

BASE=Path(__file__).parent
PREVIEW=Path('/mnt/data/ironman_v4_work/build/im2_preview')

def render(model,clip,out,steps=20):
    p=prepare(model);anim=decode_anim((ROOT/(clip+'.anim')).read_bytes())
    pngs=[]
    for i,t in enumerate(np.linspace(0,anim.duration_ms,steps,endpoint=False,dtype=int)):
        target=BASE/'_frame.im2t';target.write_bytes(write_im2t(p['im2t'],deform(p,anim,int(t))))
        pp=BASE/'_frame.ppm'
        subprocess.run([str(PREVIEW),str(target),str(pp),'3.1','0','1'],check=True,stdout=subprocess.DEVNULL)
        im=Image.open(pp).convert('RGB').resize((480,272))
        d=ImageDraw.Draw(im)
        d.rectangle((300,32,465,53),fill=(8,18,31))
        d.text((309,37),f'Original {t:04d} ms',fill=(119,220,234))
        pngs.append(im)
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    pngs[0].save(out,save_all=True,append_images=pngs[1:],duration=1000//12,loop=0,optimize=True)
    print(out,'frames',len(pngs),'bytes',out.stat().st_size)
    return pngs
if __name__=='__main__':
    a=render('Iron_man_mark6','IronMan_Aim_Float_idle',BASE/'IronMan_Original_Hover_Skinned.gif',18)
    b=render('warmachine','Warmachine_Aim_Fly_M',BASE/'WarMachine_Original_Fly_Skinned.gif',18)
    c=render('Iron_man_mark6','IronMan_Air_land',BASE/'IronMan_Original_Landing_Skinned.gif',14)
    from PIL import ImageOps
    images=[a[0],a[7],b[0],b[7],c[0],c[7]]
    o=Image.new('RGB',(960,816),'#0d1824')
    for i,im in enumerate(images):o.paste(im,((i%2)*480,(i//2)*272))
    o.save(BASE/'B7_3D_OriginalMotion_ContactSheet.png')
