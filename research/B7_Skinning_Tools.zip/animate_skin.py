#!/usr/bin/env python3
"""Skeletal skinning from original Iron Man 2 v0.0.0.133 BDAE/.anim.

Reads real inverse bind, bone palette, weights and rig hierarchy; deforms original
IP2T/GLB 3D meshes. Motion quaternion convention validated against bind matrices.
This is an archival prototype, not the original game's runtime and no VPK here.
"""
from __future__ import annotations
import sys,struct,zipfile,math,argparse
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
sys.path.insert(0,'/mnt/data/ironman_b6_work')
from anim_decoder_b6 import decode_anim
from bdae_rig_b6 import parse_rig
from evaluate_pose_b6 import sample
from skin_parser import decode_skin,map_bones
ROOT=Path('/mnt/data/ironman_b6_work/samples')
VPK=Path('/mnt/data/IronMan2_Perf_B5.vpk')

def load_im2t(data):
    magic,nv,nt,tw,th=struct.unpack_from('<4s4I',data,0)
    if magic!=b'IM2T':raise ValueError('Not IM2T')
    need=20+nv*20+nt*6+tw*th*4
    if len(data)!=need:raise ValueError('Length does not match header')
    verts=np.frombuffer(data,dtype='<f4',count=nv*5,offset=20).reshape(nv,5).copy()
    faces=np.frombuffer(data,dtype='<u2',count=nt*3,offset=20+nv*20).reshape(nt,3).copy()
    if np.max(faces)>=nv:raise ValueError('Invalid triangle index')
    rgba=np.frombuffer(data,dtype='u1',count=tw*th*4,offset=20+nv*20+nt*6).reshape(th,tw,4).copy()
    return verts,faces,rgba

def write_im2t(original,verts):
    out=bytearray(original)
    nv=struct.unpack_from('<I',original,4)[0]
    if verts.shape!=(nv,3):raise ValueError('bad vertex count')
    arr=np.frombuffer(out,dtype='<f4',count=nv*5,offset=20).reshape(nv,5)
    arr[:,:3]=verts.astype('<f4');return bytes(out)

def compose(n,local_q,local_pos):
    q=np.asarray(local_q,dtype='float64').copy()
    q[:3]*=-1  # native BDAE quaternion vector-part sign is opposite scipy x,y,z,w
    q/=np.linalg.norm(q)
    m=np.eye(4,dtype='float64')
    m[:3,:3]=Rotation.from_quat(q).as_matrix()@np.diag(n['scale'])
    m[:3,3]=local_pos
    return m

def eval_world(rig,anim=None,ms=0):
    if anim:
        maps={k:(p,r) for k,p,r in zip(anim.names,anim.translations,anim.rotations)}
    else:maps={}
    worlds={}
    for n in rig['nodes']:
        name=n['name'];basename=name.removesuffix('-node')
        if name.endswith('-node') and basename in maps:
            p,r=maps[basename]
            pos=sample(p,ms,False);q=sample(r,ms,True)
        else:pos,q=n['pos'],n['quat']
        local=compose(n,q,pos)
        worlds[name]=worlds[n['parent']]@local if n['parent'] else local
    return worlds

def prepare(model):
    prefix='mark6' if model=='Iron_man_mark6' else 'warmachine'
    b=(ROOT/(model+'.bdae')).read_bytes()
    rig=parse_rig(b)
    with zipfile.ZipFile(VPK) as z:source=z.read('models/'+prefix+'.im2t')
    verts,faces,tex=load_im2t(source)
    skin=decode_skin(b,len(verts));joint_nodes=map_bones(b,rig,skin)
    # Key check: BDAE rig world matrix * original inverse bind equals identity.
    rest=eval_world(rig)
    errs=[np.max(np.abs(rest[n]@skin['inverse_bind'][i]-np.eye(4))) for i,n in enumerate(joint_nodes)]
    if max(errs)>2e-4:raise ValueError(f'inverse bind/rest disagreement {max(errs)}')
    return dict(name=model,model=prefix,bdae=b,rig=rig,skin=skin,vertices=verts,faces=faces,texture=tex,im2t=source,joints=joint_nodes,bind_error=max(errs))

def deform(setup,anim,ms):
    world=eval_world(setup['rig'],anim,ms)
    skins=np.stack([world[n]@setup['skin']['inverse_bind'][i] for i,n in enumerate(setup['joints'])])
    # For all vertices blend at most two bones; use vectorized batched matrix ops
    pos=setup['vertices'][:,:3]
    coords=np.concatenate([pos,np.ones((len(pos),1))],axis=1)
    indexes=setup['skin']['indices']
    weights=setup['skin']['weights']
    return (np.einsum('vkij,vj,vk->vi',skins[indexes,:,:],coords,weights))[:,:3]

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--model',choices=['Iron_man_mark6','warmachine'],default='Iron_man_mark6');ap.add_argument('--clip',default='IronMan_Air_land');ap.add_argument('--ms',type=int,default=200);ap.add_argument('--out',type=Path,default=Path('/mnt/data/ironman_b7_skinning/frame.im2t'))
    a=ap.parse_args()
    setup=prepare(a.model);anim=decode_anim((ROOT/(a.clip+'.anim')).read_bytes())
    out=deform(setup,anim,a.ms)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_bytes(write_im2t(setup['im2t'],out))
    diff=np.linalg.norm(out-setup['vertices'][:,:3],axis=1)
    print('model',a.model,'clip',a.clip,'ms',a.ms,'rest matrix error',setup['bind_error'],'vertex motion mean',diff.mean(),'max',diff.max(),'unmoved',np.sum(diff<1e-5),'out',a.out)
