#!/usr/bin/env python3
"""Validated skin palette reader for original Gameloft BDAE 0.0.0.133 (Iron Man 2 2010).

The main geometry is interleaved; the skin descriptor is [bone_count, bone ptrs,
16*bone_count float matrix data, weight_float_count, weight_float_table,
vertex_count, uint8 vertex_influence_counts, 2*sum(vertex counts), uint16
interleaved bone palette and weight table indices].
"""
from __future__ import annotations
import struct
import numpy as np
from pathlib import Path

def decode_skin(raw,vertex_count,positions=None):
    matches=[]
    for at in range(0,len(raw)-40,4):
        n_b,n_names,n_mats,p_mats,n_weights,p_weights,n_v,p_counts,n_pairs,p_pairs=struct.unpack_from('<10I',raw,at)
        if n_v!=vertex_count or not (1<=n_b<=128 and n_mats==16*n_b and 1<=n_weights<=128):continue
        if not (n_names+4*n_b<=len(raw) and p_mats+4*n_mats<=len(raw) and p_weights+4*n_weights<=len(raw) and p_counts+n_v<=len(raw) and p_pairs+2*n_pairs<=len(raw)):continue
        if n_pairs<2*n_v or n_pairs>8*n_v:continue
        counts=np.frombuffer(raw,dtype='u1',count=n_v,offset=p_counts)
        if not (np.all((counts>=1)&(counts<=4)) and int(np.sum(counts,dtype=np.int64))*2==n_pairs):continue
        names_p=np.frombuffer(raw,dtype='<u4',count=n_b,offset=n_names)
        names=[]
        for p in names_p:
            if p>=len(raw):break
            en=raw.find(b'\0',int(p));name=raw[p:en].decode('latin1') if en>=p else ''
            if not name.startswith('Bone') or not name[4:].isdigit():break
            names.append(name)
        if len(names)!=n_b:continue
        weights=np.frombuffer(raw,dtype='<f4',count=n_weights,offset=p_weights).copy()
        pairs=np.frombuffer(raw,dtype='<u2',count=n_pairs,offset=p_pairs).reshape(-1,2)
        if not (np.all(np.isfinite(weights)) and np.min(weights)>0 and np.max(weights)<=1.00001 and np.max(pairs[:,0])<n_b and np.max(pairs[:,1])<n_weights):continue
        sums=[];indices=np.zeros((n_v,4),dtype='uint16');w=np.zeros((n_v,4),dtype='float32');c=0
        for i,count0 in enumerate(counts):
            count=int(count0)
            rec=pairs[c:c+count];indices[i,:count]=rec[:,0];w[i,:count]=weights[rec[:,1]];sums.append(np.sum(w[i]));c+=count
        if np.max(np.abs(np.array(sums)-1))>1e-5:continue
        mats=np.frombuffer(raw,dtype='<f4',count=n_b*16,offset=p_mats).reshape(n_b,4,4).copy()
        matches.append(dict(descriptor=at,indices=indices,weights=w,counts=counts.copy(),bone_names=names,inverse_bind=np.transpose(mats,(0,2,1)),weight_values=weights,palette_count=n_b,positions=positions))
    if len(matches)!=1:raise ValueError(f'expected one complete skin descriptor for {vertex_count} vertices, got {len(matches)}')
    return matches[0]

def map_bones(raw,rig,skin):
    names={}
    for n in rig['nodes']:
        q=struct.unpack_from('<I',raw,n['offset']+8)[0]
        if 0<=q<len(raw):
            label=raw[q:raw.find(b'\0',q)].decode('latin1','replace')
            if label in skin['bone_names']:
                if label in names:raise ValueError('nonunique bone named '+label)
                names[label]=n['name']
    if len(names)!=len(skin['bone_names']):raise ValueError(f'only mapped {len(names)} of {len(skin["bone_names"])} joints')
    return [names[x] for x in skin['bone_names']]

if __name__=='__main__':
    import sys
    sys.path.insert(0,'/mnt/data/ironman_b7_skinning');sys.path.insert(0,'/mnt/data/ironman_b6_work')
    from bdae_rig_b6 import parse_rig
    from bres_mesh_exporter import scan_vertex_runs,scan_uv40,scan_color36
    for n in ['Iron_man_mark6','warmachine']:
        raw=Path('/mnt/data/ironman_b6_work/samples/'+n+'.bdae').read_bytes()
        runs=sorted(scan_vertex_runs(raw)+scan_uv40(raw)+scan_color36(raw),key=lambda x:x['count'],reverse=True)
        geom=runs[0];rig=parse_rig(raw);skin=decode_skin(raw,geom['count']);mapping=map_bones(raw,rig,skin)
        print(n,'v',len(skin['counts']),'total influences',int(np.sum(skin['counts'],dtype=np.int64)),'bone count',len(mapping),'weight values',len(skin['weight_values']),'descriptor',hex(skin['descriptor']))
        print('first mapped',mapping[:10]);print('counts',np.unique(skin['counts'],return_counts=True))
