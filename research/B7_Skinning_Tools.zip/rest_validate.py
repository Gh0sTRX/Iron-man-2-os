import sys,struct,numpy as np
sys.path.insert(0,'/mnt/data/ironman_b6_work')
from bdae_rig_b6 import parse_rig
from scipy.spatial.transform import Rotation
from skin_parser import decode_skin,map_bones
for fname,nv in [('Iron_man_mark6',802),('warmachine',1292)]:
 b=open('/mnt/data/ironman_b6_work/samples/'+fname+'.bdae','rb').read(); rig=parse_rig(b); skin=decode_skin(b,nv); joints=map_bones(b,rig,skin)
 world={}
 for node in rig['nodes']:
  t=np.array(node['pos']);q=np.array(node['quat']);q[:3]*=-1
  L=np.eye(4);L[:3,:3]=Rotation.from_quat(q).as_matrix()@np.diag(node['scale']);L[:3,3]=t
  world[node['name']]=world[node['parent']]@L if node['parent'] else L
 er=[]; bone_errors=[]
 for i,n in enumerate(joints):
  M=world[n]@skin['inverse_bind'][i]
  err=np.linalg.norm(M-np.eye(4));er.append(err)
  bone_errors.append((round(err,7),n))
 print(fname,'inverse_bind rest errors: min',min(er),'max',max(er),'mean',np.mean(er),'maxdetail',sorted(bone_errors,reverse=True)[:3])
