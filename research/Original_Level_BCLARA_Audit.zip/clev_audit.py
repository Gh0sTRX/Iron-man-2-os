#!/usr/bin/env python3
"""Read the Gameloft `clev` named archive from a user-owned Iron Man 2 IPA.
Outputs exact 10-entry inventory + binary-safe indicators, never executes game code.
"""
import argparse, csv, hashlib, re, struct, zipfile
from pathlib import Path

PREFIX = 'Payload/IronMan2.app/clev'
MARKERS = (b'Mission',b'Objective',b'SpawnPoint',b'MCondition_KillEnemy',b'OnStart',b'OnComplete',b'OnFail',b'NextMission',b'FightBoss')
def read_archive(blob):
    if len(blob)<18:raise ValueError('short archive')
    n=struct.unpack_from('<H',blob,0)[0]
    if n<3 or n>10000:raise ValueError('count out of range')
    if 2+4*n>len(blob):raise ValueError('offsets truncated')
    offsets=struct.unpack_from('<'+'I'*n,blob,2)
    base=2+4*n
    if offsets[0]!=0 or offsets[-1]!=len(blob)-base or tuple(sorted(offsets))!=offsets:
        raise ValueError('offset bounds invalid')
    c=struct.unpack_from('<H',blob,base)[0]
    if c!=n-2:raise ValueError('name count mismatch')
    cursor=base+2
    names=[]
    for _ in range(c):
        if cursor+2>len(blob):raise ValueError('name header missing')
        size=struct.unpack_from('<H',blob,cursor)[0];cursor+=2
        if cursor+size>len(blob):raise ValueError('name overflow')
        names.append(blob[cursor:cursor+size].decode('latin-1'));cursor+=size
    if cursor != base + offsets[1]:raise ValueError('name end mismatch')
    return [(name,blob[base+offsets[i+1]:base+offsets[i+2]]) for i,name in enumerate(names)]
def audit(ipa):
    with zipfile.ZipFile(ipa) as z:
        entries=read_archive(z.read(PREFIX))
    rows=[]
    for name,data in entries:
        row={'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
             'first8_hex':data[:8].hex()}
        for marker in MARKERS:row[marker.decode('ascii')]=int(marker in data)
        rows.append(row)
    return rows
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('ipa');p.add_argument('--output',default='original_level_index.csv');a=p.parse_args()
    rows=audit(a.ipa)
    with open(a.output,'w',newline='',encoding='utf-8') as out:
        wr=csv.DictWriter(out,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
    print('BCLARA records:',len(rows),'total bytes:',sum(r['bytes'] for r in rows))
    for r in sorted(rows,key=lambda r:int(re.search(r'\d+',r['name']).group())):
        print(f"{r['name']:<20} {r['bytes']:>8,d}  sha256 {r['sha256'][:16]}")
    print('These are binary mission/configuration records, NOT decoded mission logic or game geometry.')
