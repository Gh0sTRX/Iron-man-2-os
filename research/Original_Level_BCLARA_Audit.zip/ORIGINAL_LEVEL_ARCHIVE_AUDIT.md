# Iron Man 2 (2010) iOS — first `clev` mission archive investigation

**Source:** actual user-provided `IronMan2_1.0.0_ios_2.2.1.ipa`, not outside guesses.

The IPA contains a named Gameloft asset archive `Payload/IronMan2.app/clev` measuring **2,939,343 bytes**. Its verified offset/name table yields exactly **10 records**: `level1.bclara` through `level10.bclara`.

**Grounded features seen in the raw binary** (schema-level names, not yet decoded instance values): `Mission`, `Objective`, `NextMission`, `FightBoss`, `MCondition_KillEnemy`, `MCondition_Protect`, `MCondition_Collect`, `SpawnPoint`, `OnStart`, `OnComplete`, and `OnFail`.

The archive has no evidence of being a complete playable mission by itself: an interpreter for BCLARA object graphs and references, matching 3D scene models, actual spawn coordinates, enemies, collision meshes and the mission state machine are still required. **Ten `.bclara` resources do not automatically prove exactly ten playable campaign missions.** Do not treat schema marker frequency as objective/spawn/entity counts.

New standalone reproducible `clev_audit.py` reads the original IPA with only standard Python, validates archive offsets and name boundaries, and outputs a SHA256-indexed inventory CSV of all ten mission configuration records. This code does not execute unknown serialized game instructions.

Next research: decode BCLARA's second-level serialization and pointers; resolve the per-level object instances and references to named geometry/scene resources. Only after interpreting mission instances should we implement a first authentic scripted mini-mission.

Existing user-tested Vita B8 remains the known-good animation+combat prototype; B9 and B10 hardware tests are pending. Avoid inventing a Vita map from this schema alone.
