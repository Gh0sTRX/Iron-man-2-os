#!/usr/bin/env python3
"""Inspect Iron Man 2 (2010) iOS asset archives without distributing game data.

Usage: python anim_audit.py IronMan2_1.0.0_ios_2.2.1.ipa --output animation_inventory.csv
This reads names, sizes and bone-name tables only; it DOES NOT decode animation keyframes.
"""
from __future__ import annotations
import argparse
import csv
import struct
import zipfile
from pathlib import Path

ROOT = "Payload/IronMan2.app/"

def decode_archive(data: bytes):
    if len(data) < 14:
        raise ValueError("Archive too small")
    slots = struct.unpack_from('<H', data)[0]
    if slots < 3 or slots > 20000 or 2 + 4 * slots > len(data):
        raise ValueError("Bad archive index size")
    offsets = struct.unpack_from('<' + 'I' * slots, data, 2)
    begin = 2 + 4 * slots
    if offsets[0] != 0 or offsets[-1] != len(data) - begin or list(offsets) != sorted(offsets):
        raise ValueError("Invalid archive offsets")
    count = struct.unpack_from('<H', data, begin)[0]
    if count + 2 != slots:
        raise ValueError("Archive entry count mismatch")
    pos = begin + 2
    names = []
    for _ in range(count):
        if pos + 2 > len(data):
            raise ValueError("Truncated filename size")
        n = struct.unpack_from('<H', data, pos)[0]
        pos += 2
        if n < 1 or pos + n > len(data):
            raise ValueError("Truncated filename")
        names.append(data[pos:pos+n].decode('latin-1'))
        pos += n
    if pos != begin + offsets[1]:
        raise ValueError("Index boundary mismatch")
    for i, name in enumerate(names):
        yield name, data[begin+offsets[i+1]: begin+offsets[i+2]]

def read_name_table(raw: bytes) -> list[str]:
    if len(raw) < 4:
        raise ValueError("Too small for animation")
    count = struct.unpack_from('<H', raw, 0)[0]
    if count < 1 or count > 1024:
        raise ValueError(f"Unexpected name table count: {count}")
    pos = 2
    names = []
    for _ in range(count):
        if pos + 2 > len(raw):
            raise ValueError("Truncated animation name size")
        n = struct.unpack_from('<H', raw, pos)[0]
        pos += 2
        if n < 1 or n > 512 or pos + n > len(raw):
            raise ValueError(f"Invalid animation name length: {n}")
        names.append(raw[pos:pos+n].decode('latin-1'))
        pos += n
    return names

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('ipa', type=Path)
    p.add_argument('--output', type=Path, default=Path('animation_inventory.csv'))
    args = p.parse_args()
    with zipfile.ZipFile(args.ipa) as ipa:
        animations = dict(decode_archive(ipa.read(ROOT + 'anims')))
        models = dict(decode_archive(ipa.read(ROOT + 'models')))
    target_models = {
        'IronMan': ['Iron_man_mark6.bdae', 'Iron_man_mark4.bdae'],
        'Warmachine': ['warmachine.bdae'],
    }
    rows=[]
    failures=[]
    for filename, raw in sorted(animations.items()):
        try:
            names = read_name_table(raw)
        except (ValueError, struct.error) as e:
            failures.append((filename,str(e)))
            continue
        character = 'IronMan' if filename.lower().startswith('ironman') else ('Warmachine' if filename.lower().startswith('warmachine') else '')
        parts = [n for n in names if '\\' not in n and '/' not in n and not n.endswith('.bdae')]
        info=[]
        for mdl in target_models.get(character, []):
            if mdl in models:
                matches = sum(n.encode('latin-1') in models[mdl] for n in parts)
                info.append(f'{mdl}:{matches}/{len(parts)}')
        rows.append({'animation':filename,'bytes':len(raw),'name_count':len(names),'character':character,'models_name_matches':';'.join(info),'first_names':';'.join(names[:7])})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)
    print(f'{len(rows)} animation name-tables parsed; {len(failures)} rejected; csv={args.output}')
    print(f'IronMan animations: {sum(r["character"] == "IronMan" for r in rows)}')
    print(f'War Machine animations: {sum(r["character"] == "Warmachine" for r in rows)}')
    for name,e in failures[:8]:
        print(f'WARN: {name}: {e}')

if __name__ == '__main__':
    main()
