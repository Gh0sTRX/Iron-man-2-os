# Iron Man 2 (2010) — Animation inventory, 2026-10-12

The included `animation_inventory.csv` and `anim_audit.py` were generated from the user's own 1.0.0 IPA. The CSV lists filenames, sizes, parsed name-table counts, and textual correspondence with model archives. It contains no original animation keyframe data.

## Verified findings
- 972 of 972 animation files expose parseable length-prefixed name tables (no decode failures).
- 248 filenames start `IronMan`, 56 start `Warmachine` (case-insensitive).
- `IronMan_Aim_Float_idle.anim` lists 38 strings, including 37 non-source-path names; 31 of the 37 text names occur in each of the Mark IV and Mark VI `.bdae` files.
- `IronMan_Air_land.anim`: 38 total name-table strings; 31/37 non-path strings found in Mark IV and Mark VI models.
- `Warmachine_Aim_Fly_M.anim`: 42 strings; 41/41 non-source-path strings found in original `warmachine.bdae`, including `Bip01`, `Gun01`, `Gun02`, etc.
- The remaining entry in those animation name tables is a full original Windows build path to a `.bdae` animation source. **Bone-name correspondence is NOT proof of keyframe decoding, bind pose, skeleton hierarchy or skinning weights.**

## Why the test is useful
This gives a concrete mapping from specific source animation clips to the relevant character rigs. The next decode step is to identify keyframe times, transform (rotation/translation/scale) encoding, parent-child bone relationships and per-vertex skin weights; only then can the original movement be reproduced on the Vita model.

## Next playable target
Keep B3/B4 working, measure B5 FPS+CPU_MS+SDL_MS when device is available, decode one simple idle/ground/flight clip, build a small controllable flight and repulsor arena. Do not claim full original Iron Man 2 port, original animation, or an optimized FPS until validated on hardware.
