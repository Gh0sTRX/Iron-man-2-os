# Iron Man 2 PS Vita – B15 Mechanics Sandbox (2026-10-12)

**Amaç:** Kullanıcının gerçek PS Vita B14 testi sonrası kontrollere, kameraya, uçuş kademelerine, idle/koşu animasyonlarına ve sonsuz tekrar oynanabilir atış hedefine yapılan düzeltmeler. Bu, orijinal iOS oyun motorunun tam portu değildir.

## Vita kontrolleri
- **Sol analog:** third-person karakter hareketi, analog şiddeti flight seviyesini belirler.
- **Sağ analog:** baş merkezli third-person yörünge kamera.
- **D-pad SOL:** sol analog X yönünü tersle/normal; varsayılan kullanıcı bildirimi nedeniyle ters.
- **D-pad SAĞ:** kamera sağ analog Y yönünü tersle/normal; varsayılan kullanıcı bildirimi nedeniyle ters.
- **D-pad YUKARI/AŞAĞI:** kamerayı yakınlaştır / uzaklaştır.
- **Daire:** havalan / yere in.
- **Üçgen:** yerde koşu; havada 3. seviye boost anahtarı.
- **R/L:** yüksel / alçal.
- **Kare:** repulsor atışı; 3 hedef temizlenince 1.35 saniye sonra yenileri gelir. Ateş düğmesi kilitlenmez.
- **Çarpı:** sıradaki zırh.
- **SELECT:** VSync değiştir, **START:** çık.

## Uçuş
- 0–0.16 joystick: hover/idle;
- 0.16–0.53: 1. kademe dik/yavaş sürüklenme; `IronMan_Air_Move_F`, War Machine `Warmachine_Aim_Float_move_F`.
- 0.53–1.0: 2. kademe normal yatay uçuş: `Ironman_Fly_F`, War Machine `Warmachine_Aim_Fly_M`.
- Boost açık ve joystick >0.53: 3. kademe hızlanmış uçuş ve seçili `RUSH` ara pozları. **War Machine için orijinal RUSH kaydı yok:** bu zırh boostta kendi yatay uçuş pozunu korur ama ilerleme hızı artar.
- Bu eşik değerleri bizim yeni oynanış kodumuz, orijinal oyun mekaniği olarak doğrulanmış değil.

## Yeni kaydedilen orijinal hareketler
- `mark6_air_move.im2v` → IronMan_Air_Move_F.anim
- `suitcase_air_move.im2v` → IronMan_Air_Move_F.anim, Mark V'ye retarget.
- `suitcase_ground_idle.im2v` → IronMan_Ground_Idel.anim, Mark V'ye retarget.
- `warmachine_ground_idle.im2v` → Warmachine_Aim_Ground_idle.anim, War Machine özgün idle (nişan alma varyantı).
- `warmachine_run_retarget.im2v` → IronMan_run.anim, War Machine'e retarget; henüz gerçek Vita görsel kalitesi test edilmedi.

Yeni sürüm: `IronMan2_Mechanics_B15.vpk`, TITLE_ID `IM2K00010`, B14 yerine yazmaz. Bilinen 31 + yeni 5 = **36 .im2v** animasyon verisi, 5 zırh modeli.

## Bilinçli sınırlar
- Orijinal melee/füze/Unibeam/mühimmat/upgrade/combos'un çalışan sistemleri henüz portlanmadı. Orijinal oyuncu animasyonlarının tam listesi `B15_COMPLETE_304_PLAYER_CLIPS.md`, tüm animasyonların CSV'si, sembol API'si ayrı araştırma paketinde.
- B14 yazılımsal renderer ve `SDL_UpdateTexture` ~29 ms bottleneck GPU kullanım sorunu sürüyor.
- 3 hedef gerçek dünya koordinatlı, ancak isabet ekran izdüşümü ile yapılıyor, fiziksel 3D mermi ve çarpışma değil.
- Kamera pivotu modelin **bind-pose** baş yüksekliğine oturur; yüz/bone animasyonunu her kare takip etmez, jitter azaltır.
- Yeni görüntü ve girdi kontrolleri cihazda test edilene kadar Vita uyumu doğrulanmış sayılamaz; CI yeşil sadece derleme sonucudur.
