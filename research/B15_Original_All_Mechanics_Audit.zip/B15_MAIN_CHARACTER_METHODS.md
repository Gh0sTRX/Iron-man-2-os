# Native MainCharacter API symbols – ORIGINAL Iron Man 2 iOS binary

**119 names**, demangled from the user-owned 2010 ARM Mach-O file. Names are evidence of compiled function entry points, not source code or proof of runtime control mapping.

1. `MainCharacter::GetShadowZ()`
2. `MainCharacter::StartThrow(Actor*)`
3. `MainCharacter::ClearTarget(Actor*)`
4. `MainCharacter::IsInUniBeam()`
5. `MainCharacter::OnHitBackBy(Actor*)`
6. `MainCharacter::OnTargetDie(Actor*)`
7. `MainCharacter::SetRotation(irr::core::quaternion const&)`
8. `MainCharacter::SetRotation(irr::core::quaternion const&, float)`
9. `MainCharacter::UpdateInput()`
10. `MainCharacter::getAccuracy()`
11. `MainCharacter::LoadFromFile(EntityData*, StateDatabase*)`
12. `MainCharacter::ThrowMissile(ProjectileEntity*)`
13. `MainCharacter::GetShotButton()`
14. `MainCharacter::OnRemoveForce(SForceInfo&)`
15. `MainCharacter::OnStateChange(StatesMgr*, int, int&, int&, bool&)`
16. `MainCharacter::OnStateUpdate(StatesMgr*, int)`
17. `MainCharacter::ResetQTEState()`
18. `MainCharacter::AddItemCollect(InteractiveEntity*, bool)`
19. `MainCharacter::DrawAimingMark(Sprite*)`
20. `MainCharacter::GetFwMoveSpeed()`
21. `MainCharacter::SetUltimoState(MainCharacter::EUltimoState)`
22. `MainCharacter::UpdateMovement(int)`
23. `MainCharacter::UseItemCollect(InteractiveEntity*)`
24. `MainCharacter::DoUniBeamAttack(int, Actor*, float, float, irr::core::vector3d<float> const&)`
25. `MainCharacter::DrawQTEProgress(Sprite*)`
26. `MainCharacter::IsItemCollected(InteractiveEntity*)`
27. `MainCharacter::PlayAttackSound(int, int)`
28. `MainCharacter::ResetThrowState()`
29. `MainCharacter::UpdateIndicator()`
30. `MainCharacter::FindAttackTarget(float&, bool, bool, float)`
31. `MainCharacter::GetStateCategory()`
32. `MainCharacter::StartMeleeAttack(float)`
33. `MainCharacter::UpdateAimingMark(int)`
34. `MainCharacter::UpdateNavigation(int)`
35. `MainCharacter::UpdateStateFloat(int, float)`
36. `MainCharacter::isSruggleSuccess()`
37. `MainCharacter::ActiveUltimoState(UltimoNPC*)`
38. `MainCharacter::CheckThrowMissile(int)`
39. `MainCharacter::FlyAwayFromUltimo(int)`
40. `MainCharacter::GetCanAttackRange()`
41. `MainCharacter::SetCameraElements(CameraMgr*)`
42. `MainCharacter::UpdateAimingState()`
43. `MainCharacter::UpdateHeightLimit(int)`
44. `MainCharacter::UpdateShadowState()`
45. `MainCharacter::UpdateTrailEffect()`
46. `MainCharacter::ApplyItemCollected()`
47. `MainCharacter::IncreaseExperience(int, bool, bool)`
48. `MainCharacter::OnHitInSpecialMode(Actor*, int, float)`
49. `MainCharacter::UpdateManualAiming()`
50. `MainCharacter::DrawMissileCoolDown(Sprite*)`
51. `MainCharacter::DrawUnibeamProgress(Sprite*)`
52. `MainCharacter::FindCanBeAimedActor(_AIM_STRUCT&, bool)`
53. `MainCharacter::GetCollisionBoxSize(irr::core::vector3d<float>&)`
54. `MainCharacter::IsInJumpAttackState()`
55. `MainCharacter::IsItemTypeCollected(int)`
56. `MainCharacter::ResetInteractiveObj()`
57. `MainCharacter::UpdateFlyModeTarget(int)`
58. `MainCharacter::UpdateFlyNavigation(int, State*)`
59. `MainCharacter::UpdateSphereMapping()`
60. `MainCharacter::ColHdr_OutsideGround(irr::core::vector3d<float>*, irr::core::vector3d<float>*, irr::core::vector3d<float>*, bool, irr::core::vector3d<float>*)`
61. `MainCharacter::ColHdr_OutsideGround(void*, irr::core::vector3d<float>*, irr::core::vector3d<float>*, irr::core::vector3d<float>*, bool, irr::core::vector3d<float>*)`
62. `MainCharacter::GetTargetingPosition()`
63. `MainCharacter::IsInMeleeAttackState()`
64. `MainCharacter::SetInterfaceElements(Button*, Button*, Button*, Button*, Button*)`
65. `MainCharacter::UpdateIdleNavigation(int, State*)`
66. `MainCharacter::UpdateMoveNavigation(int, State*)`
67. `MainCharacter::ActiveLowFlySpecialFX(bool, bool)`
68. `MainCharacter::DrawFlyModeAimingMark(Sprite*)`
69. `MainCharacter::FindInteractiveTarget()`
70. `MainCharacter::ResetMeleeAttackState()`
71. `MainCharacter::UpdateFloatNavigation(int, State*)`
72. `MainCharacter::UpdateSpecialMovement(int)`
73. `MainCharacter::UpdateThrowNavigation(int, State*)`
74. `MainCharacter::UpdateUltimoBossState(int)`
75. `MainCharacter::GetItemCollectedByType(int)`
76. `MainCharacter::InitDirectionIndicator()`
77. `MainCharacter::UpdateMeleeAttackState()`
78. `MainCharacter::AddToMissileTargetArray(Actor*)`
79. `MainCharacter::IsInMeleeAttackEndState()`
80. `MainCharacter::UpdateAutoFlyNavigation(int)`
81. `MainCharacter::UpdateComboAttackAction(int)`
82. `MainCharacter::UpdateSpecialNavigation(int, irr::core::vector3d<float>&, irr::core::quaternion&)`
83. `MainCharacter::IsInMeleeAttackReadyState()`
84. `MainCharacter::UpdateJumpKickAttackState(int)`
85. `MainCharacter::IsCollisionPositionChanged()`
86. `MainCharacter::OnStateChangeInSpecialMode(StatesMgr*, int, int&, int&, bool&)`
87. `MainCharacter::PlayLaserShootSpecialEffect(int, int)`
88. `MainCharacter::UpdateOutsideZoneProcessing(int)`
89. `MainCharacter::Init()`
90. `MainCharacter::IsMC()`
91. `MainCharacter::IsNPC()`
92. `MainCharacter::OnDie()`
93. `MainCharacter::OnHit(Actor*, int, float)`
94. `MainCharacter::Reset()`
95. `MainCharacter::Damage(Actor*, float)`
96. `MainCharacter::Render()`
97. `MainCharacter::Revive()`
98. `MainCharacter::Update(int)`
99. `MainCharacter::Suicide()`
100. `MainCharacter::DoAttack(int, int)`
101. `MainCharacter::SaveLoad(checkpoint::IStream*)`
102. `MainCharacter::StartQTE(Actor*)`
103. `MainCharacter::CheckArea(irr::core::vector3d<float> const&, irr::core::vector3d<float> const&)`
104. `MainCharacter::FaceToYaw(irr::core::vector3d<float>&)`
105. `MainCharacter::NotifyHit(Actor*, int, float)`
106. `MainCharacter::OnLanding()`
107. `MainCharacter::SetTarget(Actor*)`
108. `MainCharacter::MainCharacter()`
109. `MainCharacter::MainCharacter()`
110. `MainCharacter::~MainCharacter()`
111. `MainCharacter::~MainCharacter()`
112. `MainCharacter::~MainCharacter()`
113. `MainCharacter::IsQTEButtonEnabled() const`
114. `MainCharacter::IsInThrowingPrepare() const`
115. `MainCharacter::GetManualAttackRange() const`
116. `MainCharacter::GetMeleeAttackRangeSQ() const`
117. `MainCharacter::GetCurrentMeleeAttackStep() const`
118. `MainCharacter::IsInMeleeAttackSlideState() const`
119. `MainCharacter::GetMeleeAttackSlideRangeSQ() const`

Other executable symbols, weapons, enemy AI, targeting, collision and upgrades: `B15_GAMEPLAY_SYMBOLS.csv`; every demangled C++ symbol: `B15_NATIVE_10760_SYMBOLS.csv`. Function bodies not yet reverse engineered.
