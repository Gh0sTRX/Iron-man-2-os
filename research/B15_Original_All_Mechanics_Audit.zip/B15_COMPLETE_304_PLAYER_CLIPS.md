# IRON MAN 2 (2010) – COMPLETE original armor animation inventory

Source: user-provided iOS 1.0.0 IPA; 248 IronMan* plus 56 Warmachine* = **304** named clips. All 972 originals also in `B15_ALL_972_ANIMATIONS.csv`.

IMPORTANT: names and motion curves are verified; **these are NOT 304 distinct working gameplay attacks**. They include directed poses, stances, boss cutscenes, variants, death, hurt and animations for different character states.

The original runtime transitions, weapon cooldowns, damage, input bindings, melee collision and resource costs are **not recovered**. Family classifications below are provisional interpretation of clip names.

## IronMan – all 248 clip names

### Bekleme / nişan alma (13)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `IronMan_Aim_Ground_idle.anim` | 933 ms | 38 |
| `Ironman_Aim_Ground_idle_2H.anim` | 800 ms | 38 |
| `Ironman_Aim_Ground_idle_Att.anim` | 333 ms | 38 |
| `Ironman_Aim_Ground_idle_Att_2H.anim` | 800 ms | 38 |
| `Ironman_Aim_Ground_idle_Att_L.anim` | 333 ms | 38 |
| `IronMan_Aim_Ground_idle_L.anim` | 933 ms | 38 |
| `Ironman_Aim_M_Ground_idle.anim` | 933 ms | 38 |
| `Ironman_Aim_M_Ground_idle_Att.anim` | 400 ms | 38 |
| `IronMan_Ground_Idel.anim` | 1399 ms | 38 |
| `IronMan_Ground_Idel_1.anim` | 2000 ms | 38 |
| `IronMan_Ground_Idel_2.anim` | 2333 ms | 38 |
| `IronMan_Idel_Att_ready.anim` | 933 ms | 29 |
| `IronMan_main_pose.anim` | 0 ms | 38 |

### Boss / görev / QTE (aday) (29)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `Ironman_attack_boss.anim` | 366 ms | 38 |
| `Ironman_fall_on_boss.anim` | 2000 ms | 53 |
| `Ironman_hold_boss.anim` | 1333 ms | 38 |
| `Ironman_jump_bomb1.anim` | 533 ms | 38 |
| `Ironman_jump_bomb2.anim` | 400 ms | 38 |
| `Ironman_jump_bomb3.anim` | 400 ms | 38 |
| `Ironman_jump_bomb31.anim` | 400 ms | 38 |
| `Ironman_jump_bomb4.anim` | 1033 ms | 38 |
| `IronMan_Obstacle_man_1.anim` | 500 ms | 38 |
| `IronMan_Obstacle_man_2.anim` | 400 ms | 38 |
| `IronMan_Obstacle_man_3.anim` | 400 ms | 38 |
| `IronMan_Obstacle_man_4.anim` | 699 ms | 38 |
| `Ironman_QTE_tank01.anim` | 800 ms | 38 |
| `Ironman_QTE_tank02.anim` | 366 ms | 38 |
| `Ironman_runaway_fail.anim` | 0 ms | 38 |
| `Ironman_runaway_success.anim` | 1100 ms | 38 |
| `Ironman_struggle_boss.anim` | 1833 ms | 38 |
| `IronMan_tex_man_1.anim` | 500 ms | 38 |
| `IronMan_tex_man_2.anim` | 400 ms | 38 |
| `IronMan_tex_man_3.anim` | 400 ms | 38 |
| `IronMan_tex_man_4.anim` | 600 ms | 38 |
| `IronMan_TreeMan_Raise_1.anim` | 666 ms | 29 |
| `IronMan_TreeMan_Raise_2.anim` | 400 ms | 29 |
| `IronMan_TreeMan_Raise_3.anim` | 400 ms | 29 |
| `IronMan_TreeMan_Raise_4.anim` | 1066 ms | 29 |
| `IronMan_utah_machine_man1.anim` | 566 ms | 47 |
| `IronMan_utah_machine_man2.anim` | 400 ms | 47 |
| `IronMan_utah_machine_man3.anim` | 800 ms | 47 |
| `IronMan_utah_machine_man4.anim` | 400 ms | 47 |

### Diğer (isimden belirsiz) (1)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `IronMan_Ground_Put_down.anim` | 1799 ms | 46 |

### Hasar / ölüm / düşme (17)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `IronMan_Air_death.anim` | 2000 ms | 38 |
| `IronMan_Air_fall.anim` | 1600 ms | 38 |
| `IronMan_Air_Hurt.anim` | 600 ms | 38 |
| `IronMan_Air_land_s_fall.anim` | 400 ms | 38 |
| `IronMan_Falling_Hurt.anim` | 266 ms | 38 |
| `IronMan_Falling_Hurt_idle.anim` | 266 ms | 38 |
| `IronMan_Falling_Hurt_Land.anim` | 1066 ms | 38 |
| `Ironman_Fly_Hurt.anim` | 800 ms | 38 |
| `Ironman_Fly_Hurt2.anim` | 800 ms | 38 |
| `IronMan_Ground_Death.anim` | 3000 ms | 38 |
| `IronMan_Ground_Hurt1.anim` | 466 ms | 38 |
| `IronMan_Ground_Hurt2.anim` | 466 ms | 38 |
| `IronMan_Ground_Hurt3.anim` | 899 ms | 38 |
| `IronMan_Ground_Hurt_run.anim` | 866 ms | 38 |
| `IronMan_Ground_Hurt_walk.anim` | 1200 ms | 38 |
| `IronMan_Jump_fall.anim` | 166 ms | 38 |
| `Ironman_Move_jump_fall.anim` | 166 ms | 38 |

### Hover / havalanma / zıplama (52)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `IronMan_Aim_Float_idle.anim` | 1600 ms | 38 |
| `IronMan_Aim_Float_idle_2H.anim` | 800 ms | 38 |
| `IronMan_Aim_Float_idle_Att.anim` | 800 ms | 29 |
| `IronMan_Aim_Float_idle_Att_2H.anim` | 800 ms | 29 |
| `IronMan_Aim_Float_idle_Att_L.anim` | 800 ms | 29 |
| `IronMan_Aim_Float_idle_Att_R.anim` | 800 ms | 29 |
| `IronMan_Aim_Float_idle_L.anim` | 800 ms | 38 |
| `IronMan_Aim_Float_move_B.anim` | 1600 ms | 38 |
| `IronMan_Aim_Float_move_B_Att.anim` | 800 ms | 38 |
| `IronMan_Aim_Float_move_F.anim` | 1600 ms | 38 |
| `IronMan_Aim_Float_move_F_Att.anim` | 800 ms | 38 |
| `IronMan_Aim_Float_move_L.anim` | 1600 ms | 38 |
| `IronMan_Aim_Float_move_L_Att.anim` | 800 ms | 38 |
| `IronMan_Aim_Float_move_R.anim` | 1600 ms | 38 |
| `IronMan_Aim_Float_move_R_Att.anim` | 800 ms | 38 |
| `IronMan_Aim_M_Float_idle.anim` | 1600 ms | 38 |
| `IronMan_Aim_M_Float_idle_Att.anim` | 1600 ms | 38 |
| `IronMan_Aim_M_Float_move_B.anim` | 1600 ms | 38 |
| `IronMan_Aim_M_Float_move_B_Att.anim` | 800 ms | 38 |
| `IronMan_Aim_M_Float_move_F.anim` | 1600 ms | 38 |
| `IronMan_Aim_M_Float_move_F_Att.anim` | 800 ms | 38 |
| `IronMan_Aim_M_Float_move_L.anim` | 1600 ms | 38 |
| `IronMan_Aim_M_Float_move_L_Att.anim` | 800 ms | 38 |
| `IronMan_Aim_M_Float_move_R.anim` | 1600 ms | 38 |
| `IronMan_Aim_M_Float_move_R_Att.anim` | 800 ms | 38 |
| `IronMan_Air_Idel.anim` | 1600 ms | 38 |
| `IronMan_Air_Idel_1.anim` | 1600 ms | 38 |
| `IronMan_Air_Idel_2.anim` | 2733 ms | 38 |
| `IronMan_Air_land.anim` | 800 ms | 38 |
| `IronMan_Air_land_s.anim` | 1399 ms | 38 |
| `IronMan_Air_land_s_end.anim` | 1100 ms | 38 |
| `IronMan_Air_land_s_start.anim` | 300 ms | 38 |
| `IronMan_Air_Move_B.anim` | 1600 ms | 38 |
| `IronMan_Air_Move_F.anim` | 1600 ms | 38 |
| `IronMan_Air_Move_L.anim` | 1600 ms | 38 |
| `IronMan_Air_Move_R.anim` | 1600 ms | 38 |
| `IronMan_Air_up.anim` | 1200 ms | 38 |
| `IronMan_Float_Att_ready.anim` | 400 ms | 29 |
| `IronMan_Float_move_Att_ready_back.anim` | 300 ms | 29 |
| `IronMan_Ground_Float.anim` | 899 ms | 38 |
| `IronMan_Jump.anim` | 1166 ms | 29 |
| `Ironman_Jump2.anim` | 1166 ms | 29 |
| `IronMan_Jump_Act1.anim` | 699 ms | 38 |
| `IronMan_Jump_Act1_run.anim` | 699 ms | 38 |
| `IronMan_Jump_Act3.anim` | 1000 ms | 38 |
| `IronMan_Jump_Act3_run.anim` | 800 ms | 38 |
| `IronMan_Jump_float.anim` | 833 ms | 38 |
| `IronMan_Jump_land.anim` | 400 ms | 38 |
| `IronMan_Jump_start.anim` | 666 ms | 38 |
| `IronMan_Move_Float.anim` | 800 ms | 38 |
| `Ironman_Move_jump_land.anim` | 300 ms | 38 |
| `Ironman_Move_jump_start.anim` | 666 ms | 38 |

### Hızlı uçuş / kaçınma (31)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `IronMan_Fly2Ground.anim` | 633 ms | 38 |
| `IronMan_Fly2Run.anim` | 966 ms | 38 |
| `Ironman_Fly_B.anim` | 1600 ms | 38 |
| `Ironman_Fly_End.anim` | 400 ms | 38 |
| `Ironman_Fly_F.anim` | 1600 ms | 38 |
| `Ironman_Fly_FtoL.anim` | 800 ms | 38 |
| `Ironman_Fly_FtoR.anim` | 800 ms | 38 |
| `Ironman_Fly_F_RUSH.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH01.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH02.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH03.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH04.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH05.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH06.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH07.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH08.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH09.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH10.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH11.anim` | 1600 ms | 38 |
| `Ironman_Fly_F_RUSH12.anim` | 1600 ms | 38 |
| `Ironman_Fly_L.anim` | 1600 ms | 38 |
| `Ironman_Fly_Left_dodge.anim` | 699 ms | 38 |
| `Ironman_Fly_LtoF.anim` | 800 ms | 38 |
| `Ironman_Fly_M_Att_end.anim` | 200 ms | 29 |
| `Ironman_Fly_M_Att_ready.anim` | 200 ms | 38 |
| `Ironman_Fly_M_Att_s.anim` | 1600 ms | 38 |
| `Ironman_Fly_R.anim` | 1600 ms | 38 |
| `Ironman_Fly_Right_dodge.anim` | 699 ms | 38 |
| `Ironman_Fly_RtoF.anim` | 800 ms | 38 |
| `Ironman_Fly_Start.anim` | 333 ms | 38 |
| `IronMan_Rush.anim` | 600 ms | 38 |

### Işın / el bombası / kaldırma-fırlatma (25)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `IronMan_Aim_Float_Beam1.anim` | 600 ms | 29 |
| `IronMan_Aim_Float_Beam2.anim` | 400 ms | 38 |
| `IronMan_Aim_Float_Beam3.anim` | 1266 ms | 38 |
| `IronMan_Aim_Ground_Beam1.anim` | 400 ms | 38 |
| `IronMan_Aim_Ground_Beam2.anim` | 400 ms | 38 |
| `IronMan_Aim_Ground_Beam3.anim` | 1000 ms | 38 |
| `Ironman_Aim_Ground_grenade_idle.anim` | 1399 ms | 38 |
| `Ironman_Aim_Ground_grenade_move_B.anim` | 866 ms | 38 |
| `Ironman_Aim_Ground_grenade_move_B_Att.anim` | 866 ms | 38 |
| `Ironman_Aim_Ground_grenade_move_F.anim` | 800 ms | 38 |
| `Ironman_Aim_Ground_grenade_move_F_Att.anim` | 800 ms | 38 |
| `Ironman_Aim_Ground_grenade_move_L.anim` | 800 ms | 38 |
| `Ironman_Aim_Ground_grenade_move_L_Att.anim` | 800 ms | 38 |
| `Ironman_Aim_Ground_grenade_move_R.anim` | 800 ms | 38 |
| `Ironman_Aim_Ground_grenade_move_R_Att.anim` | 800 ms | 38 |
| `IronMan_Ground_Raise1.anim` | 699 ms | 44 |
| `IronMan_Ground_Raise1_1.anim` | 0 ms | 44 |
| `IronMan_Ground_Raise2.anim` | 1633 ms | 44 |
| `IronMan_Ground_Raise_Idle.anim` | 800 ms | 29 |
| `IronMan_Ground_Raise_move_B.anim` | 699 ms | 39 |
| `IronMan_Ground_Raise_move_F.anim` | 699 ms | 39 |
| `IronMan_Ground_Raise_move_L.anim` | 699 ms | 39 |
| `IronMan_Ground_Raise_move_R.anim` | 699 ms | 39 |
| `IronMan_Ground_Raise_Throw.anim` | 366 ms | 30 |
| `IronMan_Ground_Raise_Throw2.anim` | 433 ms | 38 |

### Yakın dövüş / saldırı (30)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `IronMan_Aim_M_Float_Attack.anim` | 600 ms | 38 |
| `IronMan_Air_Att_s.anim` | 1600 ms | 29 |
| `IronMan_Air_CounterAtt.anim` | 899 ms | 38 |
| `IronMan_Air_Hurt_attack1.anim` | 600 ms | 38 |
| `IronMan_Air_Hurt_attack2.anim` | 600 ms | 38 |
| `IronMan_Air_Hurt_attack3.anim` | 800 ms | 38 |
| `Ironman_Attack_ground_grenade.anim` | 800 ms | 38 |
| `IronMan_Attack_Ground_idle.anim` | 266 ms | 29 |
| `IronMan_Attack_Ground_move_B.anim` | 1200 ms | 29 |
| `IronMan_Attack_Ground_move_F.anim` | 1200 ms | 29 |
| `Ironman_Attack_M_ground.anim` | 600 ms | 38 |
| `Ironman_Fly_Att_end.anim` | 200 ms | 29 |
| `Ironman_Fly_Att_m.anim` | 1600 ms | 38 |
| `Ironman_Fly_Att_ready.anim` | 200 ms | 38 |
| `Ironman_Fly_Att_s.anim` | 1600 ms | 38 |
| `IronMan_Ground_Att_end.anim` | 300 ms | 38 |
| `Ironman_Ground_Att_idel.anim` | 1333 ms | 38 |
| `IronMan_Ground_Att_idel_B.anim` | 1200 ms | 38 |
| `IronMan_Ground_Att_idel_F.anim` | 1200 ms | 40 |
| `IronMan_Ground_Att_idel_L.anim` | 1200 ms | 38 |
| `IronMan_Ground_Att_idel_R.anim` | 1200 ms | 38 |
| `IronMan_Ground_Att_s1.anim` | 266 ms | 33 |
| `IronMan_Ground_Att_s1_End.anim` | 300 ms | 29 |
| `IronMan_Ground_Att_s1_Start.anim` | 233 ms | 29 |
| `IronMan_Ground_Att_s2.anim` | 899 ms | 29 |
| `IronMan_Ground_Att_s_r.anim` | 866 ms | 29 |
| `IronMan_Ground_Att_s_w.anim` | 1200 ms | 29 |
| `Ironman_Palsy.anim` | 1066 ms | 38 |
| `IronMan_PushAway_Air.anim` | 1333 ms | 38 |
| `IronMan_PushAway_Ground.anim` | 1333 ms | 38 |

### Yakın dövüş – combo (22)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `IronMan_Ground_ComboPower1.anim` | 600 ms | 40 |
| `IronMan_Ground_ComboPower1_end.anim` | 400 ms | 40 |
| `IronMan_Ground_ComboPower2.anim` | 666 ms | 40 |
| `IronMan_Ground_ComboPower2_end.anim` | 666 ms | 40 |
| `IronMan_Ground_ComboPower3.anim` | 800 ms | 40 |
| `IronMan_Ground_ComboPower3_end.anim` | 533 ms | 40 |
| `IronMan_Ground_ComboPower4_final.anim` | 1333 ms | 40 |
| `Ironman_Ground_ComboPower_a.anim` | 666 ms | 42 |
| `Ironman_Ground_ComboPower_aa.anim` | 833 ms | 42 |
| `Ironman_Ground_ComboPower_aaa.anim` | 1766 ms | 42 |
| `Ironman_Ground_ComboPower_aab.anim` | 1566 ms | 43 |
| `Ironman_Ground_ComboPower_aa_end.anim` | 600 ms | 42 |
| `Ironman_Ground_ComboPower_ab.anim` | 1033 ms | 43 |
| `Ironman_Ground_ComboPower_aba.anim` | 1700 ms | 43 |
| `Ironman_Ground_ComboPower_abb.anim` | 2700 ms | 43 |
| `Ironman_Ground_ComboPower_ab_end.anim` | 1166 ms | 43 |
| `Ironman_Ground_ComboPower_a_end.anim` | 500 ms | 42 |
| `IronMan_Ground_Combo_1.anim` | 266 ms | 40 |
| `IronMan_Ground_Combo_1_end.anim` | 233 ms | 40 |
| `IronMan_Ground_Combo_2.anim` | 300 ms | 40 |
| `IronMan_Ground_Combo_2_end.anim` | 300 ms | 40 |
| `IronMan_Ground_Combo_3.anim` | 500 ms | 40 |

### Yerde hareket / koşu (28)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `Ironman_Aim_Ground_move_B.anim` | 866 ms | 38 |
| `Ironman_Aim_Ground_move_B_Att.anim` | 866 ms | 38 |
| `IronMan_Aim_Ground_move_F.anim` | 866 ms | 38 |
| `Ironman_Aim_Ground_move_F_Att.anim` | 866 ms | 38 |
| `IronMan_Aim_Ground_move_L.anim` | 866 ms | 38 |
| `Ironman_Aim_Ground_move_L_Att.anim` | 866 ms | 38 |
| `IronMan_Aim_Ground_move_R.anim` | 866 ms | 38 |
| `Ironman_Aim_Ground_move_R_Att.anim` | 866 ms | 38 |
| `Ironman_Aim_M_Ground_move_B.anim` | 1399 ms | 38 |
| `Ironman_Aim_M_Ground_move_B_Att.anim` | 1399 ms | 38 |
| `Ironman_Aim_M_Ground_move_F.anim` | 866 ms | 38 |
| `Ironman_Aim_M_Ground_move_F_Att.anim` | 866 ms | 38 |
| `Ironman_Aim_M_Ground_move_L.anim` | 866 ms | 38 |
| `Ironman_Aim_M_Ground_move_L_Att.anim` | 866 ms | 38 |
| `Ironman_Aim_M_Ground_move_R.anim` | 866 ms | 38 |
| `Ironman_Aim_M_Ground_move_R_Att.anim` | 866 ms | 38 |
| `IronMan_run.anim` | 533 ms | 45 |
| `IronMan_runflash1.anim` | 66 ms | 38 |
| `IronMan_runflash2.anim` | 200 ms | 38 |
| `IronMan_runflash3.anim` | 533 ms | 38 |
| `IronMan_Run_Att_end.anim` | 5066 ms | 29 |
| `Ironman_Run_Att_ready.anim` | 5066 ms | 29 |
| `IronMan_Walk_Att_end.anim` | 5733 ms | 29 |
| `IronMan_Walk_Att_ready.anim` | 5733 ms | 29 |
| `IronMan_Walk_B.anim` | 1200 ms | 29 |
| `IronMan_Walk_F.anim` | 1200 ms | 38 |
| `IronMan_Walk_L.anim` | 1200 ms | 29 |
| `IronMan_Walk_R.anim` | 1200 ms | 29 |

## Warmachine – all 56 clip names

### Bekleme / nişan alma (6)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `Warmachine_Aim_Ground_idle.anim` | 933 ms | 41 |
| `Warmachine_Aim_Ground_idle_2H.anim` | 800 ms | 41 |
| `Warmachine_Aim_Ground_idle_Att.anim` | 933 ms | 41 |
| `Warmachine_Aim_Ground_idle_LH.anim` | 933 ms | 41 |
| `Warmachine_Aim_M_Ground_idle.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Ground_idle_Att.anim` | 1600 ms | 42 |

### Hover / havalanma / zıplama (22)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `Warmachine_Aim_Float_idle.anim` | 1600 ms | 41 |
| `Warmachine_Aim_Float_idle_2H.anim` | 800 ms | 41 |
| `Warmachine_Aim_Float_idle_Att.anim` | 1600 ms | 41 |
| `Warmachine_Aim_Float_idle_L.anim` | 800 ms | 41 |
| `Warmachine_Aim_Float_move_B.anim` | 1600 ms | 41 |
| `Warmachine_Aim_Float_move_B_Att.anim` | 1600 ms | 41 |
| `Warmachine_Aim_Float_move_F.anim` | 1600 ms | 41 |
| `Warmachine_Aim_Float_move_F_Att.anim` | 1600 ms | 41 |
| `Warmachine_Aim_Float_move_L.anim` | 1600 ms | 41 |
| `Warmachine_Aim_Float_move_L_Att.anim` | 1600 ms | 41 |
| `Warmachine_Aim_Float_move_R.anim` | 1600 ms | 41 |
| `Warmachine_Aim_Float_move_R_Att.anim` | 1600 ms | 41 |
| `Warmachine_Aim_M_Float_idle.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Float_idle_Att.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Float_move_B.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Float_move_B_Att.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Float_move_F.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Float_move_F_Att.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Float_move_L.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Float_move_L_Att.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Float_move_R.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Float_move_R_Att.anim` | 1600 ms | 42 |

### Hızlı uçuş / kaçınma (2)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `Warmachine_Aim_Fly_M.anim` | 1600 ms | 42 |
| `Warmachine_Aim_Fly_M_Att.anim` | 1600 ms | 42 |

### Yakın dövüş / saldırı (10)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `Warmachine_Aattack_Float_idle_LH.anim` | 800 ms | 41 |
| `Warmachine_Aattack_Ground_move_B.anim` | 866 ms | 41 |
| `Warmachine_Attack_Float_idle_2H.anim` | 800 ms | 41 |
| `Warmachine_Attack_Float_move_B.anim` | 1600 ms | 41 |
| `Warmachine_Attack_Float_move_R.anim` | 1600 ms | 41 |
| `Warmachine_Attack_Ground_idle_2H.anim` | 800 ms | 41 |
| `Warmachine_Attack_Ground_idle_LH.anim` | 933 ms | 41 |
| `Warmachine_Attack_Ground_move_R.anim` | 866 ms | 41 |
| `Warmachine_Fly_Att_ready.anim` | 200 ms | 41 |
| `Warmachine_Fly_Att_s.anim` | 1600 ms | 41 |

### Yerde hareket / koşu (16)

| Original name | Duration | Verified skeletal labels |
|---|---:|---:|
| `Warmachine_Aim_Ground_move_B.anim` | 866 ms | 41 |
| `Warmachine_Aim_Ground_move_B_Att.anim` | 1399 ms | 41 |
| `Warmachine_Aim_Ground_move_F.anim` | 866 ms | 41 |
| `Warmachine_Aim_Ground_move_F_Att.anim` | 866 ms | 41 |
| `Warmachine_Aim_Ground_move_L.anim` | 866 ms | 41 |
| `Warmachine_Aim_Ground_move_L_Att.anim` | 866 ms | 41 |
| `Warmachine_Aim_Ground_move_R.anim` | 866 ms | 41 |
| `Warmachine_Aim_Ground_move_R_Att.anim` | 866 ms | 41 |
| `Warmachine_Aim_M_Ground_move_B.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Ground_move_B_Att.anim` | 1399 ms | 42 |
| `Warmachine_Aim_M_Ground_move_F.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Ground_move_F_Att.anim` | 866 ms | 42 |
| `Warmachine_Aim_M_Ground_move_L.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Ground_move_L_Att.anim` | 866 ms | 42 |
| `Warmachine_Aim_M_Ground_move_R.anim` | 1600 ms | 42 |
| `Warmachine_Aim_M_Ground_move_R_Att.anim` | 866 ms | 42 |

