# Original Iron Man 2 – gameplay and combat capability evidence register

## Confidence levels
- **Confirmed asset:** the original animation/scene name and binary keyframes exist in the IPA.
- **Prototype:** our independently written Vita controller implements a related basic action.
- **Unverified original mechanics:** damage, upgrades, weapon ammo/heat, combo input chains, enemy hitboxes, weapon behavior and original state machine.

| Feature family | Source filenames (samples, not an exhaustive listing) | Proven |
|---|---|---|
| Repulsor / beam | `IronMan_Aim_Float_Beam1.anim`, `IronMan_Aim_Float_Beam2.anim`, `IronMan_Aim_Float_Beam3.anim` (27 filename matches; may overlap) | Animation data only |
| Grenade | `Ironman_Aim_Ground_grenade_idle.anim`, `Ironman_Aim_Ground_grenade_move_B.anim`, `Ironman_Aim_Ground_grenade_move_B_Att.anim` (10 filename matches; may overlap) | Animation data only |
| Aimed gun/fire | `Ironman_Aim_Ground_move_B.anim`, `Ironman_Aim_Ground_move_B_Att.anim`, `IronMan_Aim_Ground_move_F.anim` (89 filename matches; may overlap) | Animation data only |
| Ground melee combo | `Ironman_Attack_M_ground.anim`, `IronMan_Ground_Att_s1.anim`, `IronMan_Ground_Att_s1_End.anim` (29 filename matches; may overlap) | Animation data only |
| Aerial strikes/dodge | `IronMan_Air_Att_s.anim`, `IronMan_Air_CounterAtt.anim`, `Ironman_Fly_Att_end.anim` (10 filename matches; may overlap) | Animation data only |
| Grab / lift / throw | `IronMan_Ground_Put_down.anim`, `IronMan_Ground_Raise1.anim`, `IronMan_Ground_Raise1_1.anim` (11 filename matches; may overlap) | Animation data only |
| Ground locomotion | `IronMan_Fly2Run.anim`, `IronMan_Ground_Hurt_run.anim`, `IronMan_Ground_Idel.anim` (19 filename matches; may overlap) | Animation data only |
| Flight / rush / landing | `IronMan_Aim_Float_idle.anim`, `IronMan_Aim_Float_idle_2H.anim`, `IronMan_Aim_Float_idle_Att.anim` (50 filename matches; may overlap) | Animation data only |
| Damage/death | `IronMan_Air_death.anim`, `IronMan_Air_fall.anim`, `IronMan_Air_Hurt.anim` (22 filename matches; may overlap) | Animation data only |
| Scripted boss/QTE | `Ironman_attack_boss.anim`, `Ironman_fall_on_boss.anim`, `Ironman_hold_boss.anim` (18 filename matches; may overlap) | Animation data only |

**Unverified systems:** all actual damage/armor balance, lock-on logic, missile count, beam energy, movement acceleration from the original executable are unknown from filenames alone. The B8/B14 firing uses our own cooldown and projected hit radius, not original weapon physics.

**Status:** B15 adds three flight tiers (drift, horizontal, conditional boost), persistent repulsor target waves, headset pivot camera and axis inversion controls, three missing idle/movement clips from IPA. All full native original combat sets require animation retarget + gameplay reconstruction and testing.
