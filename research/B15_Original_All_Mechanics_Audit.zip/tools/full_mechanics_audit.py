#!/usr/bin/env python3
"""Source-faithful no-payload original Iron Man 2 full .anim index + evidence.
Do not conflate 'animation clip exists' with verified gameplay mechanic."""
from pathlib import Path
import sys,zipfile,hashlib,csv,re,json,collections
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'tools'))
from anim_decoder_b6 import ROOT,decode_archive,decode_anim
IPA=Path('/mnt/data/IronMan2_1.0.0_ios_2.2.1.ipa')
OUT=HERE/'docs';OUT.mkdir(exist_ok=True)
def category(name):
 s=name.lower()
 if 'qte' in s or 'boss' in s or any(x in s for x in ('tex_man','obstacle_man','utah_machine','tree','runaway','jump_bomb')):return 'Boss / görev / QTE (aday)'
 if 'combopower' in s or 'combo_' in s:return 'Yakın dövüş – combo'
 if any(x in s for x in ('ground_att','air_att','fly_att','attack','counteratt','pushaway','palsy')):return 'Yakın dövüş / saldırı'
 if any(x in s for x in ('beam','grenade','raise','throw')):return 'Işın / el bombası / kaldırma-fırlatma'
 if any(x in s for x in ('hurt','death','fall','struggle')):return 'Hasar / ölüm / düşme'
 if any(x in s for x in ('fly','rush','dodge')):return 'Hızlı uçuş / kaçınma'
 if any(x in s for x in ('float','air_','jump')):return 'Hover / havalanma / zıplama'
 if any(x in s for x in ('walk','run','ground_move')):return 'Yerde hareket / koşu'
 if any(x in s for x in ('idle','idel','main_pose')):return 'Bekleme / nişan alma'
 return 'Diğer (isimden belirsiz)'
rows=[]
with zipfile.ZipFile(IPA) as z:
 for name,payload in decode_archive(z.read(ROOT+'anims')):
  a=decode_anim(payload)
  src='IronMan' if name.lower().startswith('ironman') else 'Warmachine' if name.lower().startswith('warmachine') else 'Other'
  typ=category(name)
  rows.append(dict(name=name,source_character=src,nominal_family=typ,duration_ms=a.duration_ms,joint_labels=len(a.names),animated_translations=sum(ch.mode=='keyframed' for ch in a.translations),animated_rotations=sum(ch.mode=='keyframed' for ch in a.rotations),raw_sha256=hashlib.sha256(payload).hexdigest()))
assert len(rows)==972,len(rows)
assert sum(x['source_character']=='IronMan' for x in rows)==248
assert sum(x['source_character']=='Warmachine' for x in rows)==56
with (OUT/'B15_ALL_972_ANIMATIONS.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
players=[x for x in rows if x['source_character']!='Other']
counts=collections.Counter((x['source_character'],x['nominal_family']) for x in players)
with (OUT/'B15_COMPLETE_304_PLAYER_CLIPS.md').open('w',encoding='utf-8') as f:
 f.write('# IRON MAN 2 (2010) – COMPLETE original armor animation inventory\n\n')
 f.write('Source: user-provided iOS 1.0.0 IPA; 248 IronMan* plus 56 Warmachine* = **304** named clips. All 972 originals also in `B15_ALL_972_ANIMATIONS.csv`.\n\n')
 f.write('IMPORTANT: names and motion curves are verified; **these are NOT 304 distinct working gameplay attacks**. They include directed poses, stances, boss cutscenes, variants, death, hurt and animations for different character states.\\n\\n'.replace('\\n','\n'))
 f.write('The original runtime transitions, weapon cooldowns, damage, input bindings, melee collision and resource costs are **not recovered**. Family classifications below are provisional interpretation of clip names.\n\n')
 for c in ('IronMan','Warmachine'):
  cc=[x for x in players if x['source_character']==c]
  f.write(f'## {c} – all {len(cc)} clip names\n\n')
  by=collections.defaultdict(list)
  for x in cc:by[x['nominal_family']].append(x)
  for family in sorted(by):
   f.write(f'### {family} ({len(by[family])})\n\n')
   f.write('| Original name | Duration | Verified skeletal labels |\n|---|---:|---:|\n')
   for x in by[family]:f.write(f'| `{x["name"]}` | {x["duration_ms"]} ms | {x["joint_labels"]} |\n')
   f.write('\n')
with (OUT/'B15_MECHANICS_EVIDENCE.md').open('w',encoding='utf-8') as f:
 f.write('# Original Iron Man 2 – gameplay and combat capability evidence register\n\n')
 f.write('## Confidence levels\n- **Confirmed asset:** the original animation/scene name and binary keyframes exist in the IPA.\n- **Prototype:** our independently written Vita controller implements a related basic action.\n- **Unverified original mechanics:** damage, upgrades, weapon ammo/heat, combo input chains, enemy hitboxes, weapon behavior and original state machine.\n\n')
 families={
 'Repulsor / beam':['Beam1','Beam2','Beam3','Aim_Ground_idle','Aim_Float_idle'],
 'Grenade':['grenade','Attack_ground_grenade'],
 'Aimed gun/fire':['Ground_Att_','Fly_Att_','Aim_M_','_Aim_Fly_M','_Attack_','_Aim_Ground_move'],
 'Ground melee combo':['Ground_Combo_','Ground_ComboPower','Attack_M_ground','Ground_Att_s'],
 'Aerial strikes/dodge':['Air_CounterAtt','Air_Att_s','Fly_Left_dodge','Fly_Right_dodge','Fly_Att_'],
 'Grab / lift / throw':['Ground_Raise','Ground_Put_down','Ground_Raise_Throw'],
 'Ground locomotion':['Walk_F','Walk_B','Walk_L','Walk_R','run','Ground_Idel'],
 'Flight / rush / landing':['Fly_F','RUSH','Fly_Start','Fly_End','Air_land','Fly2Ground','Float_idle','Float_move_F'],
 'Damage/death':['Hurt','death','fall','Palsy'],
 'Scripted boss/QTE':['QTE','boss','Obstacle_man','TreeMan','utah_machine']}
 f.write('| Feature family | Source filenames (samples, not an exhaustive listing) | Proven |\n|---|---|---|\n')
 for name,terms in families.items():
  hits=[x['name'] for x in players if any(t.lower() in x['name'].lower() for t in terms)]
  f.write('| '+name+' | '+', '.join('`'+x+'`' for x in hits[:3])+f' ({len(hits)} filename matches; may overlap) | Animation data only |\n')
 f.write('\n**Unverified systems:** all actual damage/armor balance, lock-on logic, missile count, beam energy, movement acceleration from the original executable are unknown from filenames alone. The B8/B14 firing uses our own cooldown and projected hit radius, not original weapon physics.\n\n')
 f.write('**Status:** B15 adds three flight tiers (drift, horizontal, conditional boost), persistent repulsor target waves, headset pivot camera and axis inversion controls, three missing idle/movement clips from IPA. All full native original combat sets require animation retarget + gameplay reconstruction and testing.\n')
(OUT/'B15_FAMILY_COUNTS.json').write_text(json.dumps({f'{k[0]}|{k[1]}':v for k,v in sorted(counts.items())},indent=2),encoding='utf-8')
print('decoded',len(rows),'total',len(players),'armor clips',dict(collections.Counter(x['nominal_family'] for x in players)))
