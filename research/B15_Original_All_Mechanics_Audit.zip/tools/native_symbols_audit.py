#!/usr/bin/env python3
"""Demangle original 32-bit ARM Mach-O C++ symbol strings (metadata only)."""
from pathlib import Path
import subprocess,zipfile,re,csv,json,collections
IPA=Path('/mnt/data/IronMan2_1.0.0_ios_2.2.1.ipa')
OUT=Path(__file__).resolve().parents[1]/'docs';OUT.mkdir(exist_ok=True)
with zipfile.ZipFile(IPA) as z:data=z.read('Payload/IronMan2.app/IronMan2')
strings=[x.decode('latin1') for x in re.findall(rb'[\x20-\x7e]{6,}',data)]
names=sorted(set(x for x in strings if x.startswith('__ZN')))
result=subprocess.run(['c++filt'],input='\n'.join(x[1:] for x in names),text=True,capture_output=True,check=True)
dem=result.stdout.splitlines();assert len(names)==len(dem)
terms=('MainCharacter::','CameraCtrl::','WeaponEntity::','AttackEntity::','ProjectileEntity::','Upgrade','WCollision::','StatesMgr::','GamePlay','Melee','Missile','Laser','UniBeam','Damage','Aim','State','Shield','Combo','Rush','Navigation')
def sysgroup(s):
 if s.startswith('MainCharacter::'):return 'MainCharacter'
 if s.startswith('CameraCtrl::'):return 'CameraCtrl'
 if s.startswith(('WeaponEntity::','AttackEntity::','ProjectileEntity::')):return 'Weapon/projectile'
 if 'Upgrade' in s:return 'Upgrade'
 if s.startswith('WCollision::') or 'Collision' in s:return 'Collision'
 if any(x in s for x in ('AI','NPC','StatesMgr')):return 'Enemy/AI/state'
 return 'Other/system'
relevant=[(a,b,sysgroup(b)) for a,b in zip(names,dem) if any(t.lower() in b.lower() for t in terms)]
with (OUT/'B15_NATIVE_10760_SYMBOLS.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['Mangled original Mach-O label','C++ demangled spelling']);w.writerows(zip(names,dem))
with (OUT/'B15_GAMEPLAY_SYMBOLS.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['mangled','demangled','inferred_system']);w.writerows(relevant)
cc=[b for a,b in zip(names,dem) if b.startswith('MainCharacter::')]
with (OUT/'B15_MAIN_CHARACTER_METHODS.md').open('w',encoding='utf-8') as f:
 f.write('# Native MainCharacter API symbols – ORIGINAL Iron Man 2 iOS binary\n\n')
 f.write(f'**{len(cc)} names**, demangled from the user-owned 2010 ARM Mach-O file. Names are evidence of compiled function entry points, not source code or proof of runtime control mapping.\n\n')
 for i,s in enumerate(cc,1):f.write(f'{i}. `{s}`\n')
 f.write('\nOther executable symbols, weapons, enemy AI, targeting, collision and upgrades: `B15_GAMEPLAY_SYMBOLS.csv`; every demangled C++ symbol: `B15_NATIVE_10760_SYMBOLS.csv`. Function bodies not yet reverse engineered.\n')
summary={'total_unique_mangled_names':len(names),'gameplay_matching_names':len(relevant),'MainCharacter_symbols':len(cc),'systems':dict(collections.Counter(c for _,_,c in relevant))}
(OUT/'B15_NATIVE_SYMBOL_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(summary)
