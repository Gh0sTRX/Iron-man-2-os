#!/usr/bin/env python3
"""Validated, independent 2010 Gameloft Iron Man 2 .anim decoder.

Reverse-engineered from user-provided iOS v1.0.0 IPA, not presumed to apply to
other Gameloft games. It reads encoded translation and quaternion timelines;
rig hierarchy, weights and animation playback in-game are NOT implemented.

Encoding:
  u16 string_count; for each: u16 bytes_len, latin1 name
  for each string entry: translation (u8 mode=1 => 3*f32; mode=0 => u16 samples, records i32 milliseconds+3*f32)
  for each string entry: rotation (u8 mode=1 => 4*i16; mode=0 => u16 samples, records i32 milliseconds+4*i16)
Quat signed fixed point scale is 1/32767. Normalize for floating use.
"""
from __future__ import annotations
from dataclasses import dataclass
import argparse, csv, json, math, struct, zipfile
from pathlib import Path

ROOT = 'Payload/IronMan2.app/'

@dataclass
class Channel:
    mode: str
    values: list[tuple[int,tuple]]  # timestamps in ms, values tuple

@dataclass
class Animation:
    names: list[str]
    translations: list[Channel]
    rotations: list[Channel]
    duration_ms: int
    sample_count: int


def read_at(buf, offset, fmt):
    size=struct.calcsize(fmt)
    if offset+size>len(buf): raise ValueError(f'truncated {fmt} at {offset}')
    return struct.unpack_from(fmt,buf,offset), offset+size

def unpack_track(buf: bytes, p: int, is_quaternion: bool):
    if p>=len(buf): raise ValueError('truncated track type')
    typ=buf[p];p+=1
    if typ not in (0,1): raise ValueError(f'unsupported track mode {typ} at 0x{p-1:x}')
    fmt='<hhhh' if is_quaternion else '<fff'
    def checked(vals):
        if is_quaternion:
            # Scale raw signed 16-bit components to floats; do not assume 4D xyzw ordering proven.
            q=tuple(v/32767.0 for v in vals)
            norm=math.sqrt(sum(x*x for x in q))
            if not .8 < norm < 1.2: raise ValueError(f'non-unit quaternion: {q} norm {norm}')
            return q
        if not all(math.isfinite(v) for v in vals): raise ValueError('nonfinite translation')
        return tuple(vals)
    if typ==1:
        val,p=read_at(buf,p,fmt)
        return Channel('constant',[(0,checked(val))]),p
    (n,),p=read_at(buf,p,'<H')
    if n==0 or n>20000: raise ValueError(f'invalid keyframe count {n}')
    values=[];t_prev=-(1<<31)
    for i in range(n):
        (time,),p=read_at(buf,p,'<i')
        val,p=read_at(buf,p,fmt)
        if time<=t_prev or time>1000*60*30 or time < -30000:
            raise ValueError(f'non-increasing/invalid timeline: key {i} t={time} previous={t_prev}')
        t_prev=time
        values.append((time,checked(val)))
    return Channel('keyframed',values),p

def decode_anim(raw: bytes) -> Animation:
    p=0
    (count,),p=read_at(raw,p,'<H')
    if not (1<=count<=1024):raise ValueError(f'invalid string count {count}')
    names=[]
    for i in range(count):
        (length,),p=read_at(raw,p,'<H')
        if length<1 or length>4096 or p+length>len(raw):raise ValueError(f'invalid name byte length {length} at {i}')
        names.append(raw[p:p+length].decode('latin-1'));p+=length
    translations=[];rotations=[]
    for name in names:
        ch,p=unpack_track(raw,p,False)
        translations.append(ch)
    for name in names:
        ch,p=unpack_track(raw,p,True)
        rotations.append(ch)
    if p!=len(raw):raise ValueError(f'unconsumed bytes: cursor={p} file size={len(raw)} residual={len(raw)-p}')
    timeline_end=max((t for ch in translations+rotations for t,_ in ch.values),default=0)
    total_samples=sum(len(c.values) for c in translations+rotations)
    return Animation(names,translations,rotations,timeline_end,total_samples)


def decode_archive(data:bytes):
    (slots,)=struct.unpack_from('<H',data,0)
    if slots<3 or slots>20000 or 2+4*slots>len(data):raise ValueError('invalid archive slots')
    offsets=struct.unpack_from('<'+'I'*slots,data,2)
    base=2+4*slots
    (count,)=struct.unpack_from('<H',data,base)
    if offsets[0]!=0 or offsets[-1]!=len(data)-base or count+2!=slots or list(offsets)!=sorted(offsets):
        raise ValueError('invalid archive index')
    pos=base+2;names=[]
    for i in range(count):
        (n,)=struct.unpack_from('<H',data,pos);pos+=2
        if n==0 or pos+n>len(data):raise ValueError('invalid entry name')
        names.append(data[pos:pos+n].decode('latin-1'));pos+=n
    if pos!=base+offsets[1]:raise ValueError('bad archive name boundary')
    for i,name in enumerate(names):yield name,data[base+offsets[i+1]:base+offsets[i+2]]


def main():
    cli=argparse.ArgumentParser(description='Audit all Iron Man 2 .anim transforms; no content redistribution')
    cli.add_argument('ipa',type=Path)
    cli.add_argument('--csv',type=Path,default=Path('B6_animation_decode_inventory.csv'))
    cli.add_argument('--json',type=Path,default=None,help='Export one animation (all tracks) as JSON; requires --clip')
    cli.add_argument('--clip',type=str,default=None)
    a=cli.parse_args()
    with zipfile.ZipFile(a.ipa) as z:
        clips=list(decode_archive(z.read(ROOT+'anims')))
    rows=[];failures=[];duration_counts={}
    for filename,blob in clips:
        try:
            anim=decode_anim(blob)
            duration_counts[anim.duration_ms]=duration_counts.get(anim.duration_ms,0)+1
            d={
                'name':filename,'size_bytes':len(blob),'named_channels':len(anim.names),
                'duration_ms':anim.duration_ms,'samples':anim.sample_count,
                'translation_animated':sum(c.mode=='keyframed' for c in anim.translations),
                'rotation_animated':sum(c.mode=='keyframed' for c in anim.rotations),
                'translation_static':sum(c.mode=='constant' for c in anim.translations),
                'rotation_static':sum(c.mode=='constant' for c in anim.rotations),
            }
            rows.append(d)
            if a.clip and filename.casefold()==a.clip.casefold():
                if not a.json: raise ValueError('provide --json when using --clip')
                out={'clip':filename,'duration_ms':anim.duration_ms,'notes':'Quaternion component order / rig hierarchy not yet independently verified','nodes':[
                    {'name':name,'position_mode':p.mode,'position_frames':p.values,'quaternion_mode':r.mode,'quaternion_frames':r.values}
                    for name,p,r in zip(anim.names,anim.translations,anim.rotations)]}
                a.json.parent.mkdir(parents=True,exist_ok=True)
                a.json.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
        except (ValueError,struct.error,IndexError) as e:failures.append((filename,str(e)))
    a.csv.parent.mkdir(parents=True,exist_ok=True)
    with a.csv.open('w',encoding='utf-8',newline='') as fp:
        writer=csv.DictWriter(fp,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(f'VALID={len(rows)} REJECTED={len(failures)} TOTAL={len(clips)}')
    print(f'Keyframed translations={sum(x["translation_animated"] for x in rows)} rotations={sum(x["rotation_animated"] for x in rows)}')
    print(f'All samples={sum(x["samples"] for x in rows)}')
    print('Durations:',sorted(duration_counts.items(),key=lambda x:-x[1])[:15])
    for f,reason in failures[:30]:print('FAIL',f,reason)
    if failures:exit(1)

if __name__=='__main__':main()
