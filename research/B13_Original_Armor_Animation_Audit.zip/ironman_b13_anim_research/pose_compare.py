import sys,zipfile,importlib.util,math
from pathlib import Path
R=Path('/mnt/data/ironman_b13_anim_research')
spec=importlib.util.spec_from_file_location('anim_decoder_b6',R/'anim_decoder_b6.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
with zipfile.ZipFile('/mnt/data/IronMan2_1.0.0_ios_2.2.1.ipa') as z:
 raw=dict(mod.decode_archive(z.read('Payload/IronMan2.app/anims')))
focus=['Ironman_Fly_F.anim','Ironman_Fly_F_RUSH.anim','Ironman_Fly_F_RUSH01.anim','Ironman_Fly_F_RUSH12.anim','IronMan_Air_Move_F.anim','IronMan_Walk_F.anim','IronMan_Aim_Ground_move_F.anim','IronMan_run.anim']
A={k:mod.decode_anim(raw[k]) for k in focus}
def quatdist(q0,q1):
 d=sum(a*b for a,b in zip(q0,q1)); d=max(-1,min(1,abs(d)));return 2*math.degrees(math.acos(d))
def rms_frame_diff(a,b,t=0):
 ca={n:v for n,v in zip(a.names,a.rotations)};cb={n:v for n,v in zip(b.names,b.rotations)}
 angles=[]
 for n in ca.keys() & cb.keys():
  if not n.startswith('Bip01'):continue
  q0=min(ca[n].values,key=lambda x:abs(x[0]-t))[1]
  q1=min(cb[n].values,key=lambda x:abs(x[0]-t))[1]
  angles.append((quatdist(q0,q1),n))
 angles.sort(reverse=True)
 return len(angles),round(math.sqrt(sum(x*x for x,_ in angles)/len(angles)),2),[(n,round(d,2)) for d,n in angles[:5]]
for x,y in [('Ironman_Fly_F.anim','Ironman_Fly_F_RUSH.anim'),('Ironman_Fly_F.anim','Ironman_Fly_F_RUSH01.anim'),('Ironman_Fly_F_RUSH.anim','Ironman_Fly_F_RUSH12.anim'),('IronMan_Air_Move_F.anim','Ironman_Fly_F.anim'),('IronMan_Walk_F.anim','IronMan_Aim_Ground_move_F.anim'),('IronMan_run.anim','IronMan_Walk_F.anim')]:
 print(x,'vs',y)
 for t in [0,800]:
  print(' t=',t,rms_frame_diff(A[x],A[y],t))
