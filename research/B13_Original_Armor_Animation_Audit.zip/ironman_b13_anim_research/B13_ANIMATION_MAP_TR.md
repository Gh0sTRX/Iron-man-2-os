# Iron Man 2 (2010) iOS -> PS Vita: B13 Gerçek Animasyon Haritası

**Tarih:** 12 Ekim 2026. **Kaynak:** Kullanıcının orijinal `IronMan2_1.0.0_ios_2.2.1.ipa` dosyasındaki `Payload/IronMan2.app/anims` arşivi. Önceki B6 çözücüsü ile ikili dosyalar tekrar çözümlendi. Bu bir isim tahmin listesi değil: süreler, isimli kanallar ve quaternion verileri doğrudan `.anim` kayıtlarından alındı. Oyun motorunun runtime transition graph'ı henüz çözümlenmedi. 

## Donanım testleri (KULLANICI DOĞRULADI)

- **B9**: beş zırhın tamamı kuruldu/görüntülendi; görünür geometri deformasyonu bildirilmedi. Çalışan geçişler/animasyonlar var, fakat bazı hareket etiketleri beklenen oyunsal hareketle uyuşmuyor. Normal FPS çoğunlukla **23–25** olarak bildirildi; sahneye göre değişir.
- War Machine için `Fly2Ground` uyarlaması gerçek yere inişten çok uçuşta **aniden durma/poz kırma** gibi görünüyor; bu klibi `landing` olarak doğrulanmış saymıyoruz.
- Mark V / Suitcase modelinde `IronMan_Air_Move_F` kullanımı düşük hızlı havada ilerleme hissi veriyor; **maximum-speed rush** değil.
- Zırhlar yürürken bir kol havada repulsor ateşlemeye hazır; B7/B9'un kullandığı **`IronMan_Aim_Ground_move_F`**, silahsız normal yürüyüş değildir.
- **B10**: VSync açık/kapalı testinde kullanıcının gözüyle önemli FPS farkı yok. İki War Machine fotoğrafında FPS **20 / 20**, CPU **20–22 ms**, `UP` **29 ms**, `COPY` **0 ms**, `PRES` **0 ms**. Bu, önceki birleştirilmiş `SDL 29 ms` okumasının büyük ölçüde **`SDL_UpdateTexture` çağrısında** ölçülen bekleme/zaman olduğuna işaret ediyor; aktarımdan mı GPU eşzamanlamasından mı kaynaklandığı henüz kesin değil. VSync ana sınırlayıcı olarak desteklenmedi. FPS 23–25 raporuyla çelişmez: kare sahne/koşulları değişiyor.

## Tüm orijinal karakter klipleri

- IPA v1.0.0: **972 animasyon**; doğrudan adı `IronMan*` olan **248**, `Warmachine*` olan **56**, ikisinin toplamı **304**. Diğer 668 klip düşmanlar, siviller, efektler gibi öteki ögelere aittir. 
- iOS v1.0.3'te **989 kayıt** var; ek 17 kayıt eski araştırmada iPad sivil karakter hareketleri olarak doğrulanmıştı; ortak 972 hareketin baytları aynı.
- `ALL_304_ARMOR_CLIPS.csv`: bütün 304 klibin adı, süresi, dosya SHA-256'sı, hareket kanalı sayısı ve ilgili modeldeki isim uyumu. `IMPORTANT_ARMOR_CLIPS.csv`: hareket seçimi için 122 önemli aday.
- Bu CSV'de örneğin Iron Man kliplerinin **31 / 37** non-path adının Mark VI sahne düğümleriyle doğrudan eşleşmesi; geriye kalan farklı tipteki dummy/attachment adlarının otomatik eşleşme olmadığını gösteriyor. B9'un başarısı tüm ek efektleri/attachment'ları da eşleştirdiğimiz anlamına gelmez. War Machine'in bazı ek tabaka/ışık adları da farklı olabilir.

## B13'te kullanılması düşünülen orijinal durum animasyonları

| İşlev | İlk denenecek orijinal kayıt | Süre | Doğrulama ihtiyacı |
|---|---|---:|---|
| Yerde rahat bekleme | `IronMan_Ground_Idel.anim` | 1399 ms | `Idel` orijinal yazımı; silahsız/dinlenme duruşu için görsel kontrol |
| **NORMAL YÜRÜME** | `IronMan_Walk_F.anim` | 1200 ms | Kullanılan `IronMan_Aim_Ground_move_F.anim` (866ms) ile yan yana görsel test |
| Koşma | `IronMan_run.anim` | 533 ms | Animasyon hızı ve oyun içi fizik hızını ayrı ayarla |
| Yerde nişan alma yürüyüşü | `IronMan_Aim_Ground_move_F.anim` | 866 ms | Ateş/aim durumundayken kullan; şu anki sürekli hedef alma pozu bu aileden |
| Hover idle | `IronMan_Aim_Float_idle.anim` | 1600 ms | B9 doğrulandı (uyarlanmış zırhlarda değişebilir) |
| Hover'da ileri gitme | `IronMan_Air_Move_F.anim` | 1600 ms | Mark V'nin yavaş uçuş hissi buna uyuyor |
| İleri uçuş normal | `Ironman_Fly_F.anim` | 1600 ms | War Machine klibinden uyarlamak yerine asli Iron Man fly pose adayı |
| **RUSH ileri uçuş** | `Ironman_Fly_F_RUSH.anim` | 1600 ms | Gerçek kemik pozuyla farklı, hareket hızı/kontrolü orijinal runtime'dan ayrıca teyit edilmeli |
| RUSH ara pozları | `Ironman_Fly_F_RUSH01.anim` … `RUSH12.anim` | 1600 ms her biri | Aşağıdaki eşit aralıklı pose geçişinde kullanılabilir |
| Hızlı uçuş başlangıcı | `Ironman_Fly_Start.anim` | 333 ms | Ground takeoff ile `fly` mode başlangıcı aynı olmayabilir |
| Hızlı uçuş sonu | `Ironman_Fly_End.anim` | 400 ms | Uçuştan çıkış; iniş demek değil |
| Uçuştan yere geçiş | `IronMan_Fly2Ground.anim` | 633 ms | War Machine retarget'i kullanıcı testinde ani duruş gibi göründü |
| İniş | `IronMan_Air_land.anim` | 800 ms | Farklı giriş/çıkış pozlarıyla oynatılmalı |
| Sert iniş varyantı | `IronMan_Air_land_s_start` / `_fall` / `_end` | 300/400/1100 ms | İsme göre aday, 3D test gerekiyor |
| Repulsor nişan/atış | `IronMan_Aim_Ground_Beam1/2/3.anim` | 400/400/1000 ms | Kollar/particle/ses ayrı doğrulanacak |
| Havada repulsor nişan/atış | `IronMan_Aim_Float_Beam1/2/3.anim` | 600/400/1266 ms | Silah/VFX kontrolü ayrı |
| War Machine havada ilerleme | `Warmachine_Aim_Float_move_F.anim` | 1600 ms | Hover hareketi için orijinal klip |
| War Machine uçuş | `Warmachine_Aim_Fly_M.anim` | 1600 ms | B8/B9'da retarget hedefinin kaynak hareketi |
| War Machine yerde ileri | `Warmachine_Aim_Ground_move_F.anim` | 866 ms | Mark VI'ya benzer aim yürüyüşü; **ayrı `Warmachine_Walk_F` kaydı bulunmadı** |

**Önemli:** Klip adı bir **hareket durumu veya hareket pozu** gösterebilir. `1600 ms` klip süresi dünya koordinatında metre/saniye hızı anlamına gelmez; hız motorun state/velocity kodunda hesaplanır.

## Yeni analitik keşif: RUSH varyantları düzgün bir ara poz dizisi gibi

Kaynak `.anim` dosyalarındaki aynı 27 `Bip01*` ekleminin **ilk quaternion pozları** arasında RMS açısal fark hesaplandı. Değerler geometrik/poz farkıdır, oyun hızı değildir.

| Poz | `Fly_F` normal uçuşa fark (RMS derece) |
|---|---:|
| Normal `Fly_F` | 0.00 |
| `RUSH01` | 1.03 |
| `RUSH02` | 2.29 |
| `RUSH03` | 4.22 |
| `RUSH04` | 6.56 |
| `RUSH05` | 8.48 |
| `RUSH06` | 10.46 |
| `RUSH07` | 12.46 |
| `RUSH08` | 14.47 |
| `RUSH09` | 16.50 |
| `RUSH10` | 18.53 |
| `RUSH11` | 20.56 |
| `RUSH12` | 22.60 |
| Kaynak `RUSH` | 22.60 |

13 RUSH dosyasının hepsi SHA256 olarak **farklı**. `RUSH12` ve temel `RUSH` çok yakın (~1° fark). `Fly_F` ile temel `RUSH` arasında 27 ortak jointin 0 ms'lik başlangıç pozu ortalama 22.60° açısal fark içeriyor; el kemiklerinin yerel dönüş farkı 68.97°'ye kadar çıkıyor. Bu düzen muhtemelen NORMAL uçuş → RUSH duruşu için ara pozlar; özgün motorun otomatik karıştırma/state politikasını çözmeden kesin runtime davranışı denemez.

Ayrıca normal yürüyüş ile repulsora nişan alarak yürüyüşün 27 ortak eklemdeki başlangıç RMS poz farkı **~40.25°**. Bu yüzden B9'da iki pozun aynı görünmesini beklememeliyiz.

## Sonraki mühendislik önerisi (B13)

1. Gerekli 3D görünüm testi: Mark VI için `Ground_Idel`, `Walk_F`, `run`, `Aim_Ground_move_F`, `Fly_F`, `RUSH01`, `RUSH06`, `RUSH12`, `Fly_End`, `Air_land`; War Machine için orijinal idle/ground/float ve Iron Man'in `Fly_End`/`Air_land` retarget testleri. Aralarında uyumlu ayak/hands attachment pozlarını kontrol et.
2. **Sürekli aim-walk** yerine mod ayrımı kur: sol analog & NO AIM → `Walk_F` / `run`; aim veya repulsor ateşleme → `Aim_Ground_move_F`/atış overlay. Kamera oyun alanına göre taşınmalı.
3. Havada `FLOAT`, `MOVE_F`, `FLY_F`, `RUSH` ayrı state olsun. Geçişleri snapshot pozların doğru blendlenmesi ile gerçekleştir; base `RUSH` doğrudan zıplamasın. War Machine'in yüksek hızlı oyun motoru durumu ayrıca tasarlanmalı.
4. Uçuş→yer geçişinde hareket sonu (`Fly_End`) ve gerçek iniş (`Air_land`) **ayrı safhalar** olarak test edilsin; War Machine'in doğrudan `Fly2Ground` uyarlaması bu nedenle şu an 'landing verified' değildir.
5. Performans: B10'un 29 ms `UP` çağrısı veri yolu ve ön yüz senkronizasyonunu işaret ediyor. Oyun sahnesi eklemeden önce `SDL_UpdateTexture` beklemesini tasarım olarak azaltmayı/GPU temelli raster yolunu ayrı bir B14 deneyinde araştır. VSync aç/kapa değişimi tek başına çözüm değil.

**Sürüm koruması:** B8 doğrulanmış yedek; B9 ve B10 kullanıcı testine göre cihazda çalışıyor. B13 henüz ayrı Vita VPK değil, doğrulanmış veriye dayalı teknik hareket araştırmasıdır. Orijinal oyun motorunun görevlere kadar portu tamamlanmış değildir.
