import sys,zipfile,importlib.util,math
from pathlib import Path
p=Path('/mnt/data/ironman_b13_anim_research')
spec=importlib.util.spec_from_file_location('anim_decoder_b6',p/'anim_decoder_b6.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
with zipfile.ZipFile('/mnt/data/IronMan2_1.0.0_ios_2.2.1.ipa') as z:d=dict(mod.decode_archive(z.read('Payload/IronMan2.app/anims')))
base=mod.decode_anim(d['Ironman_Fly_F.anim']);rush=mod.decode_anim(d['Ironman_Fly_F_RUSH.anim'])
def comp(a,b):
 A={n:q.values[0][1] for n,q in zip(a.names,a.rotations) if n.startswith('Bip01')}
 B={n:q.values[0][1] for n,q in zip(b.names,b.rotations) if n.startswith('Bip01')}
 D=[]
 for n in A.keys()&B.keys():
  dot=max(-1,min(1,abs(sum(x*y for x,y in zip(A[n],B[n])))))
  D.append(2*math.degrees(math.acos(dot)))
 return round(math.sqrt(sum(x*x for x in D)/len(D)),2)
for i in ['']+[f'{i:02d}' for i in range(1,13)]:
 n=f'Ironman_Fly_F_RUSH{i}.anim';a=mod.decode_anim(d[n]);print(n,'vs regular',comp(a,base),'vs rush',comp(a,rush))
