/* Independent PS Vita third-person mechanics playground. No original physics. */
#include "b14_world.h"
#include <math.h>
#include <string.h>
#define P 3.14159265358979323846f
static float cl(float x,float l,float h){return x<l?l:(x>h?h:x);}
static const float loc[3][3]={{0.f,7.f,.55f},{3.0f,10.0f,.95f},{-3.5f,13.f,1.5f}};
void b14_world_init(B14World *w){memset(w,0,sizeof(*w));w->pitch=.12f;w->cam_z=.82f;w->screen_x=278;w->screen_y=135;}
void b14_world_tick(B14World *w,float dt,float strafe,float forward,float lookx,float looky,float vertical){
  dt=cl(dt,0,.10f);w->orbit+=cl(lookx,-1,1)*1.9f*dt;
  w->pitch=cl(w->pitch+cl(looky,-1,1)*.95f*dt,-.12f,.43f);
  float a=cl(strafe,-1,1),b=cl(forward,-1,1);float len=sqrtf(a*a+b*b);
  if(len>1.f){a/=len;b/=len;len=1.f;}
  float vx=cosf(w->orbit)*a+sinf(w->orbit)*b;
  float vy=-sinf(w->orbit)*a+cosf(w->orbit)*b;
  w->speed=len;
  if(len>.12f){
    float desired=atan2f(vx,vy);
    float delta=atan2f(sinf(desired-w->heading),cosf(desired-w->heading));
    w->heading+=cl(delta,-dt*8.f,dt*8.f);
  }
  const float velocity=(w->flying?(w->rush?4.0f:2.0f):(w->rush?2.2f:1.1f));
  w->x=cl(w->x+vx*velocity*dt,-20,20);w->y=cl(w->y+vy*velocity*dt,-20,20);
  if(w->flying)w->target_z=cl(w->target_z+vertical*1.6f*dt,.35f,3.2f);
  else w->target_z=0;
  w->z+=cl(w->target_z-w->z,-2.5f*dt,2.5f*dt);
  /* Camera follows the player in the world, not the model orbiting in place. */
  const float follow=cl(7.f*dt,0,1);
  w->cam_x+=(w->x-w->cam_x)*follow;
  w->cam_y+=(w->y-w->cam_y)*follow;
  w->cam_z+=(w->z+.82f-w->cam_z)*follow;
  w->cooldown=cl(w->cooldown-dt,0,2);w->beam_time=cl(w->beam_time-dt,0,2);
  b14_world_target(w);
}
void b14_world_project(const B14World *w,float x,float y,float z,float *sx,float *sy,float *scale){
  float rx=cosf(w->orbit),ry=-sinf(w->orbit),fx=sinf(w->orbit),fy=cosf(w->orbit);
  float camx=w->cam_x-fx*4.35f+rx*.68f;
  float camy=w->cam_y-fy*4.35f+ry*.68f;
  float dx=x-camx,dy=y-camy,dz=z-w->cam_z;
  float sideways=dx*rx+dy*ry;
  float depth=dx*fx+dy*fy;
  float v=depth*sinf(w->pitch)+dz*cosf(w->pitch);
  float dist=depth*cosf(w->pitch)-dz*sinf(w->pitch);
  if(dist<.15f){if(sx)*sx=-500;if(sy)*sy=-500;if(scale)*scale=0;return;}
  if(scale)*scale=350.f/dist;
  if(sx)*sx=240.f+sideways*350.f/dist;
  if(sy)*sy=140.f-v*350.f/dist;
}
void b14_world_target(B14World *w){
  if(w->completed){w->visible=0;return;}
  int i=w->hits;if(i>2)i=2;
  float s=0;b14_world_project(w,loc[i][0],loc[i][1],loc[i][2],&w->screen_x,&w->screen_y,&s);
  w->screen_radius=cl(s*.22f,6,34);
  w->visible=s>0 && w->screen_x>=-35 && w->screen_x<515 && w->screen_y>=-35 && w->screen_y<295;
}
int b14_world_fire(B14World *w){
 if(w->cooldown>0.f||w->completed)return 0;
 w->cooldown=.22f;w->beam_time=.14f;w->shots++;
 float dx=w->screen_x-278.f,dy=w->screen_y-135.f;
 if(w->visible && dx*dx+dy*dy<(w->screen_radius+9.f)*(w->screen_radius+9.f)){
   w->hits++;if(w->hits>=3)w->completed=1;else b14_world_target(w);return 1;
 }
 return 0;
}
