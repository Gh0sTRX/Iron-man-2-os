#include "b14_world.h"
#include "b14_pose.h"
#include <assert.h>
#define CHECK(x) do { if(!(x)) {fprintf(stderr,"B14 CHECK FAIL: %s at line %d\n",#x,__LINE__);exit(1);} } while(0)
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
int main(void){
 B14World w;b14_world_init(&w);
 CHECK(w.x==0 && w.y==0 && w.hits==0);
 float px=0,py=0,s=0;b14_world_project(&w,0,7,.55,&px,&py,&s);
 CHECK(isfinite(px)&&isfinite(py)&&s>0);
 for(int i=0;i<20;i++)b14_world_tick(&w,.05f,0,1,0,0,0);
 CHECK(w.y>.3f&&fabsf(w.x)<.01f);
 w.flying=1;w.target_z=1;
 for(int i=0;i<20;i++)b14_world_tick(&w,.05f,0,1,0,0,0);
 CHECK(w.z>.1f);
 w.rush=1;
 CHECK(b14_pose_pick(&(B13Motion){.armor=0},1,1,1,0,0)==B14_RUSH1);
 CHECK(b14_pose_pick(&(B13Motion){.armor=2},1,1,1,0,900)==B14_FLY);
 CHECK(b14_pose_pick(&(B13Motion){.armor=4},0,1,0,0,0)==B14_WALK);
 CHECK(b14_pose_pick(&(B13Motion){.armor=4},1,1,1,0,600)==B14_RUSH12);
 B14World target;b14_world_init(&target);
 target.screen_x=278;target.screen_y=135;target.visible=1;target.screen_radius=18;
 CHECK(b14_world_fire(&target)==1&&target.hits==1);
 CHECK(b14_world_fire(&target)==0); /* cooldown */
 /* Synthetic 1-vertex authentic-animation-stream mock: verify single writer
    and zero-frame discontinuity when switching from WALK to HOVER. */
 IM2Vertex vertex={.x=0,.y=0,.z=0};
 IM2Model model={.vertices=&vertex,.nv=1};
 float resting[3]={0,0,0},walk[6]={1,0,0,2,0,0},hover[6]={4,0,0,5,0,0};
 B7Motion base={.rest=resting,.nverts=1};
 base.hover.xyz=hover;base.hover.verts=1;base.hover.frames=2;base.hover.fps=20;base.hover.duration_ms=50;
 B13Motion adv={.armor=0,.nverts=1};
 adv.clips[B13_WALK]=(B13Clip){.xyz=walk,.verts=1,.frames=2,.fps=20,.duration_ms=50};
 B14Pose pose;CHECK(b14_pose_init(&pose,&model));
 CHECK(b14_pose_tick(&pose,&model,&base,&adv,B14_WALK,1000));
 CHECK(fabsf(vertex.x)<.0001f);
 CHECK(b14_pose_tick(&pose,&model,&base,&adv,B14_WALK,1200));
 CHECK(vertex.x>0.5f);
 float before=vertex.x;
 CHECK(b14_pose_tick(&pose,&model,&base,&adv,B14_HOVER,1201));
 CHECK(fabsf(vertex.x-before)<.0001f); /* no jumping at state entry */
 CHECK(b14_pose_tick(&pose,&model,&base,&adv,B14_HOVER,1400));
 CHECK(vertex.x>3.9f);b14_pose_free(&pose);
 printf("B14 WORLD+STATE PASS: movement, flying, camera projection, rush, hits\n");
 return 0;
}
