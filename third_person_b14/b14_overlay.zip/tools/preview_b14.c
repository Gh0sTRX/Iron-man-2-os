#include "renderer.h"
#include "b14_world.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
int main(int argc,char**argv){
 if(argc<3)return 2;
 IM2Model model={0};if(!im2_load(&model,argv[1]))return 3;
 uint32_t *pixels=malloc((size_t)IM2_W*IM2_H*4);
 float *depth=malloc((size_t)IM2_W*IM2_H*sizeof(float));
 B14World w;b14_world_init(&w);
 for(int i=0;i<15;i++)b14_world_tick(&w,.04f,0,0,0,0,0);
 IM2Camera cam={0};cam.third_person=1;cam.player_x=w.x;cam.player_y=w.y;
 cam.player_heading=w.heading;cam.player_z=w.z;cam.orbit=w.orbit;
 cam.cam_x=w.cam_x;cam.cam_y=w.cam_y;cam.cam_z=w.cam_z;
 cam.pitch=w.pitch;cam.aim_x=278;cam.aim_y=135;cam.target_visible=w.visible;
 cam.target_screen_x=w.screen_x;cam.target_screen_y=w.screen_y;
 cam.target_radius=w.screen_radius;cam.zoom=1;cam.fps=22;
 im2_render(pixels,depth,&model,&cam,"MARK VI",0);
 FILE *f=fopen(argv[2],"wb");if(!f)return 4;
 fprintf(f,"P6\n%d %d\n255\n",IM2_W,IM2_H);
 for(int i=0;i<IM2_W*IM2_H;i++){
  unsigned char b[3]={(pixels[i]>>16)&255,(pixels[i]>>8)&255,pixels[i]&255};fwrite(b,1,3,f);
 }
 fclose(f);im2_free(&model);free(pixels);free(depth);return 0;
}
