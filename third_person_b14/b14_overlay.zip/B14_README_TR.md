# Iron Man 2 PS Vita – B14 Third Person Mechanics Sandbox

B13 hardware feedback: user observed 1-frame firing-aim pose snaps during walking/rush and small flight-phase jumps. War Machine has no authentic native rush flight posture. B14 addresses locomotion continuity via ONE pose writer, transition snapshots (180ms blends) and clip-local timeline, not dual B7+B13 writing.

New: third-person over-shoulder follow camera, camera-relative WASD/left-stick movement with heading, right-stick orbit/pitch, adjustable flight altitude, RUSH state, fixed in-world three-target repulsor range with crosshair and hit tests. 5 authentic game suit assets and original premade B7/B9/B13 skinned clips preserved. This is still a mechanical sandbox, not a recreation of real Iron Man 2 levels/physics or accurate shoot animation layering. Repulsor beam is a simple 2D visual trail after a 3D target projection / crosshair hit-test.

Vita controls: left stick world motion, right stick camera, Circle fly/land, Triangle run/rush, Square fire, Cross next suit, R climb/L descend, SELECT VSync toggle, START exit. Keyboard WASD/arrows, C/T/F/X, E/Q, V, Escape for testing.

The camera follows position in world coordinates. No authentic original 3D collision, environment, target mesh or native firing arm clip is implemented. 3 target points are placeholders in a bounded floor grid. Mark IV, Stealth use Mark VI's compatible skeleton clips. War Machine uses its own verified available hover/flight and aimed ground-walk, and does not show an incorrectly labeled native rush/landing pose.

The legacy B8 on-screen 2D target rendering is NOT used in B14: B14 aims with center-right fixed reticle while right stick controls third person camera. Old B8 C unit tests are preserved and runnable.

Build: overlay this ZIP on top of the fully reconstructed B13 tree. Use official VitaSDK via .github/workflows/third-person-b14.yml. App ID IM2J00009, title Iron Man 2 - Third B14; B13 app IM2H00008 is preserved. No claim of Vita hardware success until user tests VPK.
