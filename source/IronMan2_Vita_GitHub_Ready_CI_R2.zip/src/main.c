/* IRON MAN 2 - PS Vita original asset viewer.
 * Not a port of the game or a way to execute the original IPA.
 * 100% software textured triangle renderer: VitaSDK SDL2 backend only.
 */
#include "renderer.h"
#include <SDL2/SDL.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

static const char *filename[4]={"mark6.im2t","mark4.im2t","warmachine.im2t","stealth.im2t"};
static const char *title[4]={"MARK VI","MARK IV","WAR MACHINE","STEALTH"};
static IM2Model model={0};
static int load(int idx){
    char path[256];
#if defined(__vita__) || defined(__VITA__) || defined(__psp2__)
    snprintf(path,sizeof(path),"app0:/models/%s",filename[idx]);
#else
    snprintf(path,sizeof(path),"models/%s",filename[idx]);
#endif
    return im2_load(&model,path);
}
int main(int argc,char **argv){
    (void)argc;(void)argv;
    if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_GAMECONTROLLER|SDL_INIT_TIMER)<0)return 1;
    SDL_Window *window=SDL_CreateWindow("Iron Man 2 - Original Asset Viewer",SDL_WINDOWPOS_CENTERED,
                             SDL_WINDOWPOS_CENTERED,960,544,SDL_WINDOW_SHOWN);
    if(!window){SDL_Quit();return 2;}
    SDL_Renderer *sdl=SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
    if(!sdl)sdl=SDL_CreateRenderer(window,-1,SDL_RENDERER_SOFTWARE);
    if(!sdl){SDL_DestroyWindow(window);SDL_Quit();return 3;}
    SDL_Texture *display=SDL_CreateTexture(sdl,SDL_PIXELFORMAT_ARGB8888,SDL_TEXTUREACCESS_STREAMING,IM2_W,IM2_H);
    if(!display){SDL_DestroyRenderer(sdl);SDL_DestroyWindow(window);SDL_Quit();return 4;}
    uint32_t *pixels=(uint32_t*)malloc(IM2_W*IM2_H*sizeof(uint32_t));
    float *zbuffer=(float*)malloc(IM2_W*IM2_H*sizeof(float));
    if(!pixels||!zbuffer){free(pixels);free(zbuffer);SDL_DestroyTexture(display);
        SDL_DestroyRenderer(sdl);SDL_DestroyWindow(window);SDL_Quit();return 5;}
    SDL_GameController *pad=NULL;
    for(int i=0;i<SDL_NumJoysticks();i++)if(SDL_IsGameController(i)){pad=SDL_GameControllerOpen(i);break;}
    int idx=0,running=load(idx);IM2Camera camera={3.10f,0.0f,1.0f,0};
    Uint32 last=SDL_GetTicks(),frame=0;
    while(running){
        SDL_Event e;
        while(SDL_PollEvent(&e)){
            if(e.type==SDL_QUIT)running=0;
            if(e.type==SDL_KEYDOWN){
                if(e.key.keysym.sym==SDLK_ESCAPE)running=0;
                if(e.key.keysym.sym==SDLK_x||e.key.keysym.sym==SDLK_SPACE){idx=(idx+1)%4;load(idx);}
                if(e.key.keysym.sym==SDLK_z||e.key.keysym.sym==SDLK_TAB)camera.wireframe=!camera.wireframe;
                if(e.key.keysym.sym==SDLK_r){camera.yaw=3.10f;camera.pitch=0;camera.zoom=1;}
            }
            if(e.type==SDL_CONTROLLERBUTTONDOWN){
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_A){idx=(idx+1)%4;load(idx);}
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_X)camera.wireframe=!camera.wireframe;
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_START)running=0;
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_Y){camera.yaw=3.10f;camera.pitch=0;camera.zoom=1;}
            }
        }
        if(!running)break;
        Uint32 now=SDL_GetTicks();float dt=(now-last)*0.001f;last=now;
        if(dt>0.07f)dt=0.07f;
        float ax=0,ay=0,az=0;
        const Uint8 *keys=SDL_GetKeyboardState(NULL);
        if(keys[SDL_SCANCODE_LEFT])ax-=1;
        if(keys[SDL_SCANCODE_RIGHT])ax+=1;
        if(keys[SDL_SCANCODE_UP])ay+=1;
        if(keys[SDL_SCANCODE_DOWN])ay-=1;
        if(keys[SDL_SCANCODE_PAGEUP]||keys[SDL_SCANCODE_EQUALS])az+=1;
        if(keys[SDL_SCANCODE_PAGEDOWN]||keys[SDL_SCANCODE_MINUS])az-=1;
        if(pad){
            float lx=SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_LEFTX)/32768.0f;
            float ly=SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_LEFTY)/32768.0f;
            float ry=SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_RIGHTY)/32768.0f;
            if(fabsf(lx)>.12f)ax+=lx;
            if(fabsf(ly)>.12f)ay-=ly;
            if(fabsf(ry)>.12f)az-=ry;
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_DPAD_UP))az+=.75f;
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_DPAD_DOWN))az-=.75f;
        }
        camera.yaw+=1.7f*ax*dt;
        camera.pitch+=1.1f*ay*dt;
        if(camera.pitch>.85f)camera.pitch=.85f;
        if(camera.pitch<-.85f)camera.pitch=-.85f;
        camera.zoom+=az*dt*.65f;
        if(camera.zoom<.55f)camera.zoom=.55f;
        if(camera.zoom>2.2f)camera.zoom=2.2f;
        im2_render(pixels,zbuffer,&model,&camera,title[idx],frame++);
        SDL_UpdateTexture(display,NULL,pixels,IM2_W*sizeof(uint32_t));
        SDL_RenderClear(sdl);
        SDL_RenderCopy(sdl,display,NULL,NULL);
        SDL_RenderPresent(sdl);
        if(!pad)SDL_Delay(10);
    }
    if(pad)SDL_GameControllerClose(pad);
    im2_free(&model);free(pixels);free(zbuffer);
    SDL_DestroyTexture(display);SDL_DestroyRenderer(sdl);SDL_DestroyWindow(window);
    SDL_Quit();return 0;
}
