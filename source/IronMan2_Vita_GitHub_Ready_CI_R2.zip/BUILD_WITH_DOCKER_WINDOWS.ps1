# Requires Docker Desktop on Windows (Linux containers enabled).
# No C compiler required on Windows: VitaSDK lives in its Docker image.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'Building Iron Man 2 Vita Asset Beta (VitaSDK Docker 2026.08)...'
docker info | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Docker Desktop is not running.' }
$volume = (Get-Location).Path + ':/workspace'
docker run --rm -v $volume -w /workspace vitasdk/vitasdk:2026.08 sh -lc 'cmake -S . -B build-vita -DCMAKE_TOOLCHAIN_FILE="$VITASDK/share/vita.toolchain.cmake" -DCMAKE_BUILD_TYPE=Release && cmake --build build-vita --parallel 4'
if ($LASTEXITCODE -ne 0) { throw 'Vita build failed. Share the terminal output for diagnosis.' }
Write-Host 'Output: build-vita/IronMan2_Asset_Beta.vpk'
