# Iron Man 2 Vita — GitHub bulut derlemesi (özel depo)

**Önemli:** Bu ZIP içindeki `.im2t` dosyaları Iron Man 2 iOS oyunundan ayrıştırılmış modelleri ve dokuları içerir. Telif hakları nedeniyle **GitHub depounu PRIVATE (Özel)** olarak oluştur. Kaynaklar kişisel test amaçlıdır; internette açıkça dağıtma.

## En kolay yol (PC / tarayıcı)

1. https://github.com/new adresine git.
2. Repository name: `ironman2-vita-private` — Visibility: **Private**; `Create repository`.
3. Bu ZIP'i bilgisayarında aç. GitHub'da özel depona gir, **uploading an existing file** veya `Add file` → `Upload files` seçeneğini kullan.
4. ZIP içindeki `CMakeLists.txt`, `src/`, `models/`, `.github/` klasör yapılarını koruyarak GitHub'a yükle. Bu klasörlerin altındaki dosyaların konumları korunmalı; özellikle `.github/workflows/vita-build.yml` doğru konumda olmalı.
5. `Commit changes` yap. `Actions` sekmesinde `Build Vita Asset Beta` iş akışı bir push ile başlayabilir; başlamazsa `Actions` → `Build Vita Asset Beta` → `Run workflow`.
6. Derleme başarılıysa ilgili iş akışının `Artifacts` kısmındaki `IronMan2_Vita_Asset_Beta` dosyasını indir; içinden `.vpk` çıkacak. VitaShell ile Vita'na kopyalayıp kur.
7. Eğer GitHub Actions hata verirse, iş akışı logunu ChatGPT'ye gönder. Kodun SDL2/VitaSDK uyumluluğu gerçek bulut ortamında henüz doğrulanmadı.

**Bu dosya VPK değildir.** Bilgisayarın, GitHub hesabın veya PS Vita cihazın üzerinden gerçek Vita derlemesi bu çalışma ortamında gerçekleştirilemedi. Dosyaların doğru paketlendiği ve C görüntüleyicinin masaüstünde çalıştığı doğrulandı.

### Desteklediği Vita kontrolleri
- X: Sonraki zırh
- Kare: Tel kafes
- Sol analog: Döndür / eğ
- Sağ analog: Yakınlaştır
- Üçgen: Kamerayı sıfırla
- START: Çıkış

### Bilgisayarda Docker ile alternatif
Bu dizini Docker Desktop kurulu Windows bilgisayarında açıp `BUILD_WITH_DOCKER_WINDOWS.ps1` dosyasını PowerShell üzerinden çalıştırabilirsin. Resmî VitaSDK Docker imajı kullanılır; yaklaşık gigabayt boyutunda ilk SDK indirmesi gerekir.

### İçerik
- `src` C tabanlı yazılımsal 3D rasterizer ve SDL2 uygulama kabuğu
- `models` 4 özgün dokulu modelin `.im2t` veri dosyası
- `.github/workflows/vita-build.yml` GitHub Actions VPK iş akışı
- `tools/check_assets.py` model bütünlük denetimi
- `CMakeLists.txt` SDK ile VPK paket oluşturma hedefi
