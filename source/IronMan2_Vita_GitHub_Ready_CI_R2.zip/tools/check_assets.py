#!/usr/bin/env python3
"""Read-only IM2T integrity test: no dependency beyond Python stdlib."""
from pathlib import Path
import struct
root=Path(__file__).resolve().parent.parent
for code in ['mark6','mark4','warmachine','stealth']:
    path=root/'models'/(code+'.im2t')
    raw=path.read_bytes()
    magic,nv,nt,w,h=struct.unpack_from('<4sIIII',raw)
    assert magic==b'IM2T'
    assert 0<nv<=16000 and 0<nt<=24000 and w==512 and h==512
    expected=20+nv*20+nt*6+w*h*4
    assert len(raw)==expected,(code,len(raw),expected)
    faces=struct.unpack_from('<'+'H'*(nt*3),raw,20+nv*20)
    assert max(faces)<nv
    print(f'OK {code:11s} vertices={nv:5d} triangles={nt:5d} texture={w}x{h} bytes={len(raw):,}')
print('4/4 models verified')
