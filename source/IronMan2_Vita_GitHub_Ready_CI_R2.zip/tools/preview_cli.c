#include "../src/renderer.h"
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv){
    if(argc<3){fprintf(stderr,"Usage: preview_cli model.im2t output.ppm [yaw] [pitch] [zoom] [wire]\n");return 1;}
    IM2Model m={0};if(!im2_load(&m,argv[1])){fprintf(stderr,"Couldn't load IM2T\n");return 2;}
    IM2Camera cam={argc>3?atof(argv[3]):0.24,argc>4?atof(argv[4]):0.0,argc>5?atof(argv[5]):1.0,argc>6?atoi(argv[6]):0};
    uint32_t *frame=(uint32_t*)malloc(IM2_W*IM2_H*sizeof(uint32_t));
    float *z=(float*)malloc(IM2_W*IM2_H*sizeof(float));
    if(!frame||!z)return 3;
    im2_render(frame,z,&m,&cam,"ORIGINAL MODEL",0);
    FILE *f=fopen(argv[2],"wb");if(!f)return 4;
    fprintf(f,"P6\n%d %d\n255\n",IM2_W,IM2_H);
    for(int i=0;i<IM2_W*IM2_H;i++){
        unsigned char rgb[3]={(unsigned char)(frame[i]>>16),(unsigned char)(frame[i]>>8),(unsigned char)frame[i]};
        fwrite(rgb,1,3,f);
    }
    fclose(f);free(frame);free(z);im2_free(&m);return 0;
}
