#include "../src/renderer.h"
#include "../src/b7_anim.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
static int validate(const char *file,unsigned suit){
 IM2Model mdl={0};B7Motion motion={0};
 if(!im2_load(&mdl,file)){fprintf(stderr,"IM2T read failed: %s\n",file);return 0;}
 if(!b7_prepare(&motion,suit,&mdl)){fprintf(stderr,"B7 animation load failed: %s\n",file);return 0;}
 float origin[3]={mdl.vertices[0].x,mdl.vertices[0].y,mdl.vertices[0].z};
 b7_apply(&motion,&mdl,1,0,0,200,0);
 float moved=0;
 for(int k=0;k<3;k++){
  float cur=k==0?mdl.vertices[0].x:(k==1?mdl.vertices[0].y:mdl.vertices[0].z);
  moved+=fabsf(cur-origin[k]);
 }
 if(moved<1e-6f){fprintf(stderr,"Hover frames did not change original pose\n");return 0;}
 b7_apply(&motion,&mdl,0,0,0,0,0);
 if(fabsf(mdl.vertices[0].x-origin[0])+fabsf(mdl.vertices[0].y-origin[1])+fabsf(mdl.vertices[0].z-origin[2])>1e-5f){fprintf(stderr,"Rest pose not restored\n");return 0;}
 b7_release(&motion);im2_free(&mdl);
 return 1;
}
int main(){
 if(!validate("models/mark6.im2t",0))return 1;
 if(!validate("models/warmachine.im2t",2))return 1;
 puts("PASS: original armor animation changes pose and rest pose returns exactly");
 return 0;
}
