/*
 * Iron Man 2 — PS Vita Flight Beta B5 (optimized software renderer).
 * Independent experimental locomotion / hovering controller.
 * Uses original IPA-derived textured assets but does NOT execute original gameplay.
 * All movement, HUD and flight simulation here are newly implemented.
 */
#include "renderer.h"
#include "b7_anim.h"
#include <SDL2/SDL.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

static const char *filename[4] = {"mark6.im2t", "mark4.im2t", "warmachine.im2t", "stealth.im2t"};
static const char *title[4] = {"MARK VI", "MARK IV", "WAR MACHINE", "STEALTH"};
static IM2Model model = {0};
static B7Motion motion = {0};

static int load(int idx) {
    char path[256];
#ifdef __vita__
    snprintf(path, sizeof(path), "app0:models/%s", filename[idx]);
#else
    snprintf(path, sizeof(path), "models/%s", filename[idx]);
#endif
    if(!im2_load(&model, path))return 0;
    return b7_prepare(&motion,(unsigned)idx,&model);
}
static float clip(float a,float lo,float hi) {return a<lo?lo:(a>hi?hi:a);}
static float deadzone(float a) {return fabsf(a)<0.16f?0.0f:a;}

int main(int argc,char **argv) {
    (void)argc;(void)argv;
    if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_GAMECONTROLLER|SDL_INIT_TIMER)<0)return 1;
    SDL_Window *window=SDL_CreateWindow("Iron Man 2 - Anim B7",SDL_WINDOWPOS_CENTERED,
                                 SDL_WINDOWPOS_CENTERED,960,544,SDL_WINDOW_SHOWN);
    if(!window){SDL_Quit();return 2;}
    SDL_Renderer *sdl=SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
    if(!sdl)sdl=SDL_CreateRenderer(window,-1,SDL_RENDERER_SOFTWARE);
    if(!sdl){SDL_DestroyWindow(window);SDL_Quit();return 3;}
    SDL_Texture *display=SDL_CreateTexture(sdl,SDL_PIXELFORMAT_ARGB8888,SDL_TEXTUREACCESS_STREAMING,IM2_W,IM2_H);
    if(!display){SDL_DestroyRenderer(sdl);SDL_DestroyWindow(window);SDL_Quit();return 4;}
    uint32_t *pixels=(uint32_t*)malloc(IM2_W*IM2_H*sizeof(uint32_t));
    float *zbuffer=(float*)malloc(IM2_W*IM2_H*sizeof(float));
    if(!pixels||!zbuffer){free(pixels);free(zbuffer);SDL_DestroyTexture(display);
        SDL_DestroyRenderer(sdl);SDL_DestroyWindow(window);SDL_Quit();return 5;}
    SDL_GameController *pad=NULL;
    for(int i=0;i<SDL_NumJoysticks();i++)if(SDL_IsGameController(i)){pad=SDL_GameControllerOpen(i);break;}
    int idx=0,running=load(idx);
    IM2Camera camera={0};camera.yaw=3.10f;camera.zoom=1.0f;
    float desired_altitude=0.0f,phase=0.0f, smooth_fps=0.0f;
    Uint32 landing_started=0; int landing_now=0;
    Uint32 last=SDL_GetTicks(),frame=0;
    while(running){
        SDL_Event e;
        while(SDL_PollEvent(&e)){
            if(e.type==SDL_QUIT)running=0;
            if(e.type==SDL_KEYDOWN){
                SDL_Keycode key=e.key.keysym.sym;
                if(key==SDLK_ESCAPE)running=0;
                if(!e.key.repeat){
                    if(key==SDLK_x||key==SDLK_SPACE){idx=(idx+1)%4;load(idx);}
                    if(key==SDLK_z||key==SDLK_TAB)camera.wireframe=!camera.wireframe;
                    if(key==SDLK_c){camera.flying=!camera.flying;desired_altitude=camera.flying?fmaxf(desired_altitude,.35f):0.0f; landing_now=!camera.flying;landing_started=SDL_GetTicks();}
                    if(key==SDLK_r){camera.yaw=3.10f;camera.pitch=0;camera.zoom=1;
                        camera.move_x=0;camera.move_y=0;camera.flying=0;desired_altitude=0;}
                }
            }
            if(e.type==SDL_CONTROLLERBUTTONDOWN){
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_A){idx=(idx+1)%4;load(idx);}
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_X)camera.wireframe=!camera.wireframe;
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_B){
                    camera.flying=!camera.flying;
                    desired_altitude=camera.flying?fmaxf(desired_altitude,.35f):0.0f;
                    landing_now=!camera.flying;landing_started=SDL_GetTicks();
                }
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_START)running=0;
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_Y){
                    camera.yaw=3.10f;camera.pitch=0;camera.zoom=1;
                    camera.move_x=0;camera.move_y=0;camera.flying=0;desired_altitude=0;
                }
            }
        }
        if(!running)break;
        Uint32 now=SDL_GetTicks();float raw_dt=(now-last)*0.001f;last=now;
        float dt=clip(raw_dt,.0005f,.09f);
        float move_x=0,move_y=0,turn=0,look=0,ascend=0,zoom=0;
        const Uint8 *keys=SDL_GetKeyboardState(NULL);
        if(keys[SDL_SCANCODE_A])move_x-=1;
        if(keys[SDL_SCANCODE_D])move_x+=1;
        if(keys[SDL_SCANCODE_W])move_y+=1;
        if(keys[SDL_SCANCODE_S])move_y-=1;
        if(keys[SDL_SCANCODE_LEFT])turn-=1;
        if(keys[SDL_SCANCODE_RIGHT])turn+=1;
        if(keys[SDL_SCANCODE_UP])look+=1;
        if(keys[SDL_SCANCODE_DOWN])look-=1;
        if(keys[SDL_SCANCODE_E])ascend+=1;
        if(keys[SDL_SCANCODE_Q])ascend-=1;
        if(keys[SDL_SCANCODE_EQUALS])zoom+=1;
        if(keys[SDL_SCANCODE_MINUS])zoom-=1;
        if(pad){
            move_x+=deadzone(SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_LEFTX)/32768.0f);
            move_y-=deadzone(SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_LEFTY)/32768.0f);
            turn+=deadzone(SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_RIGHTX)/32768.0f);
            look-=deadzone(SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_RIGHTY)/32768.0f);
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_RIGHTSHOULDER))ascend+=1;
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_LEFTSHOULDER))ascend-=1;
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_DPAD_UP))zoom+=1;
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_DPAD_DOWN))zoom-=1;
        }
        /* Small bounded test arena. This is not game-world collision. */
        camera.move_x=clip(camera.move_x+clip(move_x,-1,1)*(camera.flying?0.88f:0.56f)*dt,-.85f,.85f);
        camera.move_y=clip(camera.move_y+clip(move_y,-1,1)*(camera.flying?.74f:.48f)*dt,-.65f,.65f);
        camera.yaw+=turn*1.5f*dt;
        camera.pitch=clip(camera.pitch+look*.85f*dt,-.75f,.75f);
        camera.zoom=clip(camera.zoom+zoom*.85f*dt,.65f,1.75f);
        if(camera.flying)desired_altitude=clip(desired_altitude+ascend*.65f*dt,.22f,.90f);
        else desired_altitude=0;
        camera.altitude+=clip(desired_altitude-camera.altitude,-2.0f*dt,2.0f*dt);
        if(fabsf(camera.altitude-desired_altitude)<.001f)camera.altitude=desired_altitude;
        phase+=dt*7.0f;
        camera.hover_bob=camera.flying?.022f*sinf(phase):0.0f;
        float immediate_fps=1.0f/fmaxf(raw_dt,.001f);
        smooth_fps=smooth_fps==0.0f?immediate_fps:smooth_fps*.95f+immediate_fps*.05f;
        camera.fps=smooth_fps;
        /* Diagnostic timings are deliberately measured separately. On real Vita
           this tells us whether the CPU rasterizer or SDL texture upload/present
           is the actual FPS limiter; do not infer from desktop FPS alone. */
        /* Original 2010 keyframed skinning baked to 20fps data for CPU efficiency.
           Walk/hover/land status is an original B4 control prototype. */
        if(landing_now && now-landing_started>800u)landing_now=0;
        const int has_move=fabsf(move_x)+fabsf(move_y)>.18f;
        b7_apply(&motion,&model,camera.flying,has_move,landing_now,(unsigned)now,(unsigned)(now-landing_started));
        const Uint64 tic=SDL_GetPerformanceCounter();
        im2_render(pixels,zbuffer,&model,&camera,title[idx],frame++);
        const Uint64 raster_done=SDL_GetPerformanceCounter();
        SDL_UpdateTexture(display,NULL,pixels,IM2_W*sizeof(uint32_t));
        SDL_RenderClear(sdl);SDL_RenderCopy(sdl,display,NULL,NULL);SDL_RenderPresent(sdl);
        const Uint64 frame_done=SDL_GetPerformanceCounter();
        const double perf_scale=1000.0/(double)SDL_GetPerformanceFrequency();
        const float rast=(float)((raster_done-tic)*perf_scale);
        const float present=(float)((frame_done-raster_done)*perf_scale);
        camera.raster_ms=camera.raster_ms>0?camera.raster_ms*.9f+rast*.1f:rast;
        camera.display_ms=camera.display_ms>0?camera.display_ms*.9f+present*.1f:present;
        if(!pad)SDL_Delay(10);
    }
    if(pad)SDL_GameControllerClose(pad);
    b7_release(&motion);im2_free(&model);free(pixels);free(zbuffer);
    SDL_DestroyTexture(display);SDL_DestroyRenderer(sdl);SDL_DestroyWindow(window);
    SDL_Quit();return 0;
}
