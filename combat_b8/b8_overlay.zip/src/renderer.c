#include "renderer.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define CLAMP(v,a,b) (MAX((a),MIN((v),(b))))

static unsigned im2_get_u32(FILE *f, int *ok) {
    unsigned char p[4];
    if(fread(p,1,4,f)!=4){*ok=0;return 0;}
    return (unsigned)p[0]|((unsigned)p[1]<<8)|((unsigned)p[2]<<16)|((unsigned)p[3]<<24);
}
static unsigned short im2_get_u16(FILE *f, int *ok) {
    unsigned char p[2];
    if(fread(p,1,2,f)!=2){*ok=0;return 0;}
    return (unsigned short)(p[0]|(p[1]<<8));
}
static float im2_get_f32(FILE *f, int *ok){
    uint32_t v=im2_get_u32(f,ok);float o=0.0f;
    memcpy(&o,&v,4);return o;
}
void im2_free(IM2Model *m){
    if(!m)return;
    free(m->vertices);free(m->triangles);free(m->texture);
    memset(m,0,sizeof(*m));
}
int im2_load(IM2Model *dst,const char *path){
    FILE *f=fopen(path,"rb");
    if(!f)return 0;
    IM2Model tmp={0};int ok=1;char magic[4];
    if(fread(magic,1,4,f)!=4||memcmp(magic,"IM2T",4)!=0){fclose(f);return 0;}
    tmp.nv=im2_get_u32(f,&ok);tmp.nt=im2_get_u32(f,&ok);
    tmp.tw=im2_get_u32(f,&ok);tmp.th=im2_get_u32(f,&ok);
    if(!ok||!tmp.nv||tmp.nv>IM2_MAXV||!tmp.nt||tmp.nt>IM2_MAXT||
       !tmp.tw||!tmp.th||tmp.tw>2048||tmp.th>2048){fclose(f);return 0;}
    tmp.vertices=(IM2Vertex*)malloc(sizeof(IM2Vertex)*tmp.nv);
    tmp.triangles=(IM2Triangle*)malloc(sizeof(IM2Triangle)*tmp.nt);
    tmp.texture=(unsigned char*)malloc((size_t)tmp.tw*tmp.th*4);
    if(!tmp.vertices||!tmp.triangles||!tmp.texture){fclose(f);im2_free(&tmp);return 0;}
    for(uint32_t i=0;i<tmp.nv;i++){
        IM2Vertex *v=&tmp.vertices[i];
        v->x=im2_get_f32(f,&ok);v->y=im2_get_f32(f,&ok);v->z=im2_get_f32(f,&ok);
        v->u=im2_get_f32(f,&ok);v->v=im2_get_f32(f,&ok);
        if(!isfinite(v->x)||!isfinite(v->y)||!isfinite(v->z)||!isfinite(v->u)||!isfinite(v->v))ok=0;
    }
    for(uint32_t i=0;i<tmp.nt;i++){
        IM2Triangle *t=&tmp.triangles[i];
        t->i0=im2_get_u16(f,&ok);t->i1=im2_get_u16(f,&ok);t->i2=im2_get_u16(f,&ok);
        if(t->i0>=tmp.nv||t->i1>=tmp.nv||t->i2>=tmp.nv)ok=0;
    }
    if(fread(tmp.texture,4,(size_t)tmp.tw*tmp.th,f)!=(size_t)tmp.tw*tmp.th)ok=0;
    fclose(f);
    if(!ok){im2_free(&tmp);return 0;}
    float minz=tmp.vertices[0].z,maxz=minz;
    for(uint32_t i=1;i<tmp.nv;i++){
        minz=MIN(minz,tmp.vertices[i].z);maxz=MAX(maxz,tmp.vertices[i].z);
    }
    tmp.center_z=(minz+maxz)*0.5f;
    im2_free(dst);*dst=tmp;
    return 1;
}

typedef struct {float sx,sy,iz,uiz,viz,cx,cy,cz;} Projected;
static Projected transformed[IM2_MAXV];
static uint32_t packrgb(unsigned r,unsigned g,unsigned b){
    return 0xff000000u | ((r&255)<<16)|((g&255)<<8)|(b&255);
}
static void pixel(uint32_t *out,int x,int y,uint32_t color){
    if(x>=0&&x<IM2_W&&y>=0&&y<IM2_H)out[y*IM2_W+x]=color;
}
static void line(uint32_t *out,int x0,int y0,int x1,int y1,uint32_t color){
    int dx=abs(x1-x0),dy=abs(y1-y0);
    int sx=x0<x1?1:-1,sy=y0<y1?1:-1;
    int err=dx-dy;
    for(int i=0;i<2500;i++){
        pixel(out,x0,y0,color);
        if(x0==x1&&y0==y1)break;
        int e=err*2;
        if(e>-dy){err-=dy;x0+=sx;}
        if(e<dx){err+=dx;y0+=sy;}
    }
}

/* Built-in 5x7 uppercase font. No SDL_ttf dependency. */
static const unsigned char glyphs[][7]={
    {14,17,17,31,17,17,17},/* A */{30,17,17,30,17,17,30},
    {15,16,16,16,16,16,15},{30,17,17,17,17,17,30},
    {31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
    {15,16,16,19,17,17,15},{17,17,17,31,17,17,17},
    {31,4,4,4,4,4,31},{7,2,2,2,18,18,12},
    {17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
    {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},
    {14,17,17,17,17,17,14},{30,17,17,30,16,16,16},
    {14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
    {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},
    {17,17,17,17,17,17,14},{17,17,17,17,17,10,4},
    {17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
    {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
};
static const unsigned char numerals[][7]={
    {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},
    {14,17,1,2,4,8,31},{30,1,1,14,1,1,30},
    {2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
    {15,16,16,30,17,17,14},{31,1,2,4,8,8,8},
    {14,17,17,14,17,17,14},{14,17,17,15,1,1,30}
};
static void write_text(uint32_t *out,int x,int y,const char *s,uint32_t color,int scale){
    while(*s){
        unsigned char ch=(unsigned char)*s++;
        const unsigned char *g=0;unsigned char special[7]={0};
        if(ch>='A'&&ch<='Z')g=glyphs[ch-'A'];
        if(ch>='0'&&ch<='9')g=numerals[ch-'0'];
        if(ch==':'){special[1]=4;special[4]=4;g=special;}
        if(ch=='-'){special[3]=14;g=special;}
        if(ch=='/'){special[0]=1;special[1]=2;special[2]=4;special[3]=8;special[4]=16;g=special;}
        if(ch=='.'){special[6]=4;g=special;}
        if(g){
            for(int row=0;row<7;row++)for(int col=0;col<5;col++)if(g[row]&(1<<(4-col)))
                for(int dy=0;dy<scale;dy++)for(int dx=0;dx<scale;dx++)
                    pixel(out,x+col*scale+dx,y+row*scale+dy,color);
        }
        x+=6*scale;
    }
}
static void draw_background(uint32_t *out,float yaw){
    for(int y=0;y<IM2_H;y++){
        float t=(float)y/IM2_H;
        unsigned r=(unsigned)(6+8*t),g=(unsigned)(11+16*t),b=(unsigned)(23+23*t);
        uint32_t c=packrgb(r,g,b);
        for(int x=0;x<IM2_W;x++)out[y*IM2_W+x]=c;
    }
    /* Grid gives the prototype a real viewer layout. */
    int floor_y=232;
    for(int i=0;i<12;i++){
        int x=(i*52+(int)(yaw*8))%600-60;
        line(out,240,floor_y-5,x,IM2_H-22,packrgb(20,40,54));
    }
    for(int i=0;i<4;i++){
        int y=floor_y+i*i*3;
        line(out,0,y,IM2_W-1,y,packrgb(20,40,54));
    }
}
static void render_triangle(uint32_t *pixels,float *depth,const IM2Model *m,
                            const Projected *a,const Projected *b,const Projected *c){
    /* Identical perspective-correct UV/depth to B4; incremental barycentric
       edges avoid recomputing four products for EVERY candidate pixel. */
    if(a->iz<=0||b->iz<=0||c->iz<=0)return;
    const float ax=a->sx,ay=a->sy,bx=b->sx,by=b->sy,cx=c->sx,cy=c->sy;
    const float den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy);
    if(fabsf(den)<0.0001f)return;
    const int x0=CLAMP((int)floorf(MIN(ax,MIN(bx,cx))),0,IM2_W-1);
    const int x1=CLAMP((int)ceilf (MAX(ax,MAX(bx,cx))),0,IM2_W-1);
    const int y0=CLAMP((int)floorf(MIN(ay,MIN(by,cy))),0,IM2_H-1);
    const int y1=CLAMP((int)ceilf (MAX(ay,MAX(by,cy))),0,IM2_H-1);
    if(x1<x0||y1<y0)return;
    const float e1x=b->cx-a->cx,e1y=b->cy-a->cy,e1z=b->cz-a->cz;
    const float e2x=c->cx-a->cx,e2y=c->cy-a->cy,e2z=c->cz-a->cz;
    const float nx=e1y*e2z-e1z*e2y,ny=e1z*e2x-e1x*e2z,nz=e1x*e2y-e1y*e2x;
    const float invnorm=1.0f/sqrtf(nx*nx+ny*ny+nz*nz+1e-20f);
    const float intensity=MIN(1.0f,0.45f+0.55f*fabsf((nx*.35f-ny*.65f+nz*.68f)*invnorm));
    const float invden=1.0f/den;
    const float dpdx=(by-cy)*invden,dqdx=(cy-ay)*invden;
    const float dpdy=(cx-bx)*invden,dqdy=(ax-cx)*invden;
    const float x0f=x0+0.5f-cx,y0f=y0+0.5f-cy;
    float pr=(by-cy)*x0f*invden+(cx-bx)*y0f*invden;
    float qr=(cy-ay)*x0f*invden+(ax-cx)*y0f*invden;
    const float dizdp=a->iz-c->iz, dizdq=b->iz-c->iz;
    const float duzdp=a->uiz-c->uiz,duzdq=b->uiz-c->uiz;
    const float dvzdp=a->viz-c->viz,dvzdq=b->viz-c->viz;
    const float dizdx=dpdx*dizdp+dqdx*dizdq;
    const float duzdx=dpdx*duzdp+dqdx*duzdq;
    const float dvzdx=dpdx*dvzdp+dqdx*dvzdq;
    float izr=c->iz+pr*dizdp+qr*dizdq;
    float uzr=c->uiz+pr*duzdp+qr*duzdq;
    float vzr=c->viz+pr*dvzdp+qr*dvzdq;
    const float dizdy=dpdy*dizdp+dqdy*dizdq;
    const float duzdy=dpdy*duzdp+dqdy*duzdq;
    const float dvzdy=dpdy*dvzdp+dqdy*dvzdq;
    const uint32_t tw=m->tw,th=m->th;
    for(int y=y0;y<=y1;y++){
        float p=pr,q=qr,iz=izr,uz=uzr,vz=vzr;
        uint32_t *outrow=pixels+(size_t)y*IM2_W;
        float *zrow=depth+(size_t)y*IM2_W;
        for(int x=x0;x<=x1;x++){
            if(p>=-0.00001f&&q>=-0.00001f&&p+q<=1.00001f&&iz>zrow[x]){
                /* All four verified IM2T atlases have UVs in (0,1).
                   Perspective interpolation stays within that convex range,
                   allowing us to omit expensive floorf-based texture wrap. */
                float inviz=1.0f/iz;
                unsigned tx=(unsigned)CLAMP((int)(uz*inviz*tw),0,(int)tw-1);
                unsigned ty=(unsigned)CLAMP((int)(vz*inviz*th),0,(int)th-1);
                const unsigned char *c4=m->texture+((size_t)ty*tw+tx)*4;
                if(c4[3]>=15){
                    zrow[x]=iz;
                    outrow[x]=packrgb((unsigned)(c4[0]*intensity),
                                      (unsigned)(c4[1]*intensity),
                                      (unsigned)(c4[2]*intensity));
                }
            }
            p+=dpdx;q+=dqdx;iz+=dizdx;uz+=duzdx;vz+=dvzdx;
        }
        pr+=dpdy;qr+=dqdy;izr+=dizdy;uzr+=duzdy;vzr+=dvzdy;
    }
}

void im2_render(uint32_t *pixels,float *zbuffer,const IM2Model *m,
                const IM2Camera *camera,const char *name,unsigned frame_number){
    (void)frame_number;
    draw_background(pixels,camera->yaw);
    memset(zbuffer,0,sizeof(float)*IM2_W*IM2_H);
    if(m&&m->nv){
        const float yaw=camera->yaw,pitch=camera->pitch;
        float sy=sinf(yaw),cy=cosf(yaw),sp=sinf(pitch),cp=cosf(pitch);
        float distance=3.70f/camera->zoom+(camera->flying?0.65f:0.0f);
        for(uint32_t i=0;i<m->nv;i++){
            IM2Vertex v=m->vertices[i];
            /* Keep character rotation but translate player in a world-like arena.
             * Keeping translation separate from yaw is important for controls. */
            float x=v.x*cy-v.y*sy+camera->move_x;
            float y=v.x*sy+v.y*cy+camera->move_y;
            float z=v.z-m->center_z+camera->altitude*0.50f+camera->hover_bob;
            float yy=y*cp-z*sp;
            float zz=y*sp+z*cp;
            float dep=distance-yy;
            Projected *p=&transformed[i];p->cx=x;p->cy=yy;p->cz=zz;
            p->iz=dep>0.15f?1.0f/dep:-1.0f;
            p->sx=IM2_W*0.50f+350.f*x*p->iz;
            p->sy=IM2_H*0.52f-350.f*zz*p->iz;
            p->uiz=v.u*p->iz;p->viz=v.v*p->iz;
        }
        for(uint32_t i=0;i<m->nt;i++){
            IM2Triangle t=m->triangles[i];
            const Projected *a=&transformed[t.i0],*b=&transformed[t.i1],*c=&transformed[t.i2];
            render_triangle(pixels,zbuffer,m,a,b,c);
            if(camera->wireframe && a->iz>0 && b->iz>0 && c->iz>0){
                uint32_t linecol=packrgb(65,208,233);
                line(pixels,(int)a->sx,(int)a->sy,(int)b->sx,(int)b->sy,linecol);
                line(pixels,(int)b->sx,(int)b->sy,(int)c->sx,(int)c->sy,linecol);
                line(pixels,(int)c->sx,(int)c->sy,(int)a->sx,(int)a->sy,linecol);
            }
        }
    }
    for(int y=0;y<24;y++)for(int x=0;x<IM2_W;x++)pixels[y*IM2_W+x]=packrgb(9,18,29);
    write_text(pixels,12,8,"IRON MAN 2",packrgb(224,238,243),2);
    write_text(pixels,285,11,"VITA COMBAT B8",packrgb(81,187,210),1);
    line(pixels,0,24,IM2_W-1,24,packrgb(44,96,111));
    write_text(pixels,10,35,name?name:"NO MODEL",packrgb(250,205,109),2);
    write_text(pixels,10,61,camera->wireframe?"WIREFRAME":"ORIGINAL ATLAS",packrgb(111,196,207),1);
    write_text(pixels,10,75,camera->flying?"FLIGHT MODE":"GROUND MODE",packrgb(228,166,90),1);
    char hud[80];
    snprintf(hud,sizeof(hud),"X %.1f  Y %.1f  ALT %.1f",camera->move_x,camera->move_y,camera->altitude);
    write_text(pixels,10,89,hud,packrgb(131,195,209),1);
    snprintf(hud,sizeof(hud),"FPS %d",(int)(camera->fps+0.5f));
    write_text(pixels,425,35,hud,packrgb(131,195,209),1);
    /* CPU raster / SDL upload+present durations from previous completed frame. */
    snprintf(hud,sizeof(hud),"CPU %.0fMS",camera->raster_ms);
    write_text(pixels,413,47,hud,packrgb(131,195,209),1);
    snprintf(hud,sizeof(hud),"SDL %.0fMS",camera->display_ms);
    write_text(pixels,413,59,hud,packrgb(131,195,209),1);
    for(int y=IM2_H-17;y<IM2_H;y++)for(int x=0;x<IM2_W;x++)pixels[y*IM2_W+x]=packrgb(8,16,28);
    write_text(pixels,7,IM2_H-13,"L MOVE R AIM SQ FIRE O FLY X NEXT START EXIT",packrgb(155,178,188),1);
}
