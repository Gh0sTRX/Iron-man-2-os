#include "../src/b8_combat.h"
#include "../src/renderer.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int main(void){
  B8Combat c;b8_init(&c);
  if(c.stage||c.shots||c.hits)return 1;
  float x,y;b8_get_target(&c,&x,&y);
  if((int)x!=380||(int)y!=137)return 2;
  /* First shot misses, then three hits with cooldown between shots. */
  if(b8_fire(&c)!=0||c.shots!=1||c.hits!=0)return 3;
  if(b8_fire(&c)!=0||c.shots!=1)return 4;
  b8_update(&c,.1f,0,0);b8_update(&c,.1f,0,0);b8_update(&c,.1f,0,0);
  for(int i=0;i<3;i++){
    b8_get_target(&c,&x,&y);c.aim_x=x;c.aim_y=y;
    if(!b8_fire(&c)||c.hits!=(unsigned)(i+1))return 5;
    for(int j=0;j<3;j++)b8_update(&c,.1f,0,0);
  }
  if(!c.completed||c.hits!=3||c.shots!=4||b8_fire(&c))return 6;
  uint32_t *pixels=calloc((size_t)IM2_W*IM2_H,sizeof(uint32_t));
  if(!pixels)return 7;
  b8_draw(pixels,&c);
  unsigned changed=0;for(int i=0;i<IM2_W*IM2_H;i++)changed+=pixels[i]!=0;
  if(changed<1000){fprintf(stderr,"B8 draw failed %u\n",changed);return 8;}
  free(pixels);puts("PASS B8: first miss, debounce, three hits, win, HUD draw");return 0;
}
