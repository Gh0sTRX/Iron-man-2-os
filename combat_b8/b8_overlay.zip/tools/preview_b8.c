#include "../src/renderer.h"
#include "../src/b8_combat.h"
#include <stdio.h>
#include <stdlib.h>
int main(int argc,char**argv){
 if(argc<2)return 1;
 IM2Model m={0};if(!im2_load(&m,"models/mark6.im2t"))return 2;
 uint32_t*p=malloc((size_t)IM2_W*IM2_H*4);
 float*z=malloc((size_t)IM2_W*IM2_H*sizeof(float));
 if(!p||!z)return 3;
 IM2Camera cam={0};cam.yaw=3.10f;cam.zoom=1;cam.fps=30;
 im2_render(p,z,&m,&cam,"MARK VI",1);
 B8Combat combat;b8_init(&combat);combat.aim_x=370;combat.aim_y=137;
 b8_fire(&combat);b8_draw(p,&combat);
 FILE*f=fopen(argv[1],"wb");if(!f)return 4;
 fprintf(f,"P6\n%d %d\n255\n",IM2_W,IM2_H);
 for(int i=0;i<IM2_W*IM2_H;i++){unsigned char rgb[3]={(p[i]>>16)&255,(p[i]>>8)&255,p[i]&255};fwrite(rgb,1,3,f);}
 fclose(f);free(p);free(z);im2_free(&m);return 0;
}
