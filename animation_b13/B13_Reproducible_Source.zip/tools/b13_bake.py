#!/usr/bin/env python3
"""Iron Man 2 (2010) B13 authentic `.anim` -> original skinned IM2V vertex bake.
Takes user-owned IPA resources and base B9 VPK; no invented motion data.
BDAE v0,0,0,133, quaternion convention verified via inverse bind matrix.
"""
import sys,zipfile,struct,math,json,hashlib
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
sys.path.insert(0,str(Path(__file__).resolve().parent))
from anim_decoder_b6 import decode_anim
WORK=Path(__file__).resolve().parents[1]


def parse_rig(raw):
    assert raw[:4]==b'BRES' and struct.unpack_from('<I',raw,12)[0]==len(raw)
    target=raw.find(b'Bip01-node\0');assert target>0
    targetbytes=struct.pack('<I',target)
    loc=[i for i in range(32,len(raw)-72) if raw[i:i+4]==targetbytes]
    assert len(loc)==1,loc
    nodes=[];seen=set()
    def visit(o,parent):
        assert o not in seen;seen.add(o)
        p=struct.unpack_from('<I',raw,o)[0]
        name=raw[p:raw.index(b'\0',p)].decode('latin1')
        pos=struct.unpack_from('<3f',raw,o+12)
        quat=struct.unpack_from('<4f',raw,o+24)
        scale=struct.unpack_from('<3f',raw,o+40)
        count,ch=struct.unpack_from('<II',raw,o+52)
        assert count<32 and (count==0 or ch+count*72<=len(raw))
        nodes.append(dict(name=name,offset=o,parent=parent,pos=pos,quat=quat,scale=scale))
        for i in range(count):visit(ch+i*72,name)
    visit(loc[0],None)
    return nodes

def parse_skin(raw,nv):
    cand=[]
    for o in range(0,len(raw)-40,4):
        nb,pnames,nm,pm,nw,pw,nverts,pc,nidx,pi=struct.unpack_from('<10I',raw,o)
        if nverts!=nv or not 1<=nb<=128 or nm!=nb*16 or not 1<=nw<=128 or not (nv*2<=nidx<=nv*8):continue
        if not (pnames+4*nb<=len(raw) and pm+4*nm<=len(raw) and pw+4*nw<=len(raw) and pc+nv<=len(raw) and pi+2*nidx<=len(raw)):continue
        counts=np.frombuffer(raw,dtype='u1',count=nv,offset=pc)
        if not (np.all((counts>=1)&(counts<=4)) and int(counts.sum())*2==nidx):continue
        namesoff=np.frombuffer(raw,dtype='<u4',count=nb,offset=pnames)
        names=[]
        for p in namesoff:
            if p>=len(raw):break
            s=raw[int(p):raw.index(b'\0',int(p))].decode('latin1')
            if not s.startswith('Bone') or not s[4:].isdigit():break
            names.append(s)
        if len(names)!=nb:continue
        wvalues=np.frombuffer(raw,dtype='<f4',count=nw,offset=pw)
        pairs=np.frombuffer(raw,dtype='<u2',count=nidx,offset=pi).reshape(-1,2)
        if not (np.isfinite(wvalues).all() and np.min(wvalues)>0 and np.max(wvalues)<=1.00001 and np.max(pairs[:,0])<nb and np.max(pairs[:,1])<nw):continue
        idx=np.zeros((nv,4),dtype=np.int32);w=np.zeros((nv,4),dtype=np.float64);k=0
        for vi,n in enumerate(counts):
            n=int(n);record=pairs[k:k+n];k+=n
            idx[vi,:n]=record[:,0];w[vi,:n]=wvalues[record[:,1]]
        if np.max(np.abs(w.sum(axis=1)-1))>1e-5:continue
        inv=np.frombuffer(raw,dtype='<f4',count=nb*16,offset=pm).reshape(nb,4,4).transpose(0,2,1).copy().astype(np.float64)
        cand.append((o,names,inv,idx,w))
    if len(cand)!=1:raise ValueError(f'Expected one skin table, found {len(cand)}')
    return cand[0]

def sample(channel,ms,quat=False):
    vv=channel.values
    if len(vv)==1 or ms<=vv[0][0]:val=vv[0][1]
    elif ms>=vv[-1][0]:val=vv[-1][1]
    else:
        lo=0;hi=len(vv)-1
        while hi-lo>1:
            mid=(lo+hi)//2
            if vv[mid][0]<=ms:lo=mid
            else:hi=mid
        a,b=vv[lo],vv[hi];u=np.array(a[1],dtype=np.float64);v=np.array(b[1],dtype=np.float64)
        if quat and np.dot(u,v)<0:v=-v
        val=u+(v-u)*((ms-a[0])/(b[0]-a[0]))
    arr=np.asarray(val,dtype=np.float64)
    if quat:arr/=np.linalg.norm(arr)
    return arr

def compose(node,pos,q):
    quat=np.asarray(q,dtype=np.float64).copy()
    quat[:3]*=-1;quat/=np.linalg.norm(quat)
    mat=np.eye(4)
    mat[:3,:3]=Rotation.from_quat(quat).as_matrix()@np.diag(node['scale'])
    mat[:3,3]=pos
    return mat

def worlds(nodes,anim=None,ms=0):
    channels={} if anim is None else {name:(p,q) for name,p,q in zip(anim.names,anim.translations,anim.rotations)}
    out={}
    for n in nodes:
        sub=n['name'].removesuffix('-node')
        if n['name'].endswith('-node') and sub in channels:
            p,q=channels[sub];pos=sample(p,ms);rot=sample(q,ms,True)
        else:pos=n['pos'];rot=n['quat']
        local=compose(n,pos,rot)
        out[n['name']]=out[n['parent']]@local if n['parent'] else local
    return out

def prepare(key,source):
    import os
    base_vpk=Path(os.getenv('IM2_B9_VPK', str(WORK/'IronMan2_Armor_B9.vpk')))
    with zipfile.ZipFile(base_vpk) as z: vpk=z.read('models/'+source+'.im2t')
    magic,nv,nt,tw,th=struct.unpack_from('<4s4I',vpk)
    assert magic==b'IM2T' and len(vpk)==20+nv*20+nt*6+tw*th*4
    verts=np.frombuffer(vpk,dtype='<f4',count=nv*5,offset=20).reshape(nv,5).copy()
    raw=(WORK/'inputs'/(key+'.bdae')).read_bytes()
    nodes=parse_rig(raw)
    offset,names,inv,indices,weights=parse_skin(raw,nv)
    mapping={}
    for node in nodes:
        k=struct.unpack_from('<I',raw,node['offset']+8)[0]
        if 0<=k<len(raw):
            label=raw[k:raw.index(b'\0',k)].decode('latin1')
            if label in names:
                assert label not in mapping;mapping[label]=node['name']
    assert len(mapping)==len(names)
    joints=[mapping[x] for x in names]
    rest=worlds(nodes)
    maxerr=max(float(np.max(np.abs(rest[j]@inv[i]-np.eye(4)))) for i,j in enumerate(joints))
    assert maxerr<2e-4,(key,maxerr)
    print(f'VALIDATED RIG {key} vertices={nv} joints={len(joints)} max_bind_matrix_error={maxerr:.8f}')
    return {'nodes':nodes,'joints':joints,'inv':inv,'indexes':indices,'weights':weights,'verts':verts,'name':key,'vpk':vpk,'maxerr':maxerr}

def bake_pose(data,anim,ms):
    ww=worlds(data['nodes'],anim,ms)
    mats=np.stack([ww[n]@data['inv'][i] for i,n in enumerate(data['joints'])])
    pos=data['verts'][:,:3]
    coords=np.concatenate([pos,np.ones((len(pos),1))],axis=1)
    return np.einsum('vkij,vj,vk->vi',mats[data['indexes']],coords,data['weights'],optimize=True)[:,:3]

def bake(data,clip,dest):
    anim=decode_anim((WORK/'inputs'/(clip+'.anim')).read_bytes())
    duration=anim.duration_ms;fps=20
    ticks=list(range(0,duration,50))+[duration]
    frames=np.asarray([bake_pose(data,anim,ms) for ms in ticks],dtype='<f4')
    if not np.isfinite(frames).all():raise ValueError('non finite frames')
    deviation=np.max(np.abs(frames-frames[0])); assert deviation>1e-5,(clip,deviation)
    output=WORK/'animations'/(dest+'.im2v')
    with output.open('wb') as f:
        f.write(struct.pack('<4s4I',b'IM2V',len(data['verts']),len(ticks),fps,duration))
        f.write(frames.tobytes())
    payload=output.read_bytes();assert len(payload)==20+len(ticks)*len(data['verts'])*12
    return dict(asset=dest,source_clip=clip,source_model=data['name'],duration_ms=duration,frames=len(ticks),vertices=len(data['verts']),size=len(payload),sha256=hashlib.sha256(payload).hexdigest(),pose_max_deviation=float(deviation),rig_rest_error=data['maxerr'])

if __name__=='__main__':
    jobs={
      'Iron_man_mark6':('mark6',[
        ('IronMan_Ground_Idel','ground_idle'),('IronMan_Walk_F','walk_normal'),('IronMan_run','run'),
        ('Ironman_Fly_F','fly_normal'),('Ironman_Fly_F_RUSH','rush_full'),
        ('Ironman_Fly_F_RUSH01','rush01'),('Ironman_Fly_F_RUSH06','rush06'),('Ironman_Fly_F_RUSH12','rush12'),
        ('Ironman_Fly_Start','fly_start'),('Ironman_Fly_End','fly_end')]),
      'suitcase':('suitcase',[
        ('IronMan_Walk_F','walk_normal'),('IronMan_run','run'),
        ('Ironman_Fly_F','fly_normal'),('Ironman_Fly_F_RUSH','rush_full'),
        ('Ironman_Fly_F_RUSH01','rush01'),('Ironman_Fly_F_RUSH06','rush06'),('Ironman_Fly_F_RUSH12','rush12')]),
      'warmachine':('warmachine',[
        ('Warmachine_Aim_Float_move_F','float_move'),
        ('Ironman_Fly_End','fly_end')])
    }
    result=[]
    for key,(src,clips) in jobs.items():
        data=prepare(key,src)
        for clip,slug in clips:
            entry=bake(data,clip,src+'_'+slug)
            print('BAKED',entry['asset'],entry['frames'],'frames',entry['size'],'bytes', 'max-motion',round(entry['pose_max_deviation'],4),flush=True)
            result.append(entry)
    (WORK/'docs'/'B13_ANIMATION_MANIFEST.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print('TOTAL files',len(result),'bytes',sum(x['size'] for x in result))
