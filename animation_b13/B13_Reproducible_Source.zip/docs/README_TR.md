# IRON MAN 2 – PS VITA ORIGINAL ANIMATION B13

**Bağımsız deneysel PS Vita VPK. Orijinal Iron Man 2 oyun motorunun portu değildir.**

## Gerçek değişiklikler

Orijinal 2010 iOS `.anim` dosyalarının kemik/iskelet verileri, orijinal 2010 `.bdae` mesh ağırlıklarıyla yeniden işlenerek 19 yeni `.im2v` akışı hazırlandı. Orijinal oryantasyon doğrulaması, Mark VI/War Machine/Suitcase modellerinde yaklaşık 0.000014 maksimum inverse-bind sapmasıyla geçti. Mark IV ve Stealth, Mark VI ile aynı vertex dizilimini kullandığı için ilgili hareket pozlarını paylaşır.

Yeni modlar:
- Normal yer yürüyüşü: `IronMan_Walk_F`, kol nişanda tutulmuyor.
- Koşma: `IronMan_run` (B13'te HIZLI mod).
- Normal ileri uçuş: `Ironman_Fly_F`.
- RUSH kademesi: `RUSH01 → RUSH06 → RUSH12 → RUSH` (B13'ün YENİ oluşturulan state sıralaması, orijinal oyun sıralaması olduğu ispatlanmış değil).
- War Machine yavaş havada ilerleme: `Warmachine_Aim_Float_move_F`; War Machine uçuş/iniş geçişi için doğrulanmamış iniş yerine hover pozu kullanılır.
- Yerde ateş ettiğinde mevcut hedef alma pozuyla kısa süreli geçiş korunur. Mark V dahil beş zırhın hepsinde yeni sınıflandırmalar denenebilir.

## Vita tuşları

| Kontrol | B13 işlevi |
|---|---|
| Sol analog | Yürü / hareket et |
| **Üçgen** | **Normal ↔ RUN/RUSH** (B13'te yeni) |
| Daire | Havalan / yere geç |
| Kare | Repulsor hedeflerine ateş et (B8 test) |
| Çarpı | Sonraki zırh |
| Sağ analog | Nişangâh |
| L / R | Alçal / yüksel |
| SELECT | B10'dan miras VSync A/B |
| START | Çıkış |

B13, B10'un ayrı FPS/CPU/UP/COPY/PRES ölçümlerini korur. `UP~29ms` için VSync'i ana neden olarak göstermiyoruz; bu deney performansı sihirli şekilde yükseltmiyor.

## Sınırlamalar ve cihaz testi

GitHub Actions VitaSDK derleme geçse de gerçek cihaz testi gerekir. Mevcut dünya düzlemi küçük deney alanı; tam orijinal bölüm, silah mekaniği, düşman AI, animasyon motorunun özgün state graph'i yok. RUSH pozları orijinal ama bunların ne zaman tetikleneceğiyle ilgili B13 mantığı yeni yazıldı. War Machine gerçek iniş kaydı doğrulanmadı. Aşırı hızlı modun hızı tarafımızdan belirlendi; kaynakta özgün fizik hızlarını çözmedik.

## Yeniden oluşturma

1. Kullanıcının orijinal iOS IPA'sındaki `models` ve `anims` paketlerinden istenen `.bdae` ve `.anim` ikililerini `inputs/` altına çıkar (`tools/anim_decoder_b6.py` içinde `decode_archive`).
2. Kullanıcının **B9 VPK** dosyasını çalışma dizinine `IronMan2_Armor_B9.vpk` koy ya da `IM2_B9_VPK` ortam değişkeni ile göster.
3. `python tools/b13_bake.py` (Python 3, numpy, scipy). SHA256 manifest'i `docs/B13_ANIMATION_MANIFEST.json` ile karşılaştır.
4. Vita C kaynakları eski B10 + yeni B13 modül ve 19 `.im2v` dosyasıyla derlenir. Kaynakların ve özgün ticari varlıkların bulunduğu GitHub deposu **özel (Private)** kalmalıdır.
