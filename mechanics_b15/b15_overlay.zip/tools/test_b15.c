#include "b14_world.h"
#include "b14_pose.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#define TEST(x) do{if(!(x)){fprintf(stderr,"B15 failed: %s at %d\n",#x,__LINE__);exit(1);}}while(0)
int main(void){
 B14World w;b14_world_init(&w);
 TEST(w.head_height>.8f && w.camera_distance>4.f);
 float hx0,hy0,s0,hx1,hy1,s1;
 b14_world_project(&w,0.f,0.f,w.head_height,&hx0,&hy0,&s0);
 TEST(s0>0 && isfinite(hx0) && isfinite(hy0));
 w.orbit=1.35f;b14_world_project(&w,0.f,0.f,w.head_height,&hx1,&hy1,&s1);
 TEST(fabsf(hx0-hx1)<.01f && fabsf(hy0-hy1)<.01f);
 w.orbit=0;
 w.flying=1;w.target_z=1;
 b14_world_tick(&w,.04f,0,.35f,0,0,0);TEST(w.flight_stage==1);
 TEST(b15_pose_pick(&(B13Motion){.armor=0},1,1,w.flight_stage,0,0,0)==B14_DRIFT);
 b14_world_tick(&w,.04f,0,.8f,0,0,0);TEST(w.flight_stage==2);
 TEST(b15_pose_pick(&(B13Motion){.armor=2},1,1,2,0,0,0)==B14_FLY);
 w.rush=1;b14_world_tick(&w,.04f,0,.8f,0,0,0);TEST(w.flight_stage==3);
 TEST(b15_pose_pick(&(B13Motion){.armor=0},1,1,3,1,0,650)==B14_RUSHFULL);
 TEST(b15_pose_pick(&(B13Motion){.armor=2},1,1,3,1,0,650)==B14_FLY);
 TEST(b15_pose_pick(&(B13Motion){.armor=4},1,1,3,1,0,250)==B14_RUSH6);
 B14World t;b14_world_init(&t);
 for(int i=0;i<3;i++){
    t.visible=1;t.screen_x=278;t.screen_y=110;t.screen_radius=15;
    TEST(b14_world_fire(&t)==1);
    for(int j=0;j<6;j++)b14_world_tick(&t,.05f,0,0,0,0,0);
 }
 TEST(t.completed && t.total_hits==3 && t.shots==3);
 /* User reported that clearing three targets completely disabled repulsors. */
 TEST(b14_world_fire(&t)==0 && t.shots==4 && t.beam_time>0);
 for(int i=0;i<18;i++)b14_world_tick(&t,.10f,0,0,0,0,0);
 TEST(!t.completed && t.hits==0 && t.waves==1 && t.total_hits==3);
 t.visible=1;t.screen_x=278;t.screen_y=110;t.screen_radius=15;
 TEST(b14_world_fire(&t)==1 && t.total_hits==4);
 puts("B15 PASS: head-pivot orbit, three flight stages, WarMachine fallback, infinite target waves");
 return 0;
}
