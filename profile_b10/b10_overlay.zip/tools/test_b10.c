#include "../src/b10_profile.h"
#include <assert.h>
#include <stdio.h>
#include <math.h>
int main(void){
 B10Profiler p={0};
 b10_record(&p, 1,2,3,4,5);
 assert(p.samples==1 && p.motion_ms==1 && p.cpu_ms==2);
 assert(p.upload_ms==3 && p.copy_ms==4 && p.present_ms==5);
 b10_record(&p,1,12,3,4,5);
 assert(p.samples==2 && fabsf(p.cpu_ms-3.2f)<0.001f);
 b10_record(&p,1,NAN,-10,4000,5);
 assert(isfinite(p.cpu_ms) && p.cpu_ms==3.2f);
 assert(p.upload_ms==3 && p.copy_ms==4);
 puts("PASS B10: segment sampling, EMA, invalid sample rejection");
 return 0;
}
