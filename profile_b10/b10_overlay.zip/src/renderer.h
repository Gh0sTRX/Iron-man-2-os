#ifndef IM2_RENDERER_H
#define IM2_RENDERER_H
#include <stdint.h>
#define IM2_W 480
#define IM2_H 272
#define IM2_MAXV 16000
#define IM2_MAXT 24000
typedef struct {float x,y,z,u,v;} IM2Vertex;
typedef struct {uint16_t i0,i1,i2;} IM2Triangle;
typedef struct {
    IM2Vertex *vertices;
    IM2Triangle *triangles;
    unsigned char *texture;
    uint32_t nv, nt, tw, th;
    float center_z;
} IM2Model;
typedef struct {
    float yaw, pitch, zoom;
    int wireframe;
    /* V4 experimental gameplay prototype (not original Iron Man 2 game engine). */
    float move_x, move_y, altitude, hover_bob, fps;
    int flying;
    float raster_ms, display_ms;  /* Retained for B9 compatibility */
    float motion_ms, upload_ms, copy_ms, present_ms;
    int vsync_requested, vsync_active, profile_error;
} IM2Camera;
int im2_load(IM2Model *dst, const char *path);
void im2_free(IM2Model *model);
void im2_render(uint32_t *pixels, float *zbuffer,
                const IM2Model *model, const IM2Camera *camera,
                const char *model_name, unsigned frame_number);
#endif
