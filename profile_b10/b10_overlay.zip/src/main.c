/*
 * Iron Man 2 — PS Vita Flight Beta B5 (optimized software renderer).
 * Independent experimental locomotion / hovering controller.
 * Uses original IPA-derived textured assets but does NOT execute original gameplay.
 * All movement, HUD and flight simulation here are newly implemented.
 */
#include "renderer.h"
#include "b7_anim.h"
#include "b8_combat.h"
#include "b10_profile.h"
#include <SDL2/SDL.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

static const char *filename[5] = {"mark6.im2t", "mark4.im2t", "warmachine.im2t", "stealth.im2t", "suitcase.im2t"};
static const char *title[5] = {"MARK VI", "MARK IV", "WAR MACHINE", "STEALTH", "MARK V"};
static IM2Model model = {0};
static B7Motion motion = {0};
static B8Combat range={0};

static int load(int idx) {
    char path[256];
#ifdef __vita__
    snprintf(path, sizeof(path), "app0:models/%s", filename[idx]);
#else
    snprintf(path, sizeof(path), "models/%s", filename[idx]);
#endif
    if(!im2_load(&model, path))return 0;
    return b7_prepare(&motion,(unsigned)idx,&model);
}

/* Recreate renderer only after explicit user input. SDL2 Vita releases may
 * lack SDL_RenderSetVSync; renderer flags are used for a portable A/B test.
 * Keep the old B9 app separate as a reliable rollback. */
static int b10_make_display(SDL_Window *w, SDL_Renderer **out_r, SDL_Texture **out_t,
                            int vsync, int *real_vsync, int *error_flag) {
    SDL_Renderer *r=NULL;
    SDL_Texture *t=NULL;
    Uint32 flags=SDL_RENDERER_ACCELERATED | (vsync?SDL_RENDERER_PRESENTVSYNC:0);
    r=SDL_CreateRenderer(w,-1,flags);
    if(!r && vsync) r=SDL_CreateRenderer(w,-1,SDL_RENDERER_ACCELERATED);
    if(!r) r=SDL_CreateRenderer(w,-1,SDL_RENDERER_SOFTWARE);
    if(!r) return 0;
    t=SDL_CreateTexture(r,SDL_PIXELFORMAT_ARGB8888,SDL_TEXTUREACCESS_STREAMING,IM2_W,IM2_H);
    if(!t){SDL_DestroyRenderer(r);return 0;}
    SDL_RendererInfo info={0};
    if(SDL_GetRendererInfo(r,&info)==0){
        *real_vsync=(info.flags & SDL_RENDERER_PRESENTVSYNC)!=0;
        *error_flag=vsync && !*real_vsync;
    }else { *real_vsync=0; *error_flag=1; }
    *out_r=r;*out_t=t;
    return 1;
}
static int b10_switch_display(SDL_Window *w,SDL_Renderer **r,SDL_Texture **t,
    int *requested,int *effective,int *error_flag){
    const int previous=*requested;
    const int target=!previous;
    SDL_DestroyTexture(*t);*t=NULL;
    SDL_DestroyRenderer(*r);*r=NULL;
    *requested=target;
    if(b10_make_display(w,r,t,target,effective,error_flag))return 1;
    /* Recovery attempt with a conservative no-VSync renderer. */
    *requested=0;
    if(b10_make_display(w,r,t,0,effective,error_flag)){
        *error_flag=1;return 1;
    }
    return 0;
}

static float clip(float a,float lo,float hi) {return a<lo?lo:(a>hi?hi:a);}
static float deadzone(float a) {return fabsf(a)<0.16f?0.0f:a;}

int main(int argc,char **argv) {
    (void)argc;(void)argv;
    if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_GAMECONTROLLER|SDL_INIT_TIMER)<0)return 1;
    SDL_Window *window=SDL_CreateWindow("Iron Man 2 - Frame Profiler B10",SDL_WINDOWPOS_CENTERED,
                                 SDL_WINDOWPOS_CENTERED,960,544,SDL_WINDOW_SHOWN);
    if(!window){SDL_Quit();return 2;}
    SDL_Renderer *sdl=NULL;
    SDL_Texture *display=NULL;
    int vsync_requested=1,vsync_active=0,profile_error=0;
    if(!b10_make_display(window,&sdl,&display,vsync_requested,&vsync_active,&profile_error)){
        SDL_DestroyWindow(window);SDL_Quit();return 3;
    }
    B10Profiler profiler={0};
    uint32_t *pixels=(uint32_t*)malloc(IM2_W*IM2_H*sizeof(uint32_t));
    float *zbuffer=(float*)malloc(IM2_W*IM2_H*sizeof(float));
    if(!pixels||!zbuffer){free(pixels);free(zbuffer);SDL_DestroyTexture(display);
        SDL_DestroyRenderer(sdl);SDL_DestroyWindow(window);SDL_Quit();return 5;}
    SDL_GameController *pad=NULL;
    for(int i=0;i<SDL_NumJoysticks();i++)if(SDL_IsGameController(i)){pad=SDL_GameControllerOpen(i);break;}
    b8_init(&range);
    int idx=0,running=load(idx);
    IM2Camera camera={0};camera.yaw=3.10f;camera.zoom=1.0f;
    float desired_altitude=0.0f,phase=0.0f, smooth_fps=0.0f;
    Uint32 landing_started=0; int landing_now=0;
    int trigger=0;
    Uint32 last=SDL_GetTicks(),frame=0;
    while(running){
        SDL_Event e;
        while(SDL_PollEvent(&e)){
            if(e.type==SDL_QUIT)running=0;
            if(e.type==SDL_KEYDOWN){
                SDL_Keycode key=e.key.keysym.sym;
                if(key==SDLK_ESCAPE)running=0;
                if(key==SDLK_f && !e.key.repeat)trigger=1;
                if(key==SDLK_v && !e.key.repeat){
                  if(!b10_switch_display(window,&sdl,&display,&vsync_requested,&vsync_active,&profile_error))running=0;
                  profiler=(B10Profiler){0};
                }
                if(!e.key.repeat){
                    if(key==SDLK_x||key==SDLK_SPACE){idx=(idx+1)%5;load(idx);}
                    if(key==SDLK_z||key==SDLK_TAB)camera.wireframe=!camera.wireframe;
                    if(key==SDLK_c){camera.flying=!camera.flying;desired_altitude=camera.flying?fmaxf(desired_altitude,.35f):0.0f; landing_now=!camera.flying;landing_started=SDL_GetTicks();}
                    if(key==SDLK_r){b8_init(&range);camera.yaw=3.10f;camera.pitch=0;camera.zoom=1;
                        camera.move_x=0;camera.move_y=0;camera.flying=0;desired_altitude=0;}
                }
            }
            if(e.type==SDL_CONTROLLERBUTTONDOWN){
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_A){idx=(idx+1)%5;load(idx);}
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_X)trigger=1;
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_BACK){
                    if(!b10_switch_display(window,&sdl,&display,&vsync_requested,&vsync_active,&profile_error))running=0;
                    profiler=(B10Profiler){0};
                }
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_B){
                    camera.flying=!camera.flying;
                    desired_altitude=camera.flying?fmaxf(desired_altitude,.35f):0.0f;
                    landing_now=!camera.flying;landing_started=SDL_GetTicks();
                }
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_START)running=0;
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_Y){
                    b8_init(&range);camera.yaw=3.10f;camera.pitch=0;camera.zoom=1;
                    camera.move_x=0;camera.move_y=0;camera.flying=0;desired_altitude=0;
                }
            }
        }
        if(!running)break;
        Uint32 now=SDL_GetTicks();float raw_dt=(now-last)*0.001f;last=now;
        float dt=clip(raw_dt,.0005f,.09f);
        float move_x=0,move_y=0,turn=0,look=0,ascend=0,zoom=0;
        const Uint8 *keys=SDL_GetKeyboardState(NULL);
        if(keys[SDL_SCANCODE_A])move_x-=1;
        if(keys[SDL_SCANCODE_D])move_x+=1;
        if(keys[SDL_SCANCODE_W])move_y+=1;
        if(keys[SDL_SCANCODE_S])move_y-=1;
        if(keys[SDL_SCANCODE_LEFT])turn-=1;
        if(keys[SDL_SCANCODE_RIGHT])turn+=1;
        if(keys[SDL_SCANCODE_UP])look+=1;
        if(keys[SDL_SCANCODE_DOWN])look-=1;
        if(keys[SDL_SCANCODE_E])ascend+=1;
        if(keys[SDL_SCANCODE_Q])ascend-=1;
        if(keys[SDL_SCANCODE_EQUALS])zoom+=1;
        if(keys[SDL_SCANCODE_MINUS])zoom-=1;
        if(pad){
            move_x+=deadzone(SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_LEFTX)/32768.0f);
            move_y-=deadzone(SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_LEFTY)/32768.0f);
            turn+=deadzone(SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_RIGHTX)/32768.0f);
            look-=deadzone(SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_RIGHTY)/32768.0f);
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_RIGHTSHOULDER))ascend+=1;
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_LEFTSHOULDER))ascend-=1;
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_DPAD_UP))zoom+=1;
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_DPAD_DOWN))zoom-=1;
        }
        /* Small bounded test arena. This is not game-world collision. */
        camera.move_x=clip(camera.move_x+clip(move_x,-1,1)*(camera.flying?0.88f:0.56f)*dt,-.85f,.85f);
        camera.move_y=clip(camera.move_y+clip(move_y,-1,1)*(camera.flying?.74f:.48f)*dt,-.65f,.65f);
        /* Right stick aims repulsor; D-pad left/right can orbit model for inspection. */
        if(pad){
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_DPAD_LEFT))camera.yaw-=1.5f*dt;
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_DPAD_RIGHT))camera.yaw+=1.5f*dt;
        }
        b8_update(&range,dt,turn,look);
        if(trigger){b8_fire(&range);trigger=0;}
        camera.zoom=clip(camera.zoom+zoom*.85f*dt,.65f,1.75f);
        if(camera.flying)desired_altitude=clip(desired_altitude+ascend*.65f*dt,.22f,.90f);
        else desired_altitude=0;
        camera.altitude+=clip(desired_altitude-camera.altitude,-2.0f*dt,2.0f*dt);
        if(fabsf(camera.altitude-desired_altitude)<.001f)camera.altitude=desired_altitude;
        phase+=dt*7.0f;
        camera.hover_bob=camera.flying?.022f*sinf(phase):0.0f;
        float immediate_fps=1.0f/fmaxf(raw_dt,.001f);
        smooth_fps=smooth_fps==0.0f?immediate_fps:smooth_fps*.95f+immediate_fps*.05f;
        camera.fps=smooth_fps;
        /* Diagnostic timings are deliberately measured separately. On real Vita
           this tells us whether the CPU rasterizer or SDL texture upload/present
           is the actual FPS limiter; do not infer from desktop FPS alone. */
        /* Original 2010 keyframed skinning baked to 20fps data for CPU efficiency.
           Walk/hover/land status is an original B4 control prototype. */
        if(landing_now && now-landing_started>(motion.land.duration_ms?motion.land.duration_ms:800u))landing_now=0;
        const int has_move=fabsf(move_x)+fabsf(move_y)>.18f;
        const Uint64 t0=SDL_GetPerformanceCounter();
        b7_apply(&motion,&model,camera.flying,has_move,landing_now,(unsigned)now,(unsigned)(now-landing_started));
        const Uint64 t1=SDL_GetPerformanceCounter();
        camera.vsync_requested=vsync_requested;
        camera.vsync_active=vsync_active;
        camera.profile_error=profile_error;
        camera.motion_ms=profiler.motion_ms;
        camera.raster_ms=profiler.cpu_ms;
        camera.upload_ms=profiler.upload_ms;
        camera.copy_ms=profiler.copy_ms;
        camera.present_ms=profiler.present_ms;
        im2_render(pixels,zbuffer,&model,&camera,title[idx],frame++);
        b8_draw(pixels,&range);
        const Uint64 t2=SDL_GetPerformanceCounter();
        if(SDL_UpdateTexture(display,NULL,pixels,IM2_W*sizeof(uint32_t))!=0){running=0;break;}
        const Uint64 t3=SDL_GetPerformanceCounter();
        SDL_RenderClear(sdl);
        SDL_RenderCopy(sdl,display,NULL,NULL);
        const Uint64 t4=SDL_GetPerformanceCounter();
        SDL_RenderPresent(sdl);
        const Uint64 t5=SDL_GetPerformanceCounter();
        const double scale=1000.0/(double)SDL_GetPerformanceFrequency();
        b10_record(&profiler,(float)((t1-t0)*scale), (float)((t2-t1)*scale),
                (float)((t3-t2)*scale),(float)((t4-t3)*scale),(float)((t5-t4)*scale));
        camera.display_ms=profiler.upload_ms+profiler.copy_ms+profiler.present_ms;
        if(!pad)SDL_Delay(10);
    }
    if(pad)SDL_GameControllerClose(pad);
    b7_release(&motion);im2_free(&model);free(pixels);free(zbuffer);
    SDL_DestroyTexture(display);SDL_DestroyRenderer(sdl);SDL_DestroyWindow(window);
    SDL_Quit();return 0;
}
